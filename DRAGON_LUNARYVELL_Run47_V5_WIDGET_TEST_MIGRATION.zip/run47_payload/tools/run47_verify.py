#!/usr/bin/env python3
"""Offline structural, content and art/audio continuity gate for Run 47."""
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent.parent
game = (ROOT / 'lib/game/dragon_lunaryvell_game.dart').read_text()
shell = (ROOT / 'lib/ui/dragon_shell.dart').read_text()
rules = (ROOT / 'lib/game/run47_relic_rules.dart').read_text()
story = (ROOT / 'lib/game/run47_cinematic_story.dart').read_text()
web_audio = (ROOT / 'lib/game/run47_audio_web.dart').read_text()
boss = (ROOT / 'lib/game/boss_encounter_fx.dart').read_text()
boss_rules = (ROOT / 'lib/game/boss_encounter_rules.dart').read_text()
pubspec = (ROOT / 'pubspec.yaml').read_text()
assert ">=3.3.0 <4.0.0" in pubspec, 'Web voice requires Dart 3.3 or later'
assert '// @dart = 3.3' in web_audio, 'Audio interop language gate missing'

for token in (
    'Run47Relics.angles(', '_fireVolleyIndex % 3 == 0',
    "Run47Audio.instance.cue('fire_$suffix')", '_hitWithDragonfire(',
    '_arcFrom(', 'Run47Relics.maxChainTargets',
    '_trinityRemaining', '_piercerRemaining', '_phoenixRemaining',
    '_veilRemaining', '_magnetRemaining', 'Run47Relics.roll(',
    'Run47Relics.sprite(pickup.kind)', 'BossEncounterFx.drawCallout(',
    'Run47Story.waveName(_wave)',
):
    assert token in game, f'Run47 gameplay not connected: {token}'
for token in (
    '_CinematicStoryScene(', 'Run47Story.openingSequence',
    'Run47Story.forWave(', 'Run47Audio.instance.speak(',
    'Icons.record_voice_over', 'SKIP SCENE', 'Voice + live captions',
    'Run47Audio.instance.toggleMute', 'GIVE TRINITY', 'GIVE CHAIN',
    "Text('THE SHATTERED MOONHEART'",
    "beat.heading.startsWith('PROLOGUE')",
):
    assert token in shell, f'Run47 story/control missing: {token}'
widget_test = (ROOT / 'test/widget_test.dart').read_text()
for token in ('campaign shows illustrated prologue',
              "find.text('PROLOGUE · THE SIXTH VOW')",
              "find.text('SKIP SCENE')", "find.text('NEXT')",
              "find.byTooltip('Leave story')"):
    assert token in widget_test, f'Run47 campaign widget test missing: {token}'
assert "find.text('NOT YET')" not in widget_test, \
    'Stale pre-cinematic dialog test must not block the new campaign'
for token in ('class Run47Relics', 'RelicKind', 'maxBolts = 52',
              'maxPickups = 5', 'maxChainTargets = 2'):
    assert token in rules, f'Relic contract missing: {token}'
for token in ('ELYRA', 'Hollow Choir', 'ASTRALIS', 'TEMPESTRYX',
              'IGNIVAR', 'NYXARIEL', 'SOLARION', 'AQUARYTH',
              'static const bossPreludes', 'static const ending'):
    assert token.lower() in story.lower(), f'Mythology missing: {token}'
for token in ('speechSynthesis', 'SpeechSynthesisUtterance',
              'onboundary', 'charIndex', 'music?.volume = .11',
              "name.startsWith('fire_') ? .13"):
    assert token in web_audio, f'Browser audio contract missing: {token}'
assert 'void drawCallout(' in boss
assert 'signatureForWave(' in boss_rules and 'SEVENTH SONG' in boss_rules
assert "if (_fireVolleyIndex % 3 == 0)" in game
assert 'for (final angle in angles)' in game
assert 'Run47Audio.instance.cue' not in game.split('for (final angle in angles)')[1].split('}')[0], 'Per-projectile audio forbidden'

icons = ('trinity', 'phoenix', 'arc', 'piercer',
         'time_veil', 'aegis', 'healing', 'magnet')
for icon in icons:
    path = ROOT / f'assets/images/run47/pickups/{icon}.png'
    raw = path.read_bytes()
    assert raw[:8] == b'\x89PNG\r\n\x1a\n', icon
    assert struct.unpack('>II', raw[16:24]) == (160, 160), icon
    assert raw[25] == 6, f'{icon}: expected RGBA color type'

scenes = ('prologue', 'shattered_spires', 'ashen_oath',
          'veil_between', 'frost_memory', 'last_eclipse')
for scene in scenes:
    path = ROOT / f'assets/images/run47/story/{scene}.jpg'
    raw = path.read_bytes()
    assert raw[:2] == b'\xff\xd8' and raw[-2:] == b'\xff\xd9', scene
    assert len(raw) > 50000, scene

audio = ROOT / 'assets/audio/run47'
effects = ('pickup_trinity', 'pickup_phoenix', 'pickup_arc',
    'pickup_piercer', 'pickup_time_veil', 'pickup_aegis',
    'pickup_healing', 'pickup_magnet', 'pickup_haste',
    'pickup_critical', 'boss_arrival', 'boss_shift', 'boss_victory',
    'fire_astralis', 'fire_temperstryx', 'fire_ignivar',
    'fire_nyxariel', 'fire_solarion', 'fire_aquaryth')
for name in ('sky_ledger_theme', *effects):
    track = audio / f'{name}.ogg'
    assert track.is_file() and 500 < track.stat().st_size < 300000, name
    assert track.open('rb').read(4) == b'OggS', name

for directory in ('assets/images/run47/pickups/',
                  'assets/images/run47/story/', 'assets/audio/run47/'):
    assert f'- {directory}' in pubspec, directory

print('RUN 47 PREFLIGHT PASS — five illustrated acts, voiced captions, '
      'eight alpha relics, ten drops, six dragon voices, 20 original OGGs, '
      'bounded volleys and premium bosses.')
