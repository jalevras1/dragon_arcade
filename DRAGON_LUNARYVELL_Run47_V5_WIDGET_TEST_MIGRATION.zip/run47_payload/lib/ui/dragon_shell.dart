import 'dart:async' show Timer, unawaited;
import 'dart:math' as math;

import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../game/dragon_lunaryvell_game.dart';
import '../game/dragon_profile.dart';
import '../game/campaign_story.dart';
import '../game/run47_cinematic_story.dart';
import '../game/run47_audio.dart';

const _navy = Color(0xFF050817);
const _blue = Color(0xFF65D9FF);
const _gold = Color(0xFFFFD77A);
const _emblem = 'assets/images/branding/lunaryvell_emblem.png';
const _homeArt = 'assets/images/run38/backgrounds/home_moon_gate.png';
const _enableTestTools = bool.fromEnvironment('DL_DEV_TOOLS', defaultValue: false);
const _developerBuildLabel = String.fromEnvironment('DL_TEST_BUILD',
    defaultValue: 'DEVELOPER TEST BUILD');

class DragonShell extends StatefulWidget {
  const DragonShell({super.key});

  @override
  State<DragonShell> createState() => _DragonShellState();
}

class _DragonShellState extends State<DragonShell> {
  DragonProfile _selected = DragonProfile.astralis;
  bool _playing = false;
  bool _campaign = false;
  int _session = 0;

  void _beginArcade() => setState(() {
    _campaign = false;
    _session++;
    _playing = true;
    Run47Audio.instance.start();
  });

  Future<void> _beginCampaign() async {
    Run47Audio.instance.start();
    final start = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: _navy,
        insetPadding: EdgeInsets.zero,
        child: SizedBox(
          width: MediaQuery.sizeOf(ctx).width,
          height: MediaQuery.sizeOf(ctx).height,
          child: _CinematicStoryScene(
          key: const ValueKey('run47_prologue'),
          beats: Run47Story.openingSequence,
          onComplete: () => Navigator.pop(ctx, true),
          onExit: () => Navigator.pop(ctx, false),
          ),
        ),
      ),
    );
    if (start == true && mounted) {
      Run47Audio.instance.stopNarration();
      Run47Audio.instance.start();
      setState(() { _campaign = true; _session++; _playing = true; });
    }
  }

  void _returnToMenu() {
    setState(() => _playing = false);
    // The outgoing GameScreen stops its sounds on dispose. Restart the quiet
    // title theme after that frame without keeping any gameplay cue alive.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) Run47Audio.instance.start();
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: _playing
              ? _GameScreen(
                  key: ValueKey(_session),
                  dragon: _selected,
                  campaignMode: _campaign,
                  onMenu: _returnToMenu,
                  onArcade: _beginArcade,
                  onCampaign: _beginCampaign,
                  onDragonChanged: (dragon) => _selected = dragon,
                )
              : _TitleScreen(
                  selected: _selected,
                  onPlay: _beginArcade,
                  onCampaign: _beginCampaign,
                  onChoose: () => _chooseDragon(
                    context,
                    selected: _selected,
                    onChoose: (dragon) => setState(() => _selected = dragon),
                  ),
                ),
        ),
      );
}

class _TitleScreen extends StatelessWidget {
  const _TitleScreen({
    required this.selected,
    required this.onPlay,
    required this.onCampaign,
    required this.onChoose,
  });

  final DragonProfile selected;
  final VoidCallback onPlay;
  final VoidCallback onCampaign;
  final VoidCallback onChoose;

  @override
  Widget build(BuildContext context) => _PremiumTitleBackdrop(
        child: LayoutBuilder(
          builder: (context, size) => SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: size.maxHeight),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Emblem(size: math.min(size.maxHeight * .3, 218.0)),
                    const Column(
                      children: [
                        Text('DRAGON',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: _gold, fontSize: 31,
                                fontWeight: FontWeight.w900, letterSpacing: 7,
                                shadows: [Shadow(color: Color(0xFF030713),
                                    blurRadius: 14, offset: Offset(0, 3))])),
                        Text('LUNARYVELL',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Colors.white, fontSize: 28,
                                fontWeight: FontWeight.w800, letterSpacing: 2,
                                shadows: [Shadow(color: Color(0xFF030713),
                                    blurRadius: 14, offset: Offset(0, 3))])),
                        SizedBox(height: 8),
                        Text('RISE ABOVE THE ECLIPSE',
                            style: TextStyle(
                                color: _blue, fontSize: 10,
                                letterSpacing: 2.5,
                                shadows: [Shadow(color: Color(0xFF030713),
                                    blurRadius: 10)])),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 350),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _CelestialMenuButton(
                            label: 'BEGIN FLIGHT',
                            icon: Icons.play_arrow_rounded,
                            tone: _MenuTone.royal,
                            height: 56,
                            onPressed: onPlay,
                          ),
                          const SizedBox(height: 10),
                          _CelestialMenuButton(
                            label: 'CAMPAIGN  ·  STORY MODE',
                            icon: Icons.menu_book_outlined,
                            tone: _MenuTone.moon,
                            height: 54,
                            onPressed: onCampaign,
                          ),
                          const SizedBox(height: 12),
                          _CelestialMenuButton(
                            label: 'DRAGON: ${selected.name}',
                            icon: Icons.auto_awesome,
                            tone: _MenuTone.azure,
                            height: 52,
                            onPressed: onChoose,
                          ),
                          const SizedBox(height: 10),
                          _CelestialMenuButton(
                            label: 'HOW TO PLAY',
                            icon: Icons.help_outline,
                            tone: _MenuTone.quiet,
                            height: 48,
                            onPressed: () => _info(context, 'HOW TO PLAY',
                                'Drag on the battlefield to fly. Your dragon '
                                'fires automatically. Dodge attacks and survive '
                                'each wave. Tap your special ability to use its '
                                'power. You can also switch dragons mid-flight.'),
                          ),
                          _CelestialMenuLink(
                            onPressed: () => _info(context, 'ABOUT THE GAME',
                                'DRAGON LUNARYVELL is an original 2D dragon '
                                'arcade adventure featuring six playable dragons. '
                                'Created for portrait touch-screen play.'),
                            label: 'ABOUT THE GAME',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

/// Portrait cinematic presentation with high-contrast captions for silent
/// play, optional phone/browser narration and an always-visible skip route.
class _CinematicStoryScene extends StatefulWidget {
  const _CinematicStoryScene({super.key, required this.beats,
      required this.onComplete, required this.onExit});
  final List<StoryBeat> beats;
  final VoidCallback onComplete, onExit;

  @override
  State<_CinematicStoryScene> createState() => _CinematicStorySceneState();
}

class _CinematicStorySceneState extends State<_CinematicStoryScene> {
  int _index = 0;
  int _visible = 0;
  bool _narrate = true;
  bool _wordTimingActive = false;
  DateTime _lastBoundaryAt = DateTime.fromMillisecondsSinceEpoch(0);
  Timer? _typewriter;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _beginBeat();
    });
  }

  void _beginBeat() {
    _typewriter?.cancel();
    Run47Audio.instance.stopNarration();
    if (widget.beats.isEmpty) return;
    _wordTimingActive = false;
    setState(() => _visible = 0);
    final line = widget.beats[_index].line;
    _typewriter = Timer.periodic(const Duration(milliseconds: 70), (timer) {
      if (!mounted) { timer.cancel(); return; }
      if (_visible >= line.length) { timer.cancel(); return; }
      if (_wordTimingActive && DateTime.now()
          .difference(_lastBoundaryAt).inMilliseconds < 350) {
        return;
      }
      setState(() => _visible = math.min(line.length, _visible + 1));
    });
    if (_narrate) {
      Run47Audio.instance.speak(line,
        speaker: widget.beats[_index].speaker,
        emotion: widget.beats[_index].emotion,
        onBoundary: (position) {
          if (!mounted || _index >= widget.beats.length) return;
          _wordTimingActive = true;
          _lastBoundaryAt = DateTime.now();
          final start = position.clamp(0, line.length).toInt();
          final space = line.indexOf(' ', start);
          final to = space < 0 ? line.length : space;
          if (to > _visible) setState(() => _visible = to);
        },
        onFinished: () {
          if (mounted && _index < widget.beats.length &&
              widget.beats[_index].line == line) {
            setState(() => _visible = line.length);
          }
        });
    }
  }

  void _advance() {
    if (widget.beats.isEmpty) { _finish(); return; }
    if (_visible < widget.beats[_index].line.length) {
      setState(() => _visible = widget.beats[_index].line.length);
      _typewriter?.cancel();
      return;
    }
    if (_index == widget.beats.length - 1) { _finish(); return; }
    setState(() => _index++);
    _beginBeat();
  }

  void _finish() {
    _typewriter?.cancel();
    Run47Audio.instance.stopNarration();
    widget.onComplete();
  }

  void _exit() {
    _typewriter?.cancel();
    Run47Audio.instance.stopNarration();
    widget.onExit();
  }

  @override
  void dispose() {
    _typewriter?.cancel();
    Run47Audio.instance.stopNarration();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.beats.isEmpty) {
      return Center(child: FilledButton(
          onPressed: _finish, child: const Text('CONTINUE THE JOURNEY')));
    }
    final beat = widget.beats[_index];
    final glow = beat.emotion == 'threat'
        ? const Color(0xFFFFA09D)
        : beat.emotion == 'warning'
            ? const Color(0xFFCCB0FF) : _gold;
    return Material(
      color: _navy,
      child: Stack(fit: StackFit.expand, children: [
        Image.asset(beat.art, fit: BoxFit.cover,
          filterQuality: FilterQuality.medium,
          errorBuilder: (_, __, ___) => const _NightBackdrop(
              child: SizedBox.expand())),
        const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Color(0xA0050B1E), Color(0x00101223),
            Color(0x66060816), Color(0xF5060919)],
          stops: [0, .32, .62, 1],
        ))),
        SafeArea(child: Padding(
          padding: const EdgeInsets.fromLTRB(15, 12, 15, 18),
          child: Column(children: [
            Row(children: [
              IconButton.filledTonal(onPressed: _exit,
                  tooltip: 'Leave story', icon: const Icon(Icons.close)),
              const SizedBox(width: 9),
              Expanded(child: Text('THE SKY LEDGER  ·  DRAGON LUNARYVELL',
                  maxLines: 2, textAlign: TextAlign.center,
                  style: TextStyle(color: glow, fontSize: 10,
                      fontWeight: FontWeight.w800, letterSpacing: 1.4))),
              IconButton.filledTonal(
                  tooltip: _narrate ? 'Voice narration off' : 'Voice narration on',
                  onPressed: () {
                    setState(() => _narrate = !_narrate);
                    if (_narrate) { _beginBeat(); }
                    else { Run47Audio.instance.stopNarration(); }
                  },
                  icon: Icon(_narrate ? Icons.record_voice_over
                      : Icons.voice_over_off)),
              IconButton.filledTonal(
                  tooltip: 'Replay this narrated line',
                  onPressed: _beginBeat,
                  icon: const Icon(Icons.replay, size: 19)),
            ]),
            // Preserve the Moonheart prologue title as an actual Text widget.
            // Run 46's campaign smoke test looks for this exact title, and
            // the illustrated Run 47 presentation should still honor it.
            if (beat.heading.startsWith('PROLOGUE'))
              const Padding(
                padding: EdgeInsets.only(top: 17),
                child: Text('THE SHATTERED MOONHEART',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 13,
                        color: Color(0xFFFFE3A1),
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2.25,
                        shadows: [Shadow(
                            blurRadius: 19,
                            color: Color(0xFF070C1B))])),
              ),
            const Spacer(),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(1.5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(19),
                gradient: LinearGradient(colors: [
                  glow.withValues(alpha: .4),
                  const Color(0xFFECCF96),
                  glow.withValues(alpha: .75),
                ]),
                boxShadow: [BoxShadow(color: glow.withValues(alpha: .14),
                    blurRadius: 23, spreadRadius: 2)],
              ),
              child: Container(
                padding: const EdgeInsets.fromLTRB(17, 17, 17, 13),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [Color(0xF016203F), Color(0xF7081028),
                      Color(0xFA111525)]),
                ),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Row(children: [
                    Icon(Icons.auto_awesome, size: 16, color: glow),
                    const SizedBox(width: 9),
                    Expanded(child: Text(beat.heading,
                        maxLines: 2, style: TextStyle(color: glow,
                            fontSize: 10, fontWeight: FontWeight.w800,
                            letterSpacing: 1.35))),
                    Text('${_index + 1} / ${widget.beats.length}',
                        style: const TextStyle(color: Color(0xFFACBBCF),
                            fontSize: 10, letterSpacing: 1)),
                  ]),
                  const SizedBox(height: 14),
                  Align(alignment: Alignment.centerLeft, child: Text(
                      beat.speaker.toUpperCase(),
                      style: const TextStyle(color: Color(0xFFFFE5B8),
                          fontSize: 14, fontWeight: FontWeight.w900,
                          letterSpacing: 2))),
                  const SizedBox(height: 8),
                  ConstrainedBox(
                    constraints: const BoxConstraints(minHeight: 98),
                    child: Align(alignment: Alignment.topLeft,
                      child: Text(beat.line.substring(0, _visible),
                          style: const TextStyle(fontSize: 15.5,
                              height: 1.47, color: Color(0xFFF5F4E9)))),
                  ),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: TextButton.icon(
                      onPressed: _finish,
                      icon: const Icon(Icons.fast_forward, size: 16),
                      label: const Text('SKIP SCENE'),
                      style: TextButton.styleFrom(
                          foregroundColor: const Color(0xFFC4BED0)))),
                    const SizedBox(width: 8),
                    Expanded(child: FilledButton.icon(
                      onPressed: () {
                        Run47Audio.instance.start();
                        _advance();
                      },
                      icon: const Icon(Icons.arrow_forward, size: 17),
                      label: Text(_index == widget.beats.length - 1
                          ? 'TAKE FLIGHT' : 'NEXT'),
                      style: FilledButton.styleFrom(
                        foregroundColor: const Color(0xFF1B1630),
                        backgroundColor: _gold))),
                  ]),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            Text(_narrate && Run47Audio.instance.voiceAvailable
                ? 'Voice + live captions  ·  tap replay if silent'
                : 'Captioned story  ·  narration optional',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFFC2BDCE),
                    fontSize: 10, letterSpacing: .4)),
          ]),
        )),
      ]),
    );
  }
}

class _GameScreen extends StatefulWidget {
  const _GameScreen({
    super.key,
    required this.dragon,
    required this.campaignMode,
    required this.onMenu,
    required this.onArcade,
    required this.onCampaign,
    required this.onDragonChanged,
  });
  final DragonProfile dragon;
  final bool campaignMode;
  final VoidCallback onMenu;
  final VoidCallback onArcade;
  final VoidCallback onCampaign;
  final ValueChanged<DragonProfile> onDragonChanged;

  @override
  State<_GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<_GameScreen> {
  late final DragonLunaryvellGame _game;

  @override
  void initState() {
    super.initState();
    _game = DragonLunaryvellGame(
      dragon: widget.dragon, campaignMode: widget.campaignMode);
    Run47Audio.instance.start();
  }

  @override
  void dispose() {
    Run47Audio.instance.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Stack(
        fit: StackFit.expand,
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onPanDown: (e) {
              Run47Audio.instance.start();
              _game.setTouchTarget(e.localPosition);
            },
            onPanUpdate: (e) => _game.setTouchTarget(e.localPosition),
            onPanEnd: (_) => _game.releaseTouch(),
            onPanCancel: _game.releaseTouch,
            child: GameWidget<DragonLunaryvellGame>(
              game: _game,
              loadingBuilder: (context) => const _LoadingScreen(),
              errorBuilder: (context, error) => _NightBackdrop(
                child: Center(child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.error_outline, size: 44, color: _gold),
                    const SizedBox(height: 10),
                    const Text('FLIGHT COULD NOT LOAD'),
                    const SizedBox(height: 12),
                    Text(error.toString(), textAlign: TextAlign.center,
                        maxLines: 5, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 15),
                    FilledButton(onPressed: widget.onMenu,
                        child: const Text('RETURN TO TITLE')),
                  ]),
                )),
              ),
            ),
          ),
          Positioned(
            left: 8, right: 8, top: 8,
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => Row(children: [
                Expanded(child: _HudPill('SCORE', '${state.score}')),
                const SizedBox(width: 5),
                Expanded(child: _HudPill(
                    state.campaignMode ? 'STORY' : 'WAVE',
                    state.campaignMode
                        ? '${(state.wave - 1) ~/ 5 + 1} · ${state.wave}'
                        : '${state.wave}')),
                const SizedBox(width: 5),
                Expanded(child: _HudPill('HULL', '${state.health}')),
                const SizedBox(width: 5),
                IconButton(
                  tooltip: 'Select dragon: ${state.dragonName}',
                  icon: const Icon(Icons.auto_awesome, color: _gold, size: 20),
                  constraints: const BoxConstraints.tightFor(width: 38, height: 38),
                  padding: EdgeInsets.zero,
                  style: IconButton.styleFrom(
                    backgroundColor: const Color(0x99121E37),
                    side: const BorderSide(color: Color(0x88DCC689)),
                  ),
                  onPressed: () => _chooseDragon(
                    context,
                    selected: _game.dragon,
                    onChoose: (dragon) {
                      widget.onDragonChanged(dragon);
                      unawaited(_game.selectDragon(dragon));
                    },
                  ),
                ),
                IconButton(
                  tooltip: Run47Audio.instance.muted
                      ? 'Unmute music and magic' : 'Mute music and magic',
                  icon: Icon(Run47Audio.instance.muted
                      ? Icons.volume_off_outlined : Icons.volume_up_outlined,
                      color: _gold, size: 19),
                  constraints: const BoxConstraints.tightFor(width: 36, height: 38),
                  padding: EdgeInsets.zero,
                  onPressed: () => setState(Run47Audio.instance.toggleMute),
                ),
              ]),
            ),
          ),
          Positioned(
            bottom: 14, left: 10,
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => Row(children: [
                IconButton.filledTonal(
                  tooltip: state.paused ? 'Resume' : 'Pause',
                  icon: Icon(state.paused ? Icons.play_arrow : Icons.pause),
                  onPressed: _game.togglePause,
                ),
                const SizedBox(width: 5),
                IconButton.filledTonal(
                  tooltip: 'Return to title',
                  icon: const Icon(Icons.home_outlined),
                  onPressed: widget.onMenu,
                ),
              ]),
            ),
          ),
          Positioned(
            bottom: 72, left: 10,
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => Wrap(spacing: 5, children: [
                if (state.hasteRemaining > 0)
                  const _BoostChip(Icons.speed, 'HASTE', _blue),
                if (state.critRemaining > 0)
                  const _BoostChip(Icons.auto_awesome, 'CRITICAL', _gold),
                if (state.shields > 0)
                  _BoostChip(Icons.shield_outlined,
                      'SHIELD ×${state.shields}', const Color(0xFF93B5FF)),
                if (state.trinityRemaining > 0)
                  const _BoostChip(Icons.call_split, 'TRINITY', Color(0xFFD3A5FF)),
                if (state.phoenixRemaining > 0)
                  const _BoostChip(Icons.local_fire_department, 'PHOENIX', Color(0xFFFFB46B)),
                if (state.arcRemaining > 0)
                  const _BoostChip(Icons.bolt, 'CHAIN', Color(0xFF8EEFFF)),
                if (state.piercerRemaining > 0)
                  const _BoostChip(Icons.auto_fix_high, 'PIERCE', Color(0xFFFFDE9A)),
                if (state.veilRemaining > 0)
                  const _BoostChip(Icons.hourglass_bottom, 'TIME VEIL', Color(0xFFC4B5FF)),
                if (state.magnetRemaining > 0)
                  const _BoostChip(Icons.attractions, 'MAGNET', Color(0xFFFFE4A6)),
              ]),
            ),
          ),
          Positioned(
            bottom: 14, right: 8,
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (state.bossActive)
                    Text(state.campaignMode
                        ? CampaignChapter.forWave(state.wave).bossTitle
                        : 'BOSS INBOUND',
                        style: const TextStyle(
                            color: Color(0xFFFFAC92), fontSize: 10,
                            fontWeight: FontWeight.bold)),
                  Text('DRAG TO FLY  ·  AUTO-FIRE',
                      style: TextStyle(
                          color: Colors.white.withValues(alpha: .7), fontSize: 10)),
                  const SizedBox(height: 6),
                  _SpecialAbilityButton(
                    dragon: _game.dragon,
                    state: state,
                    onPressed: _game.activateSpecial,
                  ),
                ],
              ),
            ),
          ),
          Positioned.fill(
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => state.health <= 0
                  ? Center(child: FilledButton.icon(
                      onPressed: _game.restartGame,
                      icon: const Icon(Icons.replay),
                      label: const Text('FLY AGAIN')))
                  : const SizedBox.shrink(),
            ),
          ),
          Positioned.fill(
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) {
                if (!state.campaignIntermission && !state.campaignComplete) {
                  return const SizedBox.shrink();
                }
                return _CinematicStoryScene(
                  key: ValueKey('run47_${state.wave}_${state.campaignComplete}'),
                  beats: Run47Story.forWave(state.wave,
                      completed: state.campaignComplete),
                  onComplete: state.campaignComplete
                      ? widget.onMenu : _game.continueCampaign,
                  onExit: widget.onMenu,
                );
              },
            ),
          ),
          // Last in the Stack: accessible during pause, defeat, chapter
          // transitions and normal play. Debug-only, never on release builds.
          if (_enableTestTools)
            Positioned(
              right: 8, top: 52,
              child: Tooltip(
                message: 'Developer test controls',
                child: OutlinedButton.icon(
                onPressed: () => _developerPanel(context, _game,
                    onMenu: widget.onMenu,
                    onArcade: widget.onArcade,
                    onCampaign: widget.onCampaign,
                    onChoose: () => _chooseDragon(
                      context,
                      selected: _game.dragon,
                      onChoose: (dragon) {
                        widget.onDragonChanged(dragon);
                        unawaited(_game.selectDragon(dragon));
                      },
                    )),
                icon: const Icon(Icons.tune, size: 16),
                label: const Text('DEV'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: _gold,
                  backgroundColor: const Color(0xDD101A34),
                  side: const BorderSide(color: Color(0xFF9DC7D9)),
                  fixedSize: const Size(84, 36),
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  textStyle: const TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w800),
                ),
                ),
              ),
            ),
        ],
      );
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen();
  @override
  Widget build(BuildContext context) => const _NightBackdrop(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _Emblem(size: 168),
              SizedBox(height: 12),
              Text('DRAGON LUNARYVELL',
                  style: TextStyle(color: _gold, fontSize: 17,
                      fontWeight: FontWeight.w800, letterSpacing: 1.8)),
              SizedBox(height: 24),
              CircularProgressIndicator(color: _blue),
              SizedBox(height: 16),
              Text('SUMMONING THE SKIES…',
                  style: TextStyle(color: Colors.white70,
                      fontSize: 11, letterSpacing: 1.5)),
            ],
          ),
        ),
      );
}

class _Emblem extends StatelessWidget {
  const _Emblem({required this.size});
  final double size;
  @override
  Widget build(BuildContext context) => Image.asset(
        _emblem,
        width: size,
        height: size,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stack) => SizedBox(
          width: size,
          height: size,
          child: const Icon(Icons.auto_awesome, color: _gold, size: 90),
        ),
      );
}

/// Finished art only; the existing live widgets own their original positions
/// and all menu tap targets remain actual Flutter buttons above the picture.
class _PremiumTitleBackdrop extends StatelessWidget {
  const _PremiumTitleBackdrop({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) => Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(_homeArt, fit: BoxFit.cover,
            errorBuilder: (context, error, stack) => const DecoratedBox(
              decoration: BoxDecoration(gradient: LinearGradient(
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Color(0xFF28335A), _navy],
              )),
            ),
          ),
          const IgnorePointer(child: DecoratedBox(
            decoration: BoxDecoration(gradient: LinearGradient(
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Color(0x2404081B), Color(0x66040817),
                       Color(0x50040817)],
              stops: [0, .48, 1],
            )),
          )),
          child,
        ],
      );
}

enum _MenuTone { royal, moon, azure, quiet }

/// Original in-place menu actions with dark celestial-metal trim. The title
/// art remains fully visible; no cartoon-flat solid color panels or extra
/// tap targets have been added to the portrait layout.
class _CelestialMenuButton extends StatefulWidget {
  const _CelestialMenuButton({
    required this.label, required this.icon, required this.tone,
    required this.height, required this.onPressed,
  });

  final String label;
  final IconData icon;
  final _MenuTone tone;
  final double height;
  final VoidCallback onPressed;

  @override
  State<_CelestialMenuButton> createState() => _CelestialMenuButtonState();
}

class _CelestialMenuButtonState extends State<_CelestialMenuButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final tint = switch (widget.tone) {
      _MenuTone.royal => const Color(0xFFE7C980),
      _MenuTone.moon => const Color(0xFFD9C1F0),
      _MenuTone.azure => const Color(0xFF93CBDD),
      _MenuTone.quiet => const Color(0xFFADC1D6),
    };
    final topColor = switch (widget.tone) {
      _MenuTone.royal => const Color(0xF02B314D),
      _MenuTone.moon => const Color(0xEF28243D),
      _MenuTone.azure => const Color(0xEE1E2D43),
      _MenuTone.quiet => const Color(0xEA1A2234),
    };
    final shape = BorderRadius.circular(11);
    return Semantics(
      button: true,
      enabled: true,
      label: widget.label,
      child: AnimatedScale(
        scale: _pressed ? .987 : 1,
        duration: const Duration(milliseconds: 110),
        curve: Curves.easeOut,
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: shape,
            border: Border.all(color: tint.withValues(alpha: .65), width: 1.05),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [topColor, const Color(0xF3101729)],
            ),
            boxShadow: [
              BoxShadow(color: const Color(0xFF030713).withValues(alpha: .72),
                  blurRadius: 11, offset: const Offset(0, 4)),
              BoxShadow(color: tint.withValues(alpha: .12), blurRadius: 7),
            ],
          ),
          child: ClipRRect(
            borderRadius: shape,
            child: Material(
              type: MaterialType.transparency,
              child: InkWell(
                onTap: widget.onPressed,
                onHighlightChanged: (pressed) {
                  if (mounted) setState(() => _pressed = pressed);
                },
                splashColor: tint.withValues(alpha: .15),
                highlightColor: tint.withValues(alpha: .08),
                child: SizedBox(
                  height: widget.height,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      IgnorePointer(child: CustomPaint(
                        painter: _CelestialButtonFrame(tint),
                      )),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 29, height: 29,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0x45131931),
                              border: Border.all(
                                  color: tint.withValues(alpha: .52), width: .8),
                            ),
                            child: Icon(widget.icon, size: 17, color: tint),
                          ),
                          const SizedBox(width: 11),
                          Flexible(child: Text(widget.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: const Color(0xFFF0E8D7),
                              fontSize: widget.tone == _MenuTone.quiet ? 13.3 : 14.3,
                              fontWeight: FontWeight.w700,
                              letterSpacing: .85,
                              shadows: const [Shadow(
                                color: Color(0xB9000410), blurRadius: 5,
                                offset: Offset(0, 1),
                              )],
                            ),
                          )),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CelestialButtonFrame extends CustomPainter {
  const _CelestialButtonFrame(this.tint);
  final Color tint;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width < 45 || size.height < 30) return;
    final fine = Paint()
      ..color = tint.withValues(alpha: .22)
      ..strokeWidth = .65
      ..style = PaintingStyle.stroke;
    canvas.drawRRect(RRect.fromRectAndRadius(
      Rect.fromLTWH(4, 4, size.width - 8, size.height - 8),
      const Radius.circular(7)), fine);
    final line = Paint()
      ..color = tint.withValues(alpha: .39)
      ..strokeWidth = .8;
    canvas.drawLine(const Offset(20, 2.5),
        Offset(size.width - 20, 2.5), line);
    final ornament = Paint()
      ..color = tint.withValues(alpha: .58)
      ..strokeWidth = .9
      ..style = PaintingStyle.stroke;
    for (final x in [13.0, size.width - 13.0]) {
      final y = size.height / 2;
      final diamond = Path()
        ..moveTo(x, y - 3.6)
        ..lineTo(x + 3, y)
        ..lineTo(x, y + 3.6)
        ..lineTo(x - 3, y)
        ..close();
      canvas.drawPath(diamond, ornament);
    }
  }

  @override
  bool shouldRepaint(covariant _CelestialButtonFrame oldDelegate) =>
      oldDelegate.tint != tint;
}

class _CelestialMenuLink extends StatelessWidget {
  const _CelestialMenuLink({required this.onPressed, required this.label});
  final VoidCallback onPressed;
  final String label;

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 38,
    child: TextButton(
      onPressed: onPressed,
      style: TextButton.styleFrom(
        foregroundColor: const Color(0xFFE2CEB0),
        overlayColor: const Color(0x33CBA96B),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('✦', style: TextStyle(color: Color(0xAAE7C980))),
        const SizedBox(width: 11),
        Text(label, style: const TextStyle(
          fontSize: 12.5, letterSpacing: 1.45,
          fontWeight: FontWeight.w600,
        )),
        const SizedBox(width: 11),
        const Text('✦', style: TextStyle(color: Color(0xAAE7C980))),
      ]),
    ),
  );
}

class _NightBackdrop extends StatelessWidget {
  const _NightBackdrop({required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -.5),
            radius: 1.3,
            colors: [Color(0xFF243C70), Color(0xFF121A35), _navy],
            stops: [0, .48, 1],
          ),
        ),
        child: Stack(fit: StackFit.expand, children: [
          const IgnorePointer(child: CustomPaint(painter: _Stars())),
          child,
        ]),
      );
}

class _Stars extends CustomPainter {
  const _Stars();
  @override
  void paint(Canvas canvas, Size size) {
    final rand = math.Random(2307);
    for (var i = 0; i < 86; i++) {
      canvas.drawCircle(
          Offset(rand.nextDouble() * size.width,
              rand.nextDouble() * size.height),
          i % 7 == 0 ? 1.25 : .65,
          Paint()..color = Colors.white.withValues(alpha: 
              .15 + rand.nextDouble() * .5));
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _BoostChip extends StatelessWidget {
  const _BoostChip(this.icon, this.label, this.color);
  final IconData icon;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(
      color: const Color(0xE9101930),
      border: Border.all(color: color.withValues(alpha: .6)),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: color, size: 12),
        const SizedBox(width: 3),
        Text(label, style: TextStyle(color: color,
            fontWeight: FontWeight.bold, fontSize: 9)),
      ]),
    ),
  );
}

class _SpecialAbilityButton extends StatelessWidget {
  const _SpecialAbilityButton({required this.dragon,
      required this.state, required this.onPressed});
  final DragonProfile dragon;
  final DragonHudState state;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final ready = state.specialRemaining <= 0 && !state.paused;
    final color = dragon.palette;
    final icon = switch (dragon.id) {
      'astralis' => Icons.auto_awesome,
      'temperstryx' => Icons.electric_bolt,
      'ignivar' => Icons.local_fire_department,
      'nyxariel' => Icons.nights_stay,
      'solarion' => Icons.sunny,
      'aquaryth' => Icons.water_drop,
      _ => Icons.auto_awesome,
    };
    final progress = state.specialMax <= 0 ? 0.0 :
        (1 - state.specialRemaining / state.specialMax)
            .clamp(0.0, 1.0).toDouble();
    return SizedBox(
      width: 184,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: ready
              ? [const Color(0xFF1F3556), color.withValues(alpha: .75)]
              : [const Color(0xFF101A2C), const Color(0xFF1A2340)]),
          border: Border.all(color: ready ? _gold
              : const Color(0xFF52627B), width: ready ? 1.5 : 1),
          borderRadius: BorderRadius.circular(14),
          boxShadow: ready ? [BoxShadow(
              color: color.withValues(alpha: .25), blurRadius: 10)] : [],
        ),
        child: Material(color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: ready ? onPressed : null,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 7),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Row(children: [
                  Icon(icon, color: ready ? _gold : Colors.white54,
                      size: 25),
                  const SizedBox(width: 7),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(dragon.specialAbility.toUpperCase(),
                          maxLines: 2, overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: ready ? Colors.white
                              : Colors.white70, fontSize: 10,
                              fontWeight: FontWeight.w900)),
                      Text(ready ? 'TAP TO UNLEASH' :
                          '${state.specialRemaining.ceil()}s  ·  RECHARGING',
                          style: TextStyle(color: ready ? _gold : _blue,
                              letterSpacing: .3, fontSize: 9)),
                    ],
                  )),
                ]),
                const SizedBox(height: 7),
                ClipRRect(borderRadius: BorderRadius.circular(3),
                  child: LinearProgressIndicator(
                    minHeight: 3,
                    value: progress,
                    color: ready ? _gold : color,
                    backgroundColor: const Color(0xFF33425A),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _HudPill extends StatelessWidget {
  const _HudPill(this.label, this.value);
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0x9917233F), Color(0x8810182B)]),
          border: Border.all(color: const Color(0x66D2BA85)),
          borderRadius: BorderRadius.circular(9),
        ),
        child: SizedBox(
          height: 36,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Flexible(child: Text(label,
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: _blue, fontSize: 8,
                    fontWeight: FontWeight.w600, letterSpacing: .2))),
              const SizedBox(width: 4),
              Text(value, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 14,
                      fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
      );
}

void _chooseDragon(BuildContext context, {
  required DragonProfile selected,
  required ValueChanged<DragonProfile> onChoose,
}) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF101B35),
    builder: (sheetContext) => SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(sheetContext).height * .77),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: Text('CHOOSE YOUR DRAGON', style: TextStyle(
                color: _gold, fontWeight: FontWeight.bold,
                fontSize: 16, letterSpacing: 1.2)),
          ),
          Flexible(child: ListView.builder(
            shrinkWrap: true,
            itemCount: DragonProfile.all.length,
            itemBuilder: (context, i) {
              final profile = DragonProfile.all[i];
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: profile.palette.withValues(alpha: .2),
                  child: Icon(Icons.auto_awesome, color: profile.palette),
                ),
                title: Text(profile.name,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${profile.title} · ${profile.playStyle}',
                    maxLines: 2),
                trailing: profile.id == selected.id
                    ? const Icon(Icons.check_circle, color: _gold)
                    : const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.pop(sheetContext);
                  onChoose(profile);
                },
              );
            },
          )),
        ]),
      ),
    ),
  );
}

void _info(BuildContext context, String title, String message) {
  showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx),
          child: const Text('CLOSE'))],
    ),
  );
}

enum _DevDestination { title, arcade, campaign, dragons, howToPlay, about }

/// Developer-only quick navigation and deterministic smoke tests. The sheet
/// freezes combat but never changes the user's saved assets or game rules.
Future<void> _developerPanel(
  BuildContext context,
  DragonLunaryvellGame game, {
  required VoidCallback onMenu,
  required VoidCallback onArcade,
  required VoidCallback onCampaign,
  required VoidCallback onChoose,
}) async {
  if (!_enableTestTools) return;
  var chosenWave = game.hud.value.wave.clamp(1, CampaignChapter.finalWave).toInt();
  game.developerSetPanelOpen(true);
  _DevDestination? destination;
  try {
    destination = await showModalBottomSheet<_DevDestination>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFF0D1932),
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheetState) {
          void runTest(VoidCallback test) {
            Navigator.pop(sheetContext);
            test();
          }

          Widget testButton(IconData icon, String label, VoidCallback test) =>
              OutlinedButton.icon(
                icon: Icon(icon, size: 17),
                label: Text(label),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFEAF4FF),
                  side: const BorderSide(color: Color(0x887DAACD)),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 11),
                ),
                onPressed: () => runTest(test),
              );

          Widget navButton(IconData icon, String label,
                  _DevDestination target) => OutlinedButton.icon(
                icon: Icon(icon, size: 17),
                label: Text(label),
                style: OutlinedButton.styleFrom(
                  foregroundColor: _gold,
                  side: const BorderSide(color: Color(0xAAFFD77A)),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 11),
                ),
                onPressed: () => Navigator.pop(sheetContext, target),
              );

          Widget section(String title, String detail) => Padding(
                padding: const EdgeInsets.only(top: 19, bottom: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(
                      color: _gold, fontSize: 14,
                      fontWeight: FontWeight.w900, letterSpacing: 1.1)),
                    const SizedBox(height: 3),
                    Text(detail, style: const TextStyle(
                        color: Colors.white60, fontSize: 11)),
                  ],
                ),
              );

          return SafeArea(
            top: false,
            child: SizedBox(
              height: MediaQuery.sizeOf(sheetContext).height * .82,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
                children: [
                  const Row(children: [
                    Icon(Icons.tune, color: _gold),
                    SizedBox(width: 9),
                    Expanded(child: Text('LUNARYVELL  •  DEV HUB',
                        style: TextStyle(color: _gold, fontSize: 17,
                            fontWeight: FontWeight.w900))),
                  ]),
                  const SizedBox(height: 5),
                  Text('$_developerBuildLabel  •  NOT IN PLAYER RELEASES',
                      style: const TextStyle(color: _blue, fontSize: 10,
                          letterSpacing: 1.2)),
                  const SizedBox(height: 10),
                  DecoratedBox(
                    decoration: BoxDecoration(
                      color: const Color(0xBB22304E),
                      border: Border.all(color: const Color(0x6682AAC8)),
                      borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(game.developerSnapshot,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 12, height: 1.5)),
                    ),
                  ),
                  section('GO TO ANY MENU',
                      'Leave this sheet and open the exact screen you need.'),
                  Wrap(spacing: 7, runSpacing: 5, children: [
                    navButton(Icons.home_outlined, 'TITLE MENU',
                        _DevDestination.title),
                    navButton(Icons.play_arrow, 'ARCADE',
                        _DevDestination.arcade),
                    navButton(Icons.menu_book_outlined, 'CAMPAIGN',
                        _DevDestination.campaign),
                    navButton(Icons.auto_awesome, 'DRAGON SELECT',
                        _DevDestination.dragons),
                    navButton(Icons.help_outline, 'HOW TO PLAY',
                        _DevDestination.howToPlay),
                    navButton(Icons.info_outline, 'ABOUT',
                        _DevDestination.about),
                  ]),
                  section('NEW ART AND ANIMATION',
                      'Isolate enemy sprites, inspect scenery or trigger magic.'),
                  Wrap(spacing: 7, runSpacing: 5, children: [
                    testButton(Icons.groups, 'ALL SIX ENEMIES',
                        game.developerEnemyGallery),
                    testButton(Icons.landscape_outlined, 'CLEAR SCENERY',
                        game.developerClearArena),
                    testButton(Icons.auto_fix_high, 'SPECIAL + TARGETS', () {
                      game.developerEnemyGallery();
                      game.developerForceAbilityReady();
                      game.activateSpecial();
                    }),
                    testButton(Icons.flash_on, 'SPECIAL READY',
                        game.developerForceAbilityReady),
                    testButton(Icons.bolt, 'USE SPECIAL', () {
                      game.developerForceAbilityReady();
                      game.activateSpecial();
                    }),
                  ]),
                  section('ENEMIES AND POWER-UPS',
                      'Spawn one enemy or grant/drop a specific pickup.'),
                  Wrap(spacing: 7, runSpacing: 5, children: [
                    testButton(Icons.add, 'SKY RAIDER',
                        () => game.developerSpawnEnemy(0)),
                    testButton(Icons.add, 'STORM HARPY',
                        () => game.developerSpawnEnemy(1)),
                    testButton(Icons.add, 'SHADOW WYVERN',
                        () => game.developerSpawnEnemy(2)),
                    testButton(Icons.add, 'CRYSTAL GARGOYLE',
                        () => game.developerSpawnEnemy(3)),
                    testButton(Icons.add, 'EMBER MANTICORE',
                        () => game.developerSpawnEnemy(4)),
                    testButton(Icons.add, 'VOID MOTH WRAITH',
                        () => game.developerSpawnEnemy(5)),
                    testButton(Icons.speed, 'GIVE HASTE',
                        () => game.developerGrantBoost('haste')),
                    testButton(Icons.auto_awesome, 'GIVE CRITICAL',
                        () => game.developerGrantBoost('critical')),
                    testButton(Icons.shield_outlined, 'GIVE SHIELD',
                        () => game.developerGrantBoost('shield')),
                    testButton(Icons.arrow_downward, 'DROP HASTE',
                        () => game.developerGrantBoost('haste', drop: true)),
                    testButton(Icons.arrow_downward, 'DROP CRITICAL',
                        () => game.developerGrantBoost('critical', drop: true)),
                    testButton(Icons.arrow_downward, 'DROP SHIELD',
                        () => game.developerGrantBoost('shield', drop: true)),
                    testButton(Icons.call_split, 'GIVE TRINITY',
                        () => game.developerGrantBoost('trinity')),
                    testButton(Icons.local_fire_department, 'GIVE PHOENIX',
                        () => game.developerGrantBoost('phoenix')),
                    testButton(Icons.bolt, 'GIVE CHAIN',
                        () => game.developerGrantBoost('arc')),
                    testButton(Icons.auto_fix_high, 'GIVE PIERCE',
                        () => game.developerGrantBoost('piercer')),
                    testButton(Icons.hourglass_bottom, 'GIVE TIME VEIL',
                        () => game.developerGrantBoost('time_veil')),
                    testButton(Icons.favorite, 'GIVE HEAL',
                        () => game.developerGrantBoost('healing')),
                    testButton(Icons.attractions, 'GIVE MAGNET',
                        () => game.developerGrantBoost('magnet')),
                    testButton(Icons.arrow_downward, 'DROP TRINITY',
                        () => game.developerGrantBoost('trinity', drop: true)),
                    testButton(Icons.arrow_downward, 'DROP CHAIN',
                        () => game.developerGrantBoost('arc', drop: true)),
                    testButton(Icons.arrow_downward, 'DROP PHOENIX',
                        () => game.developerGrantBoost('phoenix', drop: true)),
                  ]),
                  section('EXACT WAVE AND BOSS TEST',
                      'Choose any wave. Boss preview uses that chapter’s boss.'),
                  DropdownButton<int>(
                    value: chosenWave,
                    isExpanded: true,
                    dropdownColor: const Color(0xFF1A2947),
                    items: List.generate(CampaignChapter.finalWave, (i) {
                      final wave = i + 1;
                      return DropdownMenuItem<int>(
                        value: wave,
                        child: Text('WAVE $wave${wave % 5 == 0 ? "  •  BOSS" : ""}'),
                      );
                    }),
                    onChanged: (value) {
                      if (value != null) setSheetState(() => chosenWave = value);
                    },
                  ),
                  Wrap(spacing: 7, runSpacing: 5, children: [
                    testButton(Icons.flag_outlined, 'JUMP TO WAVE',
                        () => game.developerJumpToWave(chosenWave)),
                    testButton(Icons.local_fire_department, 'TEST BOSS',
                        () => game.developerJumpToWave(chosenWave, boss: true)),
                    testButton(Icons.skip_next, 'NEXT WAVE',
                        game.developerNextWave),
                  ]),
                  section('PLAYER AND COMBAT',
                      'Recover, test damage and shields, or restart this mode.'),
                  Wrap(spacing: 7, runSpacing: 5, children: [
                    testButton(Icons.favorite, 'HEAL FULL', game.developerHeal),
                    testButton(Icons.heart_broken_outlined, 'TAKE ONE HIT',
                        game.developerTestDamage),
                    testButton(Icons.restart_alt, 'RESTART', game.restartGame),
                    testButton(Icons.pause_circle_outline,
                        game.hud.value.paused ? 'RESUME GAME' : 'PAUSE GAME',
                        game.togglePause),
                  ]),
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: () => Navigator.pop(sheetContext),
                    icon: const Icon(Icons.check),
                    label: const Text('RETURN TO TEST'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  } finally {
    game.developerSetPanelOpen(false);
  }
  if (!context.mounted) return;
  switch (destination) {
    case _DevDestination.title:
      onMenu();
      return;
    case _DevDestination.arcade:
      onArcade();
      return;
    case _DevDestination.campaign:
      onCampaign();
      return;
    case _DevDestination.dragons:
      onChoose();
      return;
    case _DevDestination.howToPlay:
      _info(context, 'HOW TO PLAY',
          'Drag anywhere across the battlefield to fly. Your dragon attacks '
          'automatically. Dodge enemy attacks, survive waves and tap your '
          'special ability to unleash dragon magic. Switch dragons at any time.');
      return;
    case _DevDestination.about:
      _info(context, 'ABOUT THE GAME',
          'DRAGON LUNARYVELL is an original 2D portrait fantasy dragon arcade '
          'adventure with six playable dragon guardians and a five-act campaign.');
      return;
    case null:
      return;
  }
}
