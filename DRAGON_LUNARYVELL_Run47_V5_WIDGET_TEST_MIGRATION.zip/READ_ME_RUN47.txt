DRAGON LUNARYVELL · RUN 47 V5 — WIDGET TEST MIGRATION / SKY LEDGER
===============================================================

V5 addresses the root cause from RUN47_V4_DIAGNOSTICS.txt. The actual
Codespaces widget test was captured and its complete source inspected.
Its old campaign case was still checking the retired confirmation dialog
(THE SHATTERED MOONHEART, TAKE FLIGHT, and NOT YET). V5 replaces only that
test case with checks for the real painted PROLOGUE, SKIP SCENE, NEXT,
and the Leave story control. The existing title-menu test and all-six-
dragons test are retained unchanged. The tested production screen keeps
its premium gold Moonheart title but loses V4's redundant early button.
V5 uses the exact SHA-256 of the captured Codespaces test to ensure no
unrelated file is overwritten. This file is backed up and rolled back
with all other Run 46 code if verification or compilation fails.

All compiler/audio repairs, paintings, bosses, relics, soundtrack,
effects and dragon weapon audio remain intact. V4 already passed Dart
analysis with four nonblocking notices and passed 22 other Flutter tests.
V5 still needs the Flutter compiler and full suite in your Codespace.

What you are installing
-----------------------
1. Five-act narrative campaign (25 named waves), three-beat prologue,
   chapter dialogue, pre-boss dialogue and complete epilogue.
2. Six premium 2D story paintings, custom gold/sapphire dialogue frames,
   typewriter captions, speaker replay / voice toggle / SKIP SCENE.
3. Browser-provided English voice narration: no separate app, account,
   software or paid recording. Voice and timing depend on Android browser.
4. Five distinct boss ceremonial aura patterns, shield sigil fragments,
   improved telegraphed lane charge and phase/entry/victory title cards.
5. Ten power-up types, including triple spread fire, periodic phoenix wing
   spread, chain lightning, piercing bolts, time veil, healing and magnet.
6. Eight new transparent painted PNG relic sprites, original 48-second
   looping soundtrack, 19 individual OGG sounds (six tailored fire cues).
7. Multi-fire triggers ONE restrained dragon sound per third volley, not one
   sound per projectile. Boss and pickup sound effects are volume-limited.

Safe installation from your EXISTING GitHub Codespaces on Android
---------------------------------------------------------------
Upload DRAGON_LUNARYVELL_Run47_V5_WIDGET_TEST_MIGRATION.zip to the GitHub branch
dragon-lunaryvell-repairs first. Keep the ZIP in the repository root.
Then paste this ONE command in the existing Codespaces terminal:

cd /workspaces/dragon_arcade && test "$(git branch --show-current)" = "dragon-lunaryvell-repairs" && git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run47_V5_WIDGET_TEST_MIGRATION.zip && python3 run47_install.py

V2-V5 fix the confirmed 11 Dart extension-type errors. The package previously
declared Dart 3.0 while its browser speech/audio code needs Dart 3.3. It now
updates the Dart SDK lower bound and refreshes cached dependencies offline.
The remaining old-material-import notices are informational, not build errors.

It checks package hashes; refuses unknown custom baseline edits; runs Run
43-47 checks and full Flutter tests; attempts the same memory-friendlier
O2 release web build that worked for Run 46; tries debug only if release
fails; restores all previous Run 46 files and build/web if unsuccessful.

Your existing web preview server (port 8765) stays in place. When the
installer reports RUN47_RELEASE_READY, refresh that same forwarded tab.
You do not need a second terminal.

Suggested phone playtest
------------------------
* Tap Campaign: look for the six-dragon prologue and premium gold dialogue.
* Use speaker icon for narration on/off; replay button if Chrome was silent
  on scene open; NEXT advances; SKIP SCENE starts combat immediately.
  The final cinematic page also offers TAKE FLIGHT.
* Look at the new five chapter illustrations and pre-boss conversations.
* Tap the in-game volume icon; DRAG your dragon once if Chrome blocked music
  autoplay. Listen for low-volume loop + dragon-specific auto-fire timbre.
* DEV hub > ENEMIES AND POWER-UPS: GIVE/DROP TRINITY, PHOENIX, CHAIN,
  PIERCE, TIME VEIL, HEAL and MAGNET. Spread should shoot 3 arrows; Phoenix
  adds two wide wings every fourth volley, at most five bolts per firing.
* Check on-screen chips, sparkly illustrated relics and pickup chimes.
* DEV hub > EXACT WAVE AND BOSS TEST: wave 5/10/15/20/25; watch unique
  orbiting runes, shield break sigils, charged attack trails and phase cues.
* Continue after chapter waves into boss prelude and next act. Check no
  dialogue covers projectiles while active combat runs.
* Confirm the game remains responsive when 3 or 5-shot effects overlap.

What is and isn't verified yet
------------------------------
All artwork/audio files and Python preflight contracts passed in the
packaging environment. This environment has no Flutter SDK or Android
Chrome, so only your existing Codespace installer can certify the Dart
analysis, Flutter tests, JS compilation and actual phone voice playback.

If anything fails, leave the Codespace running only long enough to capture
the first useful error. The installer restores Run 46 automatically.
V5 also publishes RUN47_V5_DIAGNOSTICS.txt to GitHub automatically if anything
fails, without committing changed game source code.
You can simply tell ChatGPT it failed; the report should already be on GitHub.
