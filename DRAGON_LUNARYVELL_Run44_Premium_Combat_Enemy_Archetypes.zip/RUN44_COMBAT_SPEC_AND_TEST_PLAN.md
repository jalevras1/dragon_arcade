# DRAGON LUNARYVELL — Production Run 44

## Goal

The Run 43 projectiles were small animated glyphs (23×33 player, 22×22
enemy), with almost no movement trails, distinct hit feedback or muzzle
energy. Run 44 keeps those proven images as the inner sprite but paints
directional 2D magical ribbons, controlled glows, elemental ornament and
short, capped impact animations around them.

This is not a new asset atlas or 3D effect. It is fast 2D Flutter Canvas
rendering that is lightweight enough to attempt on Android Chrome.

## Locked enemy combat identities

| Enemy | Flight pattern | Attack/ability | Health and shield tier |
|---|---|---|---|
| Goblin Sky Raider | Tight quick jink | Single aimed skirmisher bolt | Light, no shield |
| Storm Harpy | Broad lateral strafe | Symmetric crossfire | Moderate, no shield |
| Shadow Wyvern | Wide dive with fast vertical pulse | High-speed aimed lance, later triple | Tough, gains a small elite shield at Wave 12 |
| Mooncrystal Gargoyle | Slow crystal patrol | Three-point rune fan; delayed shield recharge | Very tough; large crystalline overshield |
| Ember Manticore | Aggressive fast pounce | Paired ember shots; enrages under half health | Strong health, fast aggressive burst |
| Void Moth Wraith | Layered spectral weave | Alternating forked void magic and soft opacity veil | Tough; spectral overshield |

All paths are anchored to each enemy's spawn position to avoid frame-by-frame
drift. Each enemy owns a deterministic velocity profile and special volley.
Wave progression increases health, attack tempo and some shields, without
introducing enemies too early: the original first three appear at Wave 1,
Gargoyle/Manticore at Wave 4, and Void Moth at Wave 8.

## Readable combat graphics

- Player: six rune shapes (constellation star, jagged lightning, dragonfire,
  void crescent, solar rays, tidal helix) plus long tapered glow ribbons.
- Hostile: shorter, direction-aligned trails, family accent and warning rim.
- Impact: ring plus 4–6 motes, lasting 0.14s at the muzzle or 0.23s on hit.
- Overshield: compact second bar above the health bar and a slim magical arc
  around the creature. Shield takes incoming damage before health.
- Enrage/veil: visually telegraphed; no sudden sprite jumps or forced
  invulnerability.

## Safety

- Existing dragon sprites, Run 43 PNGs, bosses, stage backgrounds, UI,
  projectile speed for the player, and collision radii are preserved.
- New effects cannot change collision or damage rules. New enemy difficulty
  deliberately changes health/shield, volley patterns and species speed.
- Maximum 28 simultaneous muzzle/hit visuals and 36 regular enemy bolts.
- Run 44 installer guards every target using the Run 43 SHA-256 baseline,
  refuses conflicting custom edits, backs up every replaced file, and restores
  existing web output if compilation fails.

## Local checks completed and required remaining checks

The package preflight checks the retained Run 43 contracts and all new code
hooks. Dart/Flutter analysis, Flutter tests, web compilation and actual
Android-phone visual/performance testing must run in the user's Codespace;
the packaging environment does not contain the Flutter SDK.

Phone visual checklist:

1. Six dragons: auto-fire now has clearly different rune cores and moving
   tails; no blinding flashes or clipped trails.
2. Six enemy gallery: old and new art still displays, and the Gargoyle/Moth
   show a separate shield bar.
3. Normal waves: Goblin jinks; Harpy strafes/crossfires; Wyvern dives/lances;
   Gargoyle patrols/fans/recharges; Manticore pounces/enrages; Moth veils/forks.
4. Shoot armored enemies: shield bar decreases first, with a crystal hit ring;
   health begins falling after shield depletion.
5. Wave 5 boss and chapter transitions remain correct; pause, dragon switch,
   restart and touch movement continue working.
6. Watch phone frame rate and startup time; all effect lifetimes are bounded.
