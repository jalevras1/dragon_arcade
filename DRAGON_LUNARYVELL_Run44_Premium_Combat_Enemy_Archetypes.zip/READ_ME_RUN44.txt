DRAGON LUNARYVELL — RUN 44: PREMIUM PROJECTILES + ENEMY COMBAT IDENTITIES

Requires successfully installed Run 43 on branch dragon-lunaryvell-repairs.
Run 44 is an additive, guarded code update. It does not replace ANY existing
Run 43 images, dragon flight loops, boss art, backgrounds, menus, or saves.

WHAT CHANGES IN THE GAME
- All six player elements get layered, animated glowing 2D magical trails,
  distinct rune/energy motifs and small muzzle/impact feedback.
- All six enemy magics gain direction-aware trails and readable threat motifs.
- Three legacy enemies and three new Run 43 enemies each get one fixed flight
  signature, volley pattern, active ability and wave-scaled difficulty.
- Mooncrystal Gargoyle: crystal overshield + delayed recharge + triple fan.
- Void Moth Wraith: violet overshield + veiling shimmer + forked magic.
- Shadow Wyvern gets a small elite shield from Wave 12.
- Ember Manticore accelerates/fire rate rises when below half health.
- Small dual health/shield bars show up above armored enemies.
- Max 28 short-lived impact visuals and max 36 regular enemy bolts.

ONE-TERMINAL PHONE INSTALLATION
1. Download this ZIP to your Android phone.
2. Upload/commit the ZIP to the ROOT of your CURRENT GitHub branch:
   https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs
3. Paste the following as ONE command in your existing Codespaces terminal:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run44_Premium_Combat_Enemy_Archetypes.zip && python3 run44_install.py

4. Wait for RUN 44 COMPLETE. Refresh your existing game in port 8765.
5. Select each dragon and examine auto-fire + brief impact; use DEV > ALL SIX
   ENEMIES for a six-creature gallery. For MOVEMENT/ATTACK/SHIELD behavior,
   use normal gameplay (the static DEV gallery intentionally holds position).
   Wave 4 introduces Gargoyle/Manticore, Wave 8 Moth, Wave 12 elite Wyvern.

The installer refuses unknown file hashes and wrong branches, saves original
files, runs Run 35–44 checks, Flutter analysis, widget/rules tests, and a new
web release. On failure it restores previous Run 43 source/build.

Do NOT delete existing backups or overwrite unrelated game files. If the
installer prints STOP or FAILED, report the terminal message without trying
to force an install or reset Git.

The visual effects are efficient code-native 2D Canvas work layered over
existing 84 Run 43 transparent sprites. They create moving trails and glows
without a new atlas or extra asset loading at launch.
