#!/usr/bin/env python3
"""Read-only Run 44 structural guard, including retained Run 43 contracts."""

from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
game = (ROOT / 'lib/game/dragon_lunaryvell_game.dart').read_text()
fx = (ROOT / 'lib/game/premium_projectile_fx.dart').read_text()
enemy = (ROOT / 'lib/game/enemy_archetypes.dart').read_text()
test = (ROOT / 'test/run44_premium_projectile_fx_test.dart').read_text()
enemy_test = (ROOT / 'test/run44_enemy_archetypes_test.dart').read_text()

for term in [
    "import 'premium_projectile_fx.dart';",
    'PremiumProjectileFx.drawPlayerUnderlay(',
    'PremiumProjectileFx.drawPlayerOverlay(',
    'PremiumProjectileFx.drawEnemyUnderlay(',
    'PremiumProjectileFx.drawEnemyOverlay(',
    'PremiumProjectileImpact(',
    '_projectileImpacts.removeWhere(',
    '_projectileImpacts.length >= 28',
    'PremiumProjectileFx.colorFor(bolt.dragonId)',
    'PremiumProjectileFx.colorFor(magicId)',
    "import 'enemy_archetypes.dart';",
    'EnemyArchetypes.forType(enemyType)',
    'archetype.horizontalOffset(',
    'archetype.verticalMultiplier(',
    'archetype.attackIntervalAtWave(_wave)',
    '_fireEnemyVolley(foe, archetype)',
    'foe.shieldHitRemaining = .24',
    'foe.shield = math.max(0.0, foe.shield - absorbed).toDouble()',
    '_drawEnemyStatus(canvas, foe)',
    'EnemyAbilityStyle.crystalRegeneration',
    'EnemyAbilityStyle.emberRage',
    'foe.shieldRecoverClock > 4.8',
    'foe.typeIndex == 5',
]:
    assert term in game, f'Run 44 missing gameplay hook: {term}'

for term in [
    'ui.Gradient.linear(', 'ui.Gradient.radial(',
    'math.atan2(velocity.dy, velocity.dx)',
    'void drawPlayerUnderlay(', 'void drawPlayerOverlay(',
    'void drawEnemyUnderlay(', 'void drawEnemyOverlay(',
    'class PremiumProjectileImpact', 'double get duration => muzzle ? .14 : .23;',
    "'astralis':", "'temperstryx':", "'ignivar':",
    "'nyxariel':", "'solarion':", "'aquaryth':",
]:
    assert term in fx, f'Run 44 missing visual contract: {term}'

assert 'all six approved dragon elements' in test
assert 'premium projectile painters record' in test
assert 'six enemy species have locked unique flight' in enemy_test
assert 'overshields are stronger and independent' in enemy_test
assert 'MaskFilter.blur' not in fx
assert 'saveLayer(' not in fx
assert len(re.findall(r'EnemyArchetype\(\s*id:', enemy)) == 6
for name in ('goblinJink', 'harpyStrafe', 'wyvernDive', 'crystalPatrol',
             'manticorePounce', 'voidWeave'):
    assert name in enemy, name
for name in ('aimed', 'harpyCrossfire', 'wyvernLance', 'crystalFan',
             'emberDouble', 'voidFork'):
    assert name in enemy, name
for name in ('evasiveJink', 'windCrossfire', 'huntingDive',
             'crystalRegeneration', 'emberRage', 'voidVeil'):
    assert name in enemy, name

# Run 43 projectile sprites, positions, damage, enemy roster and flight frames
# are deliberately retained. Only presentation and bounded feedback change.
for term in [
    '(_fxTime * 15).floor() % frames.length',
    '(_fxTime * 14).floor() % frames.length',
    'unawaited(_preloadRun43EnemiesAndMagic())',
    'final available = _wave >= 8 ? 6 : _wave >= 4 ? 5 : 3;',
    '_loadDragonArtwork(profile), _loadRun43PlayerMagic(profile.id)',
    'const shotSpeed = 165.0;',
    'if (_fireClock >= .22)',
    '_enemyRadii', '_enemySpriteSizes',
]:
    assert term in game, f'Run 43 behavior unintentionally changed: {term}'

# Ensure every projectile family has a visual treatment and no new long-lived
# particle system was added to the main update loop.
assert len(re.findall(r"case '(astralis|temperstryx|ignivar|nyxariel|solarion|aquaryth)':", fx)) == 6
assert 'final List<PremiumProjectileImpact> _projectileImpacts' in game
assert 'Color(0xFF' in fx
print('RUN 44 PREFLIGHT PASS — six magic motifs; directional trails; '
      'six locked enemy flight/volley archetypes; wave-scaled overshields; '
      'short hit effects; 28-effect cap; Run 43 assets retained.')
