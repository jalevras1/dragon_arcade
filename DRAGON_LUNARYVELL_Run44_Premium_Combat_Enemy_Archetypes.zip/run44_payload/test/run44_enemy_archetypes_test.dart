import 'package:flutter_test/flutter_test.dart';
import 'package:dragon_lunaryvell/game/enemy_archetypes.dart';

void main() {
  test('six enemy species have locked unique flight and attack identities', () {
    final all = EnemyArchetypes.all;
    expect(all.length, 6);
    expect(all.map((x) => x.id).toSet().length, 6);
    expect(all.map((x) => x.flight).toSet().length, 6);
    expect(all.map((x) => x.volley).toSet().length, 6);
    expect(all.map((x) => x.ability).toSet().length, 6);
    expect(all.map((x) => x.scoreReward).toSet().length, 6);
  });

  test('overshields are stronger and independent of health', () {
    final goblin = EnemyArchetypes.forType(0);
    final gargoyle = EnemyArchetypes.forType(3);
    final moth = EnemyArchetypes.forType(5);
    expect(goblin.shieldAtWave(1), 0);
    expect(gargoyle.shieldAtWave(4), greaterThan(2));
    expect(moth.shieldAtWave(8), greaterThan(1));
    expect(gargoyle.shieldAtWave(18), greaterThan(
        gargoyle.shieldAtWave(4)));
    expect(gargoyle.healthAtWave(18), greaterThan(
        gargoyle.healthAtWave(4)));
    expect(EnemyArchetypes.forType(2).shieldAtWave(11), 0);
    expect(EnemyArchetypes.forType(2).shieldAtWave(12), 1);
  });

  test('patterns remain smooth at 50 Hz and shot cadence stays bounded', () {
    for (final enemy in EnemyArchetypes.all) {
      for (var sample = 0; sample < 100; sample++) {
        final t = sample / 50.0;
        final current = enemy.horizontalOffset(t, 1.3);
        final next = enemy.horizontalOffset(t + .02, 1.3);
        expect((next - current).abs(), lessThan(6.0));
        expect(enemy.verticalMultiplier(t), inInclusiveRange(.7, 1.6));
      }
      expect(enemy.attackIntervalAtWave(99), greaterThanOrEqualTo(.85));
      expect(enemy.healthAtWave(15), greaterThan(enemy.healthAtWave(1)));
    }
  });
}
