import 'dart:ui' show Canvas, Offset, PictureRecorder;

import 'package:flutter_test/flutter_test.dart';
import 'package:dragon_lunaryvell/game/premium_projectile_fx.dart';

void main() {
  const dragonIds = [
    'astralis',
    'temperstryx',
    'ignivar',
    'nyxariel',
    'solarion',
    'aquaryth',
  ];

  test('all six approved dragon elements have a distinct color theme', () {
    final colors = dragonIds.map(PremiumProjectileFx.colorFor).toSet();
    expect(colors.length, 6);
    for (final id in dragonIds) {
      expect(PremiumProjectileFx.hasTheme(id), isTrue);
    }
    expect(PremiumProjectileFx.hasTheme('unknown_boss'), isFalse);
  });

  test('premium projectile painters record without changing game state', () {
    final recorder = PictureRecorder();
    final canvas = Canvas(recorder);
    for (var i = 0; i < dragonIds.length; i++) {
      final center = Offset(35.0 + i * 25, 55);
      final enemy = Offset(35.0 + i * 25, 145);
      PremiumProjectileFx.drawPlayerUnderlay(
          canvas, center, dragonIds[i], i * .14);
      PremiumProjectileFx.drawPlayerOverlay(
          canvas, center, dragonIds[i], i * .14);
      PremiumProjectileFx.drawEnemyUnderlay(
          canvas, enemy, const Offset(55, 165), dragonIds[i], i * .18);
      PremiumProjectileFx.drawEnemyOverlay(
          canvas, enemy, const Offset(55, 165), dragonIds[i], i * .18);
    }
    PremiumProjectileFx.drawEnemyUnderlay(canvas, const Offset(30, 220),
        const Offset(-50, 150), 'boss_fallback', 2.0);
    PremiumProjectileFx.drawEnemyOverlay(canvas, const Offset(30, 220),
        const Offset(-50, 150), 'boss_fallback', 2.0);
    final flash = PremiumProjectileImpact(
        const Offset(100, 100), PremiumProjectileFx.colorFor('ignivar'),
        muzzle: true);
    flash.render(canvas);
    flash.age = .1;
    flash.render(canvas);
    final impact = PremiumProjectileImpact(
        const Offset(50, 50), PremiumProjectileFx.colorFor('astralis'));
    impact.age = .12;
    impact.render(canvas);
    expect(flash.duration, lessThan(.15));
    expect(impact.duration, lessThan(.25));
    recorder.endRecording().dispose();
  });
}
