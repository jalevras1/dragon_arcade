import 'dart:math' as math;

/// The six ordinary enemies have fixed tactical identities. The definitions
/// below are their single source of truth, independent of visual sprite files.
enum EnemyFlightStyle {
  goblinJink,
  harpyStrafe,
  wyvernDive,
  crystalPatrol,
  manticorePounce,
  voidWeave,
}

enum EnemyVolleyStyle {
  aimed,
  harpyCrossfire,
  wyvernLance,
  crystalFan,
  emberDouble,
  voidFork,
}

enum EnemyAbilityStyle {
  evasiveJink,
  windCrossfire,
  huntingDive,
  crystalRegeneration,
  emberRage,
  voidVeil,
}

class EnemyArchetype {
  const EnemyArchetype({
    required this.id,
    required this.title,
    required this.flight,
    required this.volley,
    required this.ability,
    required this.baseHealth,
    required this.baseShield,
    required this.speedFactor,
    required this.fireInterval,
    required this.scoreReward,
  });

  final String id, title;
  final EnemyFlightStyle flight;
  final EnemyVolleyStyle volley;
  final EnemyAbilityStyle ability;
  final double baseHealth, baseShield, speedFactor, fireInterval;
  final int scoreReward;

  double healthAtWave(int wave) =>
      baseHealth + (math.max(0, wave - 1) ~/ 4) * .75;

  double shieldAtWave(int wave) {
    if (baseShield > 0) {
      return baseShield + (math.max(0, wave - 1) ~/ 7) * .5;
    }
    // Late-campaign shadow wyverns become an elite skirmisher variant.
    if (flight == EnemyFlightStyle.wyvernDive && wave >= 12) return 1;
    return 0;
  }

  double attackIntervalAtWave(int wave) =>
      math.max(.85, fireInterval - math.max(0, wave - 1) * .025).toDouble();

  /// Smooth periodic paths are anchored to an enemy's own spawn x-position.
  /// No random lateral teleport, sprite scaling, or frame-dependent drift.
  double horizontalOffset(double time, double phase) {
    switch (flight) {
      case EnemyFlightStyle.goblinJink:
        return 19 * math.sin(time * 3.4 + phase) +
            8 * math.sin(time * 6.8 + phase * .8);
      case EnemyFlightStyle.harpyStrafe:
        return 46 * math.sin(time * 2.05 + phase) +
            7 * math.sin(time * 4.1 + phase);
      case EnemyFlightStyle.wyvernDive:
        return 28 * math.sin(time * 1.35 + phase) +
            14 * math.sin(time * .57 + phase);
      case EnemyFlightStyle.crystalPatrol:
        return 15 * math.sin(time * 1.05 + phase);
      case EnemyFlightStyle.manticorePounce:
        return 42 * math.sin(time * 2.8 + phase) +
            9 * math.sin(time * 5.6 + phase);
      case EnemyFlightStyle.voidWeave:
        return 34 * math.sin(time * 1.7 + phase) +
            15 * math.sin(time * 4.6 + phase * .5);
    }
  }

  double verticalMultiplier(double time) {
    switch (flight) {
      case EnemyFlightStyle.wyvernDive:
        final pulse = math.max(0.0, math.sin(time * 1.7));
        return 1 + .48 * pulse;
      case EnemyFlightStyle.manticorePounce:
        final pulse = math.sin(time * 2.2);
        return .88 + .45 * pulse * pulse;
      case EnemyFlightStyle.voidWeave:
        return .88 + .16 * (1 + math.sin(time * 1.2));
      default:
        return 1;
    }
  }
}

class EnemyArchetypes {
  EnemyArchetypes._();

  static const all = <EnemyArchetype>[
    EnemyArchetype(
      id: 'goblin_sky_raider', title: 'Goblin Sky Raider',
      flight: EnemyFlightStyle.goblinJink,
      volley: EnemyVolleyStyle.aimed,
      ability: EnemyAbilityStyle.evasiveJink,
      baseHealth: 1, baseShield: 0, speedFactor: 1.13,
      fireInterval: 2.1, scoreReward: 100),
    EnemyArchetype(
      id: 'storm_harpy', title: 'Storm Harpy',
      flight: EnemyFlightStyle.harpyStrafe,
      volley: EnemyVolleyStyle.harpyCrossfire,
      ability: EnemyAbilityStyle.windCrossfire,
      baseHealth: 2, baseShield: 0, speedFactor: 1.03,
      fireInterval: 1.8, scoreReward: 150),
    EnemyArchetype(
      id: 'shadow_wyvern', title: 'Shadow Wyvern',
      flight: EnemyFlightStyle.wyvernDive,
      volley: EnemyVolleyStyle.wyvernLance,
      ability: EnemyAbilityStyle.huntingDive,
      baseHealth: 2.8, baseShield: 0, speedFactor: .92,
      fireInterval: 1.9, scoreReward: 220),
    EnemyArchetype(
      id: 'crystal_gargoyle', title: 'Mooncrystal Gargoyle',
      flight: EnemyFlightStyle.crystalPatrol,
      volley: EnemyVolleyStyle.crystalFan,
      ability: EnemyAbilityStyle.crystalRegeneration,
      baseHealth: 4, baseShield: 2.5, speedFactor: .74,
      fireInterval: 2.4, scoreReward: 360),
    EnemyArchetype(
      id: 'ember_manticore', title: 'Ember Manticore',
      flight: EnemyFlightStyle.manticorePounce,
      volley: EnemyVolleyStyle.emberDouble,
      ability: EnemyAbilityStyle.emberRage,
      baseHealth: 3, baseShield: 0, speedFactor: 1.22,
      fireInterval: 1.6, scoreReward: 280),
    EnemyArchetype(
      id: 'void_moth', title: 'Void Moth Wraith',
      flight: EnemyFlightStyle.voidWeave,
      volley: EnemyVolleyStyle.voidFork,
      ability: EnemyAbilityStyle.voidVeil,
      baseHealth: 3.2, baseShield: 1.5, speedFactor: .96,
      fireInterval: 1.5, scoreReward: 330),
  ];

  static EnemyArchetype forType(int type) => all[type.clamp(0, 5).toInt()];
}
