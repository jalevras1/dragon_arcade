#!/usr/bin/env python3
"""Guarded repair of the 20 Run 32 dragon sprites; no source-code changes.

The Run 32 atlas extraction accidentally left four poses inside each PNG.
Run 33 then quarter-cropped those PNGs, leaving partial dragons. This pack
contains 20 individually extracted, checked 512x512 sprites. Installation
requires an exact Run 32 or Run 33 image match, backs up every current image,
and restores the backup if Flutter's web build fails.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import shutil
import subprocess
import tempfile
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image


PACK = Path(__file__).resolve().parent
ROOT = Path.cwd().resolve()
BACKUP_ROOT = ROOT / ".run34_backup"
ORIGINAL_ZIP = ROOT / "DRAGON_LUNARYVELL_Run32_Gameplay_Animations.zip"
ORIGINAL_ZIP_PREFIX = "DRAGON_LUNARYVELL_Run32_Gameplay_Animations/"
EXPECTED_BRANCH = "dragon-lunaryvell-repairs"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stop(message: str) -> None:
    print("\nRUN 34 STOPPED SAFELY: " + message, flush=True)
    raise SystemExit(2)


def image_info(data: bytes) -> tuple[tuple[int, int], str]:
    with Image.open(io.BytesIO(data)) as image:
        image.load()
        return image.size, image.mode


def atomic_write(data: bytes, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent,
                                     prefix=".run34_tmp_", delete=False) as temp:
        temp_path = Path(temp.name)
        temp.write(data)
    try:
        os.replace(temp_path, target)
    finally:
        temp_path.unlink(missing_ok=True)


def manifest() -> dict:
    data = json.loads((PACK / "manifest.json").read_text(encoding="utf-8"))
    old = data["original_run32_sha256"]
    new = data["repaired_run34_sha256"]
    found = {
        p.relative_to(PACK / "dragons").as_posix()
        for p in (PACK / "dragons").glob("*/flight/*.png")
    }
    if len(found) != 20 or found != set(old) or found != set(new):
        stop("The repair pack must contain exactly 20 expected sprite PNGs.")
    return data


def run32_reference(relative: str, expected_sha: str) -> bytes:
    backed_up = ROOT / ".run33_backup" / "assets/images/run32/dragons" / relative
    if backed_up.is_file():
        original = backed_up.read_bytes()
        if sha256(original) == expected_sha:
            return original
    if ORIGINAL_ZIP.is_file():
        try:
            with zipfile.ZipFile(ORIGINAL_ZIP) as archive:
                original = archive.read(ORIGINAL_ZIP_PREFIX +
                                        "dragons/" + relative)
            if sha256(original) == expected_sha:
                return original
        except (zipfile.BadZipFile, KeyError, OSError):
            pass
    stop("Could not verify the original Run 32 image for " + relative +
         ". Keep the existing art untouched and check your Run 33 backup.")


def matches_run33(current: bytes, original: bytes) -> bool:
    try:
        with Image.open(io.BytesIO(current)) as image:
            if image.size != (256, 256):
                return False
            actual = image.convert("RGBA").tobytes()
        with Image.open(io.BytesIO(original)) as image:
            expected = image.convert("RGBA").crop((0, 0, 256, 256)).tobytes()
        return actual == expected
    except (OSError, ValueError):
        return False


def preflight() -> tuple[list[tuple[Path, bytes, str]], Counter]:
    if not (ROOT / "pubspec.yaml").is_file():
        stop("Open your Flutter project folder (the one with pubspec.yaml).")
    source = ROOT / "lib/game/dragon_lunaryvell_game.dart"
    if not source.is_file() or "_run32DragonFlights" not in source.read_text(
        encoding="utf-8"
    ):
        stop("This game does not contain the Run 32 animation integration.")
    result = subprocess.run(["git", "branch", "--show-current"], cwd=ROOT,
                            capture_output=True, text=True, check=False)
    if result.returncode or result.stdout.strip() != EXPECTED_BRANCH:
        stop("Please use the existing " + EXPECTED_BRANCH + " branch.")

    hashes = manifest()
    replacements = []
    states = Counter()
    for relative, expected_old_hash in sorted(
        hashes["original_run32_sha256"].items()
    ):
        target = ROOT / "assets/images/run32/dragons" / relative
        source_image = PACK / "dragons" / relative
        if not target.is_file() or not source_image.is_file():
            stop("Missing game or repair image: " + relative)
        repaired = source_image.read_bytes()
        current = target.read_bytes()
        if sha256(repaired) != hashes["repaired_run34_sha256"][relative]:
            stop("Repair image failed checksum: " + relative)
        if image_info(repaired) != ((512, 512), "RGBA"):
            stop("Repair image must be 512x512 transparent RGBA: " + relative)
        if sha256(current) == sha256(repaired):
            state = "already repaired"
        elif sha256(current) == expected_old_hash:
            state = "original Run 32 atlas"
        elif image_info(current)[0] == (256, 256):
            original = run32_reference(relative, expected_old_hash)
            if not matches_run33(current, original):
                stop("A Run 33 image has other changes: " + relative)
            state = "Run 33 quarter-crop"
        else:
            stop("Unrecognized image contents: " + relative +
                 ". Your image will not be overwritten.")
        states[state] += 1
        replacements.append((target, repaired, state))
    return replacements, states


def make_backup(files: list[tuple[Path, bytes, str]]) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
    location = BACKUP_ROOT / stamp
    location.mkdir(parents=True, exist_ok=False)
    for target, _, _ in files:
        relative = target.relative_to(ROOT)
        original = location / relative
        original.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, original)
    return location


def restore(files: list[tuple[Path, bytes, str]], backup: Path) -> None:
    for target, _, _ in files:
        original = backup / target.relative_to(ROOT)
        if not original.is_file():
            stop("Backup is incomplete: " + original.name)
        atomic_write(original.read_bytes(), target)
    print("RUN 34: previous 20 images safely restored.", flush=True)


def rollback() -> None:
    marker = BACKUP_ROOT / "latest.json"
    if not marker.is_file():
        stop("No successful Run 34 installation backup was found.")
    stamp = json.loads(marker.read_text(encoding="utf-8"))["stamp"]
    backup = BACKUP_ROOT / stamp
    hashes = manifest()["repaired_run34_sha256"]
    files = []
    for relative in sorted(hashes):
        target = ROOT / "assets/images/run32/dragons" / relative
        original = backup / target.relative_to(ROOT)
        if (not target.is_file() or not original.is_file() or
                sha256(target.read_bytes()) != hashes[relative]):
            stop("Cannot roll back modified or missing art: " + relative)
        files.append((target, b"", ""))
    restore(files, backup)
    print("RUN 34 ROLLBACK COMPLETE. Gameplay code was never modified.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Safe Run 34 dragon sprite repair")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--rollback", action="store_true")
    parser.add_argument("--skip-flutter-build", action="store_true",
                        help="For offline installer testing only")
    args = parser.parse_args()
    if args.rollback:
        rollback()
        return
    files, states = preflight()
    print("RUN 34 PRECHECK PASSED: 20 verified dragon frames.", flush=True)
    print("CURRENT ART:", dict(states), flush=True)
    if args.dry_run:
        print("RUN 34 DRY RUN COMPLETE. Nothing changed.")
        return
    if len(states) == 1 and states["already repaired"] == 20:
        print("RUN 34 ALREADY INSTALLED. Nothing changed.")
        return
    if not args.skip_flutter_build and not shutil.which("flutter"):
        stop("Flutter is not available; nothing was changed.")

    backup = make_backup(files)
    try:
        for target, data, _ in files:
            atomic_write(data, target)
        if args.skip_flutter_build:
            print("RUN 34: Flutter build skipped for offline staging.")
        else:
            print("RUN 34: rebuilding Flutter web using corrected sprites...",
                  flush=True)
            compiled = subprocess.run(["flutter", "build", "web", "--release"],
                                      cwd=ROOT, timeout=720, check=False)
            if compiled.returncode:
                raise RuntimeError("Flutter web build failed (exit " +
                                   str(compiled.returncode) + ")")
    except BaseException as error:
        restore(files, backup)
        print("RUN 34 BUILD FAILED; ORIGINAL SPRITES RESTORED:", error)
        raise SystemExit(3)

    BACKUP_ROOT.mkdir(exist_ok=True)
    (BACKUP_ROOT / "latest.json").write_text(
        json.dumps({"stamp": backup.name}), encoding="utf-8"
    )
    print("\nRUN 34 COMPLETE: all five dragons now use isolated flight poses.")
    print("ASTRALIS animation, projectile art, combat and existing code unchanged.")
    print("Next: refresh the web preview and visually test each dragon.")
    print("Do not commit until that phone test succeeds.")


if __name__ == "__main__":
    main()
