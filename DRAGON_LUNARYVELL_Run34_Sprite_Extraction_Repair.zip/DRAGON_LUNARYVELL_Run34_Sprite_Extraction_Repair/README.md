# DRAGON LUNARYVELL — Run 34 sprite extraction repair

This is the corrected, **image-only** follow-up to Run 32 and the unsuccessful
Run 33 quarter-crop. The earlier packaged 512×512 "frames" still contained
most of a 2×2 atlas. Run 33 then cropped their top-left quarters, leaving
disconnected dragon wings and bodies on screen.

Run 34 instead goes back to the five **original source atlases** and extracts
four independent quadrant poses from each one. All 20 resulting PNGs are
512×512 with RGBA transparency and consistent positioning. One minor spillover
fragment at the left edge of each fourth pose is removed mechanically. No
additional AI artwork was generated.

All five dragon cycles: **TEMPESTRYX, IGNIVAR, NYXARIEL, SOLARION, AQUARYTH**.
**ASTRALIS, projectiles, enemies, abilities, boss art, HUD, and all code remain
unchanged.**

## On your phone — one Codespaces terminal

1. Download `DRAGON_LUNARYVELL_Run34_Sprite_Extraction_Repair.zip` and upload
   that single ZIP to GitHub branch `dragon-lunaryvell-repairs` as before.
2. Return to the terminal in `/workspaces/dragon_arcade` and run:

   ```bash
   git pull --ff-only origin dragon-lunaryvell-repairs && unzip -nq DRAGON_LUNARYVELL_Run34_Sprite_Extraction_Repair.zip && python3 DRAGON_LUNARYVELL_Run34_Sprite_Extraction_Repair/install_run34.py
   ```

The installer checks all 20 images against the exact old Run 32 bytes or the
exact Run 33 quarter-crops, using `.run33_backup/` or your Run 32 ZIP as the
reference. It refuses to overwrite an unexpected image, creates a new
`.run34_backup/`, installs the corrected sprites, and runs `flutter build web
--release`. If installation or build fails, all 20 previous images are
restored automatically. It does **not** change any Dart file or `pubspec.yaml`.

3. Only when the terminal prints **RUN 34 COMPLETE**, test your updated web
   preview on the same Codespaces port used previously (8765). If the old
   preview is cached, refresh after the new build. Check all five dragons.
4. If all five show exactly one complete body and smooth wing motion, commit
   and push **only** `assets/images/run32/dragons/` as the new stable backup.

### Optional safety controls

Dry-run verification without changing files:

```bash
python3 DRAGON_LUNARYVELL_Run34_Sprite_Extraction_Repair/install_run34.py --dry-run
```

Undo a completed installation (only if the corrected images were not changed
again afterward):

```bash
python3 DRAGON_LUNARYVELL_Run34_Sprite_Extraction_Repair/install_run34.py --rollback
```

### Verification performed before packaging

- The Run 34 files were generated from the original image atlases by explicit
  quadrant pixel coordinates, not the faulty `-crop 2x2@` extraction.
- Each of the 20 images has exactly one main connected dragon silhouette at
  alpha greater than 96; none touches the outer 12-pixel border.
- All 20 PNGs are RGBA at exactly 512×512 pixels.
- Every four-frame cycle was visually inspected against the game's dark navy
  background and shows distinct folded, intermediate, extended and lowered
  wing positions with the full dragon body intact.
- An offline staging test successfully detected the actual Run 33 256×256
  quarter-crops, installed all 20 replacements, verified idempotence, and
  restored the pre-repair images on rollback.
- Flutter itself is **not available** in this preparation workspace, so the
  installer performs the real web build inside your existing Codespace.
