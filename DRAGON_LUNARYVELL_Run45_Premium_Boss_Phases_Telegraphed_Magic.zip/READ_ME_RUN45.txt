DRAGON LUNARYVELL — RUN 45: PREMIUM BOSS ENCOUNTERS
===================================================

BASED ON YOUR WORKING RUN 44. NO EXTRA APPS OR PAID SERVICES.

WHAT CHANGES
- Five existing animated boss sprites now control five different flight
  and attack identities instead of sharing the old aimed-three-shot loop.
- Each boss has GUARDED / AWAKENED / UNLEASHED health phases. The phase
  labels are shown as GUARDED, AWAKENED and UNLEASHED in the game HUD.
- Boss volleys are locked and visually telegraphed BEFORE the shots fire;
  changing direction during the warning cannot make them track you.
- Crystal, Moonveil, Frost and Eclipse bosses have separate magic shields;
  the Ashen Drake trades shields for faster, more aggressive attacks.
- Short shield-hit/phase-rune/defeat effects and 36-enemy-shot upper bound.
- Outdated extracted Run payload folders are excluded from whole-project
  Flutter analysis, without deleting any assets or code.
- Regular enemies, six playable dragons, existing bosses' 8-frame PNGs,
  campaign, menus, background transitions, tests and controls remain.

INSTALLATION — SAME PHONE + CODESPACES WORKFLOW
1. Download DRAGON_LUNARYVELL_Run45_Premium_Boss_Phases_Telegraphed_Magic.zip
   from ChatGPT.
2. Upload the ZIP to the ROOT of the dragon-lunaryvell-repairs branch here:
   https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs
   Tap COMMIT CHANGES.
3. In your existing Codespace's project-root terminal, paste ONE command:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run45_Premium_Boss_Phases_Telegraphed_Magic.zip && python3 run45_install.py

4. Wait for: RUN 45 COMPLETE — Five premium boss encounters ready.
5. Refresh your existing port 8765 phone game tab; keep using the
   same web server. No new terminal or port is necessary.

WHAT TO TEST
- DEV TEST HUB: Boss at Waves 5, 10, 15, 20, 25.
- Watch their movements and the light warning lanes before each volley.
- Damage each boss into 65% and 30% health; notice phase labels, faster
  patterns, restrained runes and distinct moon/ice/ember arrangements.
- Crystal/frost/moon/eclipse shield bar must disappear BEFORE health drops.
- Defeat wave 5 and verify the next chapter transition, then verify
  the live six regular enemy types and existing dragon special abilities.
- Check that projectiles and warnings remain readable on your phone.

SAFETY
The installer validates file hashes, existing Run 44 source, Run 43-45
structural checks, Flutter analysis, Flutter tests and release web build.
It creates a versioned .run45_backups folder and restores the previous
Run 44 code + web build if any required check fails.
If a STOP or FAILED message appears, do not force-install; send the
terminal result to ChatGPT. Custom edits are protected.

NOTE: Full Flutter tests and compilation occur in your Codespace, not
in the preparation workspace, which does not have the Flutter SDK.
