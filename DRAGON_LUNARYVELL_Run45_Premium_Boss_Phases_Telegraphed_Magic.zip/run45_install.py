#!/usr/bin/env python3
"""Guarded Run 45 boss overhaul over the verified working Run 44."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path, PurePosixPath
import argparse
import json
import shutil
import subprocess
import sys


ROOT = Path.cwd().resolve()
EXPECTED_BRANCH = 'dragon-lunaryvell-repairs'


def digest(path: Path) -> str:
    h = sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def checked(relative: str) -> Path:
    entry = PurePosixPath(relative)
    if entry.is_absolute() or '..' in entry.parts or not entry.parts:
        raise ValueError('Unsafe update path: ' + relative)
    for n in range(1, len(entry.parts) + 1):
        if ROOT.joinpath(*entry.parts[:n]).is_symlink():
            raise ValueError('Refusing symlink update path: ' + relative)
    return ROOT.joinpath(*entry.parts)


def run(command: list[str], timeout: int) -> None:
    print('Verifying:', ' '.join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True, timeout=timeout)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--skip-build', action='store_true',
                        help='Installer QA only; no Flutter web preview made')
    args = parser.parse_args()
    if not (ROOT / '.git').is_dir() or not (ROOT / 'pubspec.yaml').is_file():
        print('STOP: Run this inside your existing dragon_arcade Codespaces terminal.')
        return 2
    branch = subprocess.check_output(
        ['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip()
    if branch != EXPECTED_BRANCH:
        print('STOP: Wrong branch:', branch)
        return 2
    manifest_path = ROOT / 'run45_manifest.json'
    if not manifest_path.is_file():
        print('STOP: Extract the Run 45 ZIP before running this installer.')
        return 2
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('run') != 45 or manifest.get('branch') != EXPECTED_BRANCH:
        print('STOP: Unrecognized Run 45 manifest.')
        return 2
    flutter = shutil.which('flutter')
    if not args.skip_build and not flutter:
        candidate = Path.home() / 'flutter/bin/flutter'
        flutter = str(candidate) if candidate.is_file() else None
    if not args.skip_build and not flutter:
        print('STOP: Flutter unavailable. No files changed.')
        return 2

    pending: list[tuple[str, Path, Path]] = []
    for entry in manifest['files']:
        rel = entry['path']
        target = checked(rel)
        source = checked('run45_payload/' + rel)
        if not source.is_file() or digest(source) != entry['new_sha256']:
            print('STOP: Run 45 package integrity failed:', rel)
            return 2
        old_hashes = entry.get('accepted_old_sha256', [entry.get('old_sha256')])
        if target.is_file():
            old_hash = digest(target)
            if old_hash == entry['new_sha256']:
                continue
            if old_hash not in old_hashes:
                print('STOP: Existing custom work protected:', rel)
                print('No files changed; send this message to ChatGPT.')
                return 2
        elif None not in old_hashes:
            print('STOP: Expected Run 44 baseline file absent:', rel)
            return 2
        pending.append((rel, source, target))

    if not pending:
        print('RUN 45 FILES ALREADY INSTALLED. Refresh the existing 8765 tab.')
        return 0

    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    backup = ROOT / '.run45_backups' / stamp
    previous_web = backup / 'previous_web'
    build = ROOT / 'build/web'
    backup.mkdir(parents=True)
    originals: list[tuple[str, Path, bool]] = []
    moved_web = False
    try:
        for rel, _, target in pending:
            exists = target.is_file()
            originals.append((rel, target, exists))
            if exists:
                saved = backup / 'original_files' / rel
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
        for _, source, target in pending:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)

        # Run 41 inspected the old boss attack behavior, which Run 45
        # intentionally replaces. Later contract verifiers still protect
        # the existing dragons, wave enemies, effects, and sprite assets.
        for phase in (43, 44, 45):
            run([sys.executable, f'tools/run{phase}_verify.py'], 150)

        if not args.skip_build:
            run([flutter, 'analyze', '--no-fatal-infos',
                 '--no-fatal-warnings',
                 'lib/game/dragon_lunaryvell_game.dart',
                 'lib/game/boss_encounter_rules.dart',
                 'lib/game/boss_encounter_fx.dart',
                 'lib/game/premium_projectile_fx.dart',
                 'lib/game/enemy_archetypes.dart',
                 'test/run44_premium_projectile_fx_test.dart',
                 'test/run44_enemy_archetypes_test.dart',
                 'test/run45_boss_encounters_test.dart'], 420)
            run([flutter, 'test', 'test/widget_test.dart',
                 'test/special_ability_rules_test.dart',
                 'test/campaign_story_test.dart',
                 'test/dragon_flight_cycle_test.dart',
                 'test/run44_premium_projectile_fx_test.dart',
                 'test/run44_enemy_archetypes_test.dart',
                 'test/run45_boss_encounters_test.dart'], 420)
            if build.is_dir():
                shutil.move(str(build), str(previous_web))
                moved_web = True
            run([flutter, 'build', 'web', '--release', '--no-pub',
                 '--dart-define=DL_DEV_TOOLS=true',
                 '--dart-define=DL_TEST_BUILD=RUN45'], 900)
            if not (build / 'index.html').is_file():
                raise RuntimeError('Flutter did not create build/web/index.html')

        (backup / 'SUCCESS.txt').write_text('Run 45 original files saved; ' +
            ('structural checks passed; build skipped\n' if args.skip_build else
             'all tests passed and web release built\n'))
        print('\nRUN 45 COMPLETE — Five premium boss encounters ready.')
        print('Previous working files saved under', backup.relative_to(ROOT))
        if args.skip_build:
            print('NOTE: --skip-build did not create a playable web preview.')
        else:
            print('Refresh the SAME 8765 tab. No second terminal is needed.')
        return 0
    except BaseException as error:
        print('\nRUN 45 FAILED:', error)
        print('Restoring previous Run 44 code and web build...', flush=True)
        for rel, target, previously_existed in reversed(originals):
            if previously_existed:
                saved = backup / 'original_files' / rel
                if saved.is_file():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(saved, target)
            elif target.is_file():
                target.unlink()
        if moved_web:
            if build.is_dir():
                shutil.rmtree(build)
            shutil.move(str(previous_web), str(build))
        print('ROLLBACK COMPLETE — prior working Run 44 version restored.')
        return 1


if __name__ == '__main__':
    sys.exit(main())
