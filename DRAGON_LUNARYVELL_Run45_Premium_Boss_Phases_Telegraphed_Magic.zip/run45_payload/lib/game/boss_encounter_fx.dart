import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'boss_encounter_rules.dart';

/// Small bounded Canvas effects layered over the existing eight-frame boss
/// sprites. No new textures, blur filters, offscreen layers or giant flashes.
class BossEncounterFx {
  static const hues = <Color>[
    Color(0xFF8DDFFF),
    Color(0xFFFF9A69),
    Color(0xFFCEABFF),
    Color(0xFF90EBEF),
    Color(0xFFFFD37A),
  ];

  static Color hue(int wave) =>
      hues[BossEncounterRules.chapterForWave(wave)];

  static void drawAura(Canvas canvas, Offset center, {
    required int wave,
    required double seconds,
    required BossCombatPhase phase,
    required double shieldFraction,
    required double hitPulse,
    required double phasePulse,
  }) {
    final tint = hue(wave);
    final chapter = BossEncounterRules.chapterForWave(wave);
    final ringRadius = 56.0 + math.sin(seconds * 2) * 2.2;
    canvas.drawCircle(
        center,
        68,
        Paint()
          ..shader = ui.Gradient.radial(center, 68, [
            tint.withValues(alpha: .14 + phasePulse * .14),
            tint.withValues(alpha: 0),
          ]));
    final arcs = phase == BossCombatPhase.unleashed ? 3 : 2;
    for (var i = 0; i < arcs; i++) {
      canvas.drawArc(
          Rect.fromCircle(center: center, radius: ringRadius + i * 5),
          seconds * (i.isEven ? .62 : -.48) + i * 2.1,
          1.05 + phase.index * .12,
          false,
          Paint()
            ..color = tint.withValues(alpha: .35 + phasePulse * .27)
            ..strokeWidth = 1.45
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke);
    }
    // The five chapters retain distinct ornaments even with fallback art.
    final count = <int>[4, 6, 5, 6, 7][chapter];
    for (var i = 0; i < count; i++) {
      final angle = seconds * (chapter == 3 ? -.17 : .21) +
          2 * math.pi * i / count;
      final orbit = 64 + math.sin(seconds * 1.8 + i * 1.9) * 1.8;
      final p = Offset(center.dx + math.cos(angle) * orbit,
          center.dy + math.sin(angle) * orbit * .75);
      final sparkle = 2.2 + (phase.index == 2 ? .6 : 0);
      final rune = Path()
        ..moveTo(p.dx, p.dy - sparkle * 1.5)
        ..lineTo(p.dx + sparkle, p.dy)
        ..lineTo(p.dx, p.dy + sparkle * 1.5)
        ..lineTo(p.dx - sparkle, p.dy)
        ..close();
      canvas.drawPath(rune,
          Paint()..color = tint.withValues(alpha: .52));
    }
    if (shieldFraction > 0) {
      canvas.drawArc(
          Rect.fromCircle(center: center, radius: 47),
          -math.pi / 2,
          2 * math.pi * shieldFraction,
          false,
          Paint()
            ..color = tint.withValues(alpha: .48)
            ..strokeWidth = 2.2
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke);
    }
    if (hitPulse > 0 || phasePulse > 0) {
      final energy = math.max(hitPulse, phasePulse * .55);
      canvas.drawCircle(
          center,
          42 + (1 - energy) * 18,
          Paint()
            ..color = tint.withValues(alpha: energy * .42)
            ..strokeWidth = 1.8
            ..style = PaintingStyle.stroke);
    }
  }

  static void drawCharge(Canvas canvas, Offset bossCenter,
      List<BossShotVector> shots, double chargeProgress, int wave,
      double seconds) {
    if (shots.isEmpty) return;
    final tint = hue(wave);
    final reveal = chargeProgress.clamp(0.0, 1.0).toDouble();
    final pulse = (.58 + .19 * math.sin(seconds * 17)) * reveal;
    final origin = Offset(bossCenter.dx, bossCenter.dy + 37);
    for (final shot in shots) {
      final vx = shot.vx;
      final vy = shot.vy;
      final length = math.max(1.0, math.sqrt(vx * vx + vy * vy));
      final from = Offset(origin.dx + shot.sourceDx, origin.dy);
      final travel = 72 + reveal * 82;
      final to = Offset(from.dx + vx / length * travel,
          from.dy + vy / length * travel);
      canvas.drawLine(
          from,
          to,
          Paint()
            ..color = tint.withValues(alpha: pulse * .37)
            ..strokeWidth = 1.6
            ..strokeCap = StrokeCap.round);
      canvas.drawCircle(to, 2.2,
          Paint()..color = tint.withValues(alpha: pulse * .75));
    }
    canvas.drawCircle(
        origin,
        10 + reveal * 7,
        Paint()
          ..color = tint.withValues(alpha: .45 * reveal)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.7);
    canvas.drawCircle(origin, 3.5 + reveal * 2,
        Paint()..color = Colors.white.withValues(alpha: .60 * reveal));
  }

  static void drawStatus(Canvas canvas, {
    required double battlefieldWidth,
    required String bossName,
    required int wave,
    required BossCombatPhase phase,
    required double health,
    required double maxHealth,
    required double shield,
    required double maxShield,
  }) {
    final hue = BossEncounterFx.hue(wave);
    final width = battlefieldWidth * .60;
    final left = battlefieldWidth * .20;
    final name = TextPainter(
        text: TextSpan(
            text: bossName,
            style: TextStyle(
                color: hue.withValues(alpha: .9),
                fontSize: 9.5,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w700)),
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: battlefieldWidth * .90);
    name.paint(canvas, Offset((battlefieldWidth - name.width) / 2, 32));

    final bar = RRect.fromRectAndRadius(
        Rect.fromLTWH(left, 54, width, 7), const Radius.circular(4));
    canvas.drawRRect(bar, Paint()..color = const Color(0xE9121A31));
    final healthRatio = (health / math.max(1, maxHealth)).clamp(0.0, 1.0)
        .toDouble();
    if (healthRatio > 0) {
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(left, 54, width * healthRatio, 7),
              const Radius.circular(4)),
          Paint()
            ..shader = ui.Gradient.linear(
              Offset(left, 54), Offset(left + width, 54),
              [hue.withValues(alpha: .94), const Color(0xFFFFE8B0)],
            ));
    }
    // Permanently visible phase ticks teach players the boss's thresholds.
    for (final fraction in <double>[.30, .65]) {
      final x = left + width * fraction;
      canvas.drawLine(Offset(x, 54), Offset(x, 61),
          Paint()..color = const Color(0xBB121A31)..strokeWidth = 1.3);
    }
    if (maxShield > 0) {
      final percent = (shield / maxShield).clamp(0.0, 1.0).toDouble();
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(left, 47, width, 3.3),
              const Radius.circular(3)),
          Paint()..color = const Color(0xCC121A31));
      if (percent > 0) {
        canvas.drawRRect(
            RRect.fromRectAndRadius(
                Rect.fromLTWH(left, 47, width * percent, 3.3),
                const Radius.circular(3)),
            Paint()..color = hue.withValues(alpha: .85));
      }
    }
    final label = TextPainter(
        text: TextSpan(
            text: BossEncounterRules.phaseName(phase),
            style: TextStyle(
                color: hue.withValues(alpha: .68),
                fontSize: 8,
                letterSpacing: 1.45,
                fontWeight: FontWeight.w600)),
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: battlefieldWidth * .60);
    label.paint(canvas, Offset((battlefieldWidth - label.width) / 2, 65));
  }
}
