#!/usr/bin/env python3
"""Run 45 preflight: boss phases/telegraphs plus Run 44 preservation."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
game = (ROOT / 'lib/game/dragon_lunaryvell_game.dart').read_text()
rules = (ROOT / 'lib/game/boss_encounter_rules.dart').read_text()
fx = (ROOT / 'lib/game/boss_encounter_fx.dart').read_text()
tests = (ROOT / 'test/run45_boss_encounters_test.dart').read_text()

for hook in (
    "import 'boss_encounter_rules.dart';",
    "import 'boss_encounter_fx.dart';",
    'BossEncounterRules.horizontalOffset(',
    'BossEncounterRules.phaseForHealth(',
    'BossEncounterRules.attackInterval(',
    'BossEncounterRules.warningSeconds(',
    'BossEncounterRules.volley(',
    'BossEncounterRules.magicTypeForWave(',
    'BossEncounterRules.shieldForWave(_wave)',
    'BossEncounterFx.drawAura(',
    'BossEncounterFx.drawCharge(',
    'BossEncounterFx.drawStatus(',
    '_bossPreparedShots = <BossShotVector>[];',
    '_bossChargeRemaining = 0;',
    'if (_enemyBolts.length >= 36) break;',
    '_defeatBoss(boss);',
    '_summonBoss(instant: true);',
    'isBoss ? BossEncounterFx.hue(_wave) : _shieldTint(foe.typeIndex)',
):
    assert hook in game, f'Missing Run 45 integration hook: {hook}'

assert 'boss.hp -= 1;' not in game
assert 'BossCombatPhase.guarded' in game
assert 'BossCombatPhase.unleashed' in rules
assert len(re.findall(r"'(?:(?:ECLIPSE|ASHEN|MOONVEIL|FROST) [A-Z ]+)'", rules)) >= 5
for name in ('ECLIPSE GARGOYLE WARDEN', 'ASHEN DRAKE COLOSSUS',
             'MOONVEIL SERPENT', 'FROST HARPY MATRIARCH',
             'ECLIPSE SOVEREIGN'):
    assert name in rules
for name in ('Crystal Warden', 'Ashen Drake', 'Moonveil',
             'Frost Matriarch', 'Eclipse Sovereign'):
    assert name in rules
for hook in ('ui.Gradient.radial', 'ui.Gradient.linear',
             'void drawAura(', 'void drawCharge(', 'void drawStatus('):
    assert hook in fx
assert 'MaskFilter.blur' not in fx
assert 'saveLayer(' not in fx
assert 'boss phases change at readable health thresholds' in tests
assert 'boss flight does not jump' in tests

# Old gameplay is intentionally retained. Run 44's guard also verifies these.
for hook in ('_fireEnemyVolley(foe, archetype)',
             'EnemyAbilityStyle.crystalRegeneration',
             'PremiumProjectileFx.drawPlayerUnderlay(',
             '_drawEnemyStatus(canvas, foe)',
             'final available = _wave >= 8 ? 6 : _wave >= 4 ? 5 : 3;'):
    assert hook in game

options = ROOT / 'analysis_options.yaml'
if options.is_file():
    config = options.read_text()
    assert '- run*_payload/**' in config
    assert '- DRAGON_LUNARYVELL_Run32_Gameplay_Animations/**' in config

print('RUN 45 PREFLIGHT PASS — five illustrated boss identities, three '
      'readable phases, committed warning lanes, guarded shields, bounded '
      'volleys, brief defeat effects and preserved Run 44 combat.')
