import 'dart:ui' show Canvas, Offset, PictureRecorder;

import 'package:dragon_lunaryvell/game/boss_encounter_fx.dart';
import 'package:dragon_lunaryvell/game/boss_encounter_rules.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const waves = <int>[5, 10, 15, 20, 25];

  test('five bosses match chapter art with fixed elemental identities', () {
    expect(BossEncounterRules.names.length, 5);
    expect(BossEncounterRules.names.toSet().length, 5);
    expect(BossEncounterFx.hues.toSet().length, 5);
    expect(waves.map(BossEncounterRules.magicTypeForWave).toSet().length, 5);
    for (var chapter = 0; chapter < 5; chapter++) {
      expect(BossEncounterRules.chapterForWave(waves[chapter]), chapter);
      expect(BossEncounterRules.nameForWave(waves[chapter]),
          BossEncounterRules.names[chapter]);
    }
    expect(BossEncounterRules.shieldForWave(5), greaterThan(0));
    expect(BossEncounterRules.shieldForWave(10), 0);
    expect(BossEncounterRules.shieldForWave(20), greaterThan(10));
  });

  test('boss phases change at readable health thresholds', () {
    expect(BossEncounterRules.phaseForHealth(100, 100),
        BossCombatPhase.guarded);
    expect(BossEncounterRules.phaseForHealth(65, 100),
        BossCombatPhase.awakened);
    expect(BossEncounterRules.phaseForHealth(30, 100),
        BossCombatPhase.unleashed);
    for (final phase in BossCombatPhase.values) {
      expect(BossEncounterRules.phaseName(phase), isNotEmpty);
      for (final wave in waves) {
        expect(BossEncounterRules.warningSeconds(wave, phase),
            greaterThanOrEqualTo(.38));
        expect(BossEncounterRules.attackInterval(wave, phase),
            greaterThanOrEqualTo(.74));
      }
    }
  });

  test('each chapter has distinct bounded volleys that travel downward', () {
    final profiles = <String>{};
    for (final wave in waves) {
      for (final phase in BossCombatPhase.values) {
        for (var turn = 0; turn < 2; turn++) {
          final shots = BossEncounterRules.volley(
              wave: wave,
              phase: phase,
              originX: 180,
              originY: 190,
              targetX: 225,
              targetY: 715,
              volleyIndex: turn);
          expect(shots.length, inInclusiveRange(3, 7));
          for (final shot in shots) {
            expect(shot.sourceDx.isFinite, isTrue);
            expect(shot.vx.isFinite, isTrue);
            expect(shot.vy, greaterThan(0));
          }
          if (phase == BossCombatPhase.unleashed && turn == 0) {
            profiles.add('${shots.length}:'
                '${shots.first.sourceDx.toStringAsFixed(1)}:'
                '${shots.first.vx.toStringAsFixed(1)}:'
                '${shots.first.vy.toStringAsFixed(1)}');
          }
        }
      }
    }
    expect(profiles.length, 5);
  });

  test('boss flight does not jump between 50Hz frames', () {
    for (final wave in waves) {
      expect(BossEncounterRules.horizontalOffset(wave, 0, 390), 0);
      for (var frame = 0; frame < 250; frame++) {
        final time = frame / 50;
        final x = BossEncounterRules.horizontalOffset(wave, time, 390);
        final next = BossEncounterRules.horizontalOffset(
            wave, time + .02, 390);
        expect((next - x).abs(), lessThan(6));
        expect(x.abs(), lessThan(390 * .28));
      }
    }
  });

  test('boss aura, health/shield HUD and warnings paint without layers', () {
    final recorder = PictureRecorder();
    final canvas = Canvas(recorder);
    for (var index = 0; index < waves.length; index++) {
      final wave = waves[index];
      final center = Offset(195, 160 + index * 110.0);
      final shots = BossEncounterRules.volley(
        wave: wave,
        phase: BossCombatPhase.awakened,
        originX: center.dx,
        originY: center.dy + 34,
        targetX: 170,
        targetY: 700,
        volleyIndex: 1,
      );
      BossEncounterFx.drawAura(canvas, center,
          wave: wave, seconds: index * .3,
          phase: BossCombatPhase.awakened, shieldFraction: .5,
          hitPulse: .2, phasePulse: .3);
      BossEncounterFx.drawCharge(
          canvas, center, shots, .73, wave, index * .2);
      BossEncounterFx.drawStatus(canvas,
          battlefieldWidth: 390,
          bossName: BossEncounterRules.nameForWave(wave),
          wave: wave,
          phase: BossCombatPhase.awakened,
          health: 35,
          maxHealth: 60,
          shield: 3,
          maxShield: 10);
    }
    recorder.endRecording().dispose();
  });
}
