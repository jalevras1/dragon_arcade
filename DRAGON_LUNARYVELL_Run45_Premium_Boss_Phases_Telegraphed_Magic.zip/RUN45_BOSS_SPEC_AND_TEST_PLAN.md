# DRAGON LUNARYVELL — Run 45 boss combat specification

## Locked chapter identities

| Wave | Animated boss (existing Run 41 art) | Flight | Fire pattern | Defense |
|---|---|---|---|---|
| 5 | Eclipse Gargoyle Warden | Measured crystal patrol | Deliberate three-point shard fan, expands in later phases | 9-point starting crystal shield |
| 10 | Ashen Drake Colossus | Fast wing-sweeps and strafes | Alternating sweeping ember wings with seven-point final pressure | No extra shield; faster attack tempo |
| 15 | Moonveil Serpent | Spectral serpentine glide | Left/right alternating crescent gaps | Violet veil shield |
| 20 | Frost Harpy Matriarch | Slow feints over ice | Parallel icicle lanes plus late fan crossfire | Strong icy shield |
| 25 | Eclipse Sovereign | Dual-frequency eclipse sweep | Seven-point convergent star magic | Strong final eclipse shield |

Every boss uses the already installed, transparent eight-frame PNG animation.
If an optional image cannot load, the pre-existing fallback render is retained.
All new warning glyphs and shields are lightweight Canvas primitives.

## Guardrails

- Three predictable phases by remaining health: >65% GUARDED, >30% AWAKENED,
  and <=30% UNLEASHED. Small phase ticks and labels in the top boss HUD.
- A charge visibly previews each projectile velocity for at least 380ms.
  Once the warning begins, the direction is fixed: dodging is meaningful.
- Each volley contains 3–7 projectiles, at most 36 enemy projectiles on
  the entire field. No seeking homing bullets, no unavoidable fullscreen wall.
- Boss X motion uses its own smoothly accumulated clock, avoiding a jump
  when the boss first enters or accelerates between phases.
- Magical shield takes player shot and special-ability damage before health.
  Boss shield effects do not change the ordinary six enemy abilities.
- Phase changes cancel any warned volley; a new attack must warn again.
- Defeat uses three tiny ~260ms glimmers and removes hitboxes/shots immediately.
- No expensive mask blur, saveLayer, huge textures or long-lived particles.

## Integration and QA

1. Python offline guard verifies Run 44 hooks and all Run 45 hooks.
2. Installer checks exact expected Run 44 code hash and package integrity.
3. In Codespaces, Run 43/44/45 preflight scripts must pass.
4. Flutter analyzer checks changed files (errors fatal; infos not fatal).
5. Flutter widget and behavior tests, including Run 45 boss test, must pass.
6. Release web build must create `build/web/index.html`.
7. Installer backs up previous game code and build and automatically rolls
   back any partial install or failed test/build.

### Phone test matrix

- [ ] Wave 5: slow crystal fan, clearly visible shield and warning rays
- [ ] Wave 10: aggressive alternate left/right ember wing spreads
- [ ] Wave 15: Moonveil crescent changes side every volley
- [ ] Wave 20: glacier shot columns leave dodging gaps
- [ ] Wave 25: eclipse 5/7 star volleys and strong final phase
- [ ] HP 65%/30% switches phase label and attack complexity
- [ ] Shield absorbs dragon special abilities and auto-fire before boss HP
- [ ] Wave 5 victory transitions chapter without lingering projectiles
- [ ] Six standard enemies still have distinct Run 44 flight and attacks
- [ ] Phone frame pacing, touch movement, dragon animations remain smooth
