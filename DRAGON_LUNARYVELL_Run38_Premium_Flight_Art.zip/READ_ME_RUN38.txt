DRAGON LUNARYVELL - RUN 38 - PREMIUM FLIGHT AND VISUAL REPAIR

Requires the successful Run 37 install in your existing Codespaces project.
No other app, terminal or port is needed. This ZIP does not modify the
gameplay, campaign, boss rules, special abilities, or button positions.

STEP 1: Upload THIS ZIP (do NOT unzip on your phone) using the existing
GitHub branch upload page:
https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs
Tap Commit changes after upload.

STEP 2: Open your ONE existing Codespaces terminal and paste ONE line:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run38_Premium_Flight_Art.zip && python3 run38_install.py

STEP 3: Wait until RUN 38 COMPLETE. Refresh your CURRENT 8765 preview tab.
If port 8765 is still serving build/web, no server restart is needed.

THIS UPDATE:
- ASTRALIS remains the eight-frame 100ms benchmark, unchanged.
- TEMPESTRYX, IGNIVAR, NYXARIEL, SOLARION and AQUARYTH each receive eight
  real, separately rendered poses (40 PNGs total), individually aligned to
  stable head/body/tail centers with neon sprite-box artifacts cleaned.
- All six dragons render at exactly the same 86x114 size, shared timing;
  other dragons no longer get a separate hover or bank wobble.
- 22 remastered enemy animation frames: 8 goblin-rider, 7 harpy, 7 shadow
  wyvern, with distinct wing poses and restrained, synchronized motion.
- A dramatic painted floating moon-citadel battlefield replaces the gradient.
- A premium new moon-gate title art sits behind the SAME five live buttons,
  in their SAME positions with more elegant borders and typography.
- Original Run 34 and Run 37 artwork is left intact and remains recoverable.

INSTALL SAFETY:
- Every file checks SHA256 against the exact installed Run 37 baseline.
- It stops without changes if you have newer local edits to the same files.
- It backs up the old project files and the working build/web directory.
- It checks Run 35, Run 36 and Run 38 guards, runs Flutter tests, rebuilds
  the web release, and restores the working version if anything fails.

If it stops or fails, do not retry blindly; share the final STOP/FAILED line.
