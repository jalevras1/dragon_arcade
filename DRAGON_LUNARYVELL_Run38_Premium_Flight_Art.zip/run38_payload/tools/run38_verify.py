#!/usr/bin/env python3
"""Run 38 visual/interaction regression guard, safe to run offline."""
from hashlib import sha256
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
names = ['tempestryx', 'ignivar', 'nyxariel', 'solarion', 'aquaryth']
all_sha = set()
count = 0
for name in names:
    folder = ROOT / 'assets/images/run38/dragons' / name / 'flight'
    paths = [folder / f'{name}_flight_{i:02d}.png' for i in range(8)]
    assert all(p.is_file() for p in paths), f'{name}: missing a new frame'
    assert len(list(folder.glob('*.png'))) == 8, f'{name}: unexpected sprites'
    bboxes = []
    local_sha = set()
    for path in paths:
        with Image.open(path) as sprite:
            assert sprite.mode == 'RGBA' and sprite.size == (512, 512), path
            bbox = sprite.getchannel('A').getbbox()
            assert bbox is not None, path
            # All heads and tails are registered in a common 420px vertical
            # region. The visible image never spills into neighboring cells.
            assert 35 <= bbox[1] <= 51 and 455 <= bbox[3] <= 471, path
            assert 1 < bbox[0] and bbox[2] < 511, path
            assert sprite.getpixel((0, 0))[3] == 0, path
            bboxes.append(bbox)
        h = sha256(path.read_bytes()).hexdigest()
        assert h not in local_sha, f'{name}: repeated image, not new art'
        local_sha.add(h)
        all_sha.add(h)
        count += 1
    centers = [(b[0] + b[2]) / 2 for b in bboxes]
    assert max(centers) - min(centers) <= 3, f'{name}: horizontal jitter'

for name in ['home_moon_gate.png', 'battlefield_moon_citadel.png']:
    path = ROOT / 'assets/images/run38/backgrounds' / name
    assert path.is_file(), f'missing Run 38 scene: {name}'
    with Image.open(path) as picture:
        assert picture.width >= 900 and picture.height >= 1500, name

enemy_count = 0
for folder, prefix, total in [('goblin_sky_raider', 'goblin', 8),
                               ('harpy', 'harpy', 7),
                               ('shadow_wyvern', 'shadow_wyvern', 7)]:
    location = ROOT / 'assets/images/run38/enemies' / folder
    sequence = [location / f'{prefix}_{i:02d}.png' for i in range(total)]
    assert all(p.is_file() for p in sequence), f'{folder}: missing frames'
    assert len(list(location.glob('*.png'))) == total, folder
    unique = set()
    for file in sequence:
        unique.add(sha256(file.read_bytes()).hexdigest())
        with Image.open(file) as sprite:
            assert sprite.mode == 'RGBA' and sprite.size == (256, 256), file
            bbox = sprite.getchannel('A').getbbox()
            assert bbox is not None and bbox[0] > 1 and bbox[1] > 1, file
    assert len(unique) == total, f'{folder}: repeated enemy poses'
    assert f'- assets/images/run38/enemies/{folder}/' in (ROOT / 'pubspec.yaml').read_text()
    enemy_count += total

pubspec = (ROOT / 'pubspec.yaml').read_text()
for name in names:
    assert f'- assets/images/run38/dragons/{name}/flight/' in pubspec
assert '- assets/images/run38/backgrounds/' in pubspec

game = (ROOT / 'lib/game/dragon_lunaryvell_game.dart').read_text()
assert 'List.generate(\n          8,\n          (i) => images.load(\n            \'run38/dragons/' in game
assert 'frames.length == 8\n            ? _flightFrame' in game
assert 'width: 86,\n            height: 114' in game
assert "'run38/backgrounds/battlefield_moon_citadel.png'" in game
assert 'DragonFlightCycle.fourPoseFrameAt(_wingMotionSeconds)' in game
assert 'unawaited(_preloadEnemySprites());' in game
assert "'run38/enemies/shadow_wyvern/shadow_wyvern_" in game
assert 'foe.animationClock >= .1' in game
assert '_updateSpecialsAndPickups(step);' in game

shell = (ROOT / 'lib/ui/dragon_shell.dart').read_text()
assert "const _homeArt = 'assets/images/run38/backgrounds/home_moon_gate.png';" in shell
for token in ['onPressed: onPlay', 'onPressed: onCampaign',
              'onPressed: onChoose', "'HOW TO PLAY'", "'ABOUT THE GAME'",
              "'DRAGON: ${selected.name}'", 'class _PremiumTitleBackdrop']:
    assert token in shell, f'missing original title interaction: {token}'
assert 'campaignMode: widget.campaignMode' in shell

print(f'RUN 38 VISUAL PREFLIGHT PASS: {count} registered dragon frames, '
      f'{enemy_count} moving enemy frames, two premium backgrounds, '
      'six playable dragons, original menu actions')
