DRAGON LUNARYVELL — RUN 46: FASTER START + PHONE PERFORMANCE POLISH
===================================================================

BASED ON YOUR SUCCESSFUL RUN 45. YOUR EXISTING CODESPACE IS ALL YOU NEED.

WHAT IS NEW
- Opening screen no longer waits for four later-chapter backgrounds.
  Those images decode later, so first paint has less mandatory work.
- The three opening enemy wing cycles load concurrently instead of one
  species at a time. Existing animated frames are preserved.
- If a future chapter background finishes loading after you jump to that
  chapter, it now enters with an eased crossfade instead of suddenly popping.
- Developer Test Hub shows approximate FPS, number of slow frames,
  peak frame time and optional chapter/boss art readiness.
- More efficient distance checks during combat (same hit radius and rules).
- 55 obsolete opacity API calls updated to the supported modern method;
  four tiny const optimizations and unused import/parameter cleanup.
- Existing Run 45 boss phases, Run 44 enemy archetypes, six dragons,
  spells, menus, power-ups and all artwork are preserved.

INSTALL — 3 PHONE STEPS

1. Download DRAGON_LUNARYVELL_Run46_Fast_Start_Performance_Polish.zip
   from ChatGPT.
2. Upload that ZIP to the ROOT of the dragon-lunaryvell-repairs branch:
   https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs
   Tap COMMIT CHANGES.
3. In the existing Codespaces project-root terminal, paste ONE line:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run46_Fast_Start_Performance_Polish.zip && python3 run46_install.py

Wait for: RUN 46 COMPLETE — Faster launch and phone diagnostics ready.
Refresh the SAME port 8765 preview. No new tool or port is needed.

PHONE TEST
- Open the game and note whether the initial load feels faster.
- Play Wave 1: three enemy types must keep continuous 2D wing animations.
- Open DEV HUB after a few live waves. Its last lines show estimated FPS,
  slow frame count, worst frame time and loaded background/boss art counts.
- Jump to Waves 6, 11, 16 and 21. Backgrounds must fade smoothly.
- Jump to Boss Waves 5, 10, 15, 20 and 25: original Run 45 warnings,
  phases and shields should remain exactly as before.
- Test the six dragons' spells and the ALL SIX ENEMIES preview.

SAFETY
The installer checks expected Run 45 file hashes, package SHA-256,
Run 43-46 contract checks, Flutter analysis, tests and web release build.
Every file being replaced is backed up. A failed install restores your
prior Run 45 code and build automatically.

The Run 46 performance meter is a lightweight diagnostic, not a precise
device benchmark. Measure actual results in your Android Chrome preview.
The package was verified offline; Flutter compilation runs in Codespaces.
