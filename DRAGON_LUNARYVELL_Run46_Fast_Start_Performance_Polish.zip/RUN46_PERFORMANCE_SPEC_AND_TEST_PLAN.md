# Run 46 — Startup and phone performance contract

## Measurable changes

1. **Shorter blocking startup:** `DragonLunaryvellGame.onLoad()` no longer
   awaits four future chapter backgrounds. The first battlefield, selected
   dragon, three wave-one enemy families and essential projectile sprites
   remain on the startup path, preventing missing-art flashes.
2. **Parallel enemy decoding:** goblin, harpy and wyvern frame groups load
   together instead of sequentially; fallback group still activates only
   when complete.
3. **Smooth late scenery:** future chapter scenes load in a bounded sequential
   queue and, if the user jumps there early, start the existing 1.4-second
   eased crossfade as they become available.
4. **Reduced per-frame arithmetic:** collision distance avoids `math.pow`
   while retaining the exact Euclidean distance and hit behavior.
5. **Developer metrics:** `FramePacingMeter` uses constant-time counters;
   frames longer than 34 ms count as slow, app-suspension gaps >500ms are
   discarded, and FPS updates approximately every 750ms.
6. **Lint maintenance:** old `.withOpacity(...)` expressions are migrated to
   `.withValues(alpha: ...)`, two unnecessary imports and an unused optional
   parameter are removed, plus safe const/comment cleanup. Older Flutter
   `material.dart` import deprecation notices remain informational; no new
   replacement UI package is installed.

## Invariants

- Existing asset paths, boss phases, damage values, projectile speeds,
  dragon flight timing, all six enemy patterns and chapter wave gates retained.
- No background sprite is removed or decompressed by the installer.
- No screenshot or new paid tool is required.
- No mask blur, `saveLayer`, timers or expensive allocations in FPS sampling.
- Projectiles retain their Run 44 glow/trails and 28-impact cap.
- If a Dart test, analyzer, or release web build fails in Codespaces, the
  installer restores the backed-up Run 45 sources and previous web output.

## Phone test checklist

- [ ] Loading screen shorter than prior Run 45 under comparable conditions
- [ ] No startup blank frame, missing enemy, flat dragon, or flicker
- [ ] Three wave-one enemy flight cycles remain synchronized and smooth
- [ ] Dev Hub displays FPS, slow frames, peak ms and art readiness
- [ ] Background fades at Waves 6, 11, 16, 21, including immediate Dev jump
- [ ] Bosses Waves 5/10/15/20/25 retain phase patterns and overshields
- [ ] Six dragon auto-fire and special abilities unchanged
- [ ] Analysis no longer reports the old `.withOpacity` notices
