# DRAGON LUNARYVELL — Asset Preparation Batch 01

## Contents
- Three celestial-blue projectile candidates for the player dragon.
- Three ember-orange projectile candidates for fantasy enemies.
- All six images are 96×96 RGBA PNGs on transparent canvases.
- Contact sheet for quick review.

## Source and processing
Extracted from the saved `DRAGON_LUNARYVELL_Priority_Enemy_and_Gameplay_Atlas_03.png`.
The atlas background haze was suppressed outside connected alpha regions, then each motif was normalized to a consistent transparent canvas.

## Safety status
**Prepared only — not integrated into the game.**
These are individual static projectile motifs, not frame-by-frame animation cycles. Their alpha edges and visual scale should be checked in the actual game before registration in `pubspec.yaml` or changes to combat rendering.

## Optional safe installation
Extract the ZIP, then run:
```bash
python3 install_projectiles.py /workspaces/dragon_arcade
```
The installer validates all six PNGs, refuses to overwrite existing files, backs up `pubspec.yaml`, and only registers the two asset folders. It does not change Dart source or gameplay behavior. The sprites will be present in the project but will not appear in-game until a separately reviewed rendering change is made.
