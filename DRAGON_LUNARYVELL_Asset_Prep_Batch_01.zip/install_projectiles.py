#!/usr/bin/env python3
"""Safely install prepared projectile PNG assets and register their folders.

This installer does NOT modify Dart source files or gameplay behavior.
It refuses to overwrite existing asset files and makes a pubspec backup
before adding missing asset directory entries.
Run from the extracted batch folder:
    python3 install_projectiles.py /workspaces/dragon_arcade
"""
from pathlib import Path
import shutil
import sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().parent.resolve()
BATCH = Path(__file__).resolve().parent
PUBSPEC = ROOT / "pubspec.yaml"
SOURCE_ASSETS = BATCH / "assets" / "images" / "projectiles"
TARGET_ASSETS = ROOT / "assets" / "images" / "projectiles"

if not PUBSPEC.is_file():
    raise SystemExit(f"STOP: pubspec.yaml not found in {ROOT}")
if not SOURCE_ASSETS.is_dir():
    raise SystemExit("STOP: prepared projectile assets folder is missing")

files = sorted(SOURCE_ASSETS.glob("*/*.png"))
if len(files) != 6:
    raise SystemExit(f"STOP: expected 6 PNG files, found {len(files)}")

# Validate every PNG before copying.
try:
    from PIL import Image
except ImportError:
    raise SystemExit("STOP: Pillow is required for validation; no files were changed.")

for path in files:
    with Image.open(path) as image:
        if image.format != "PNG" or image.mode != "RGBA" or image.size != (96, 96):
            raise SystemExit(f"STOP: unexpected image format/size: {path.name}")
        alpha = image.getchannel("A")
        if alpha.getextrema()[0] != 0:
            raise SystemExit(f"STOP: image lacks transparent pixels: {path.name}")

text = PUBSPEC.read_text(encoding="utf-8")
required = [
    "    - assets/images/projectiles/player/",
    "    - assets/images/projectiles/enemy/",
]
if "flutter:\n" not in text or "  assets:\n" not in text:
    raise SystemExit("STOP: expected Flutter assets section not found; no files were changed.")

# Check for collisions before any writes.
for source in files:
    target = TARGET_ASSETS / source.parent.name / source.name
    if target.exists():
        raise SystemExit(f"STOP: refusing to overwrite existing file: {target}")

# Prepare modified pubspec in memory and validate insertion point.
missing = [entry for entry in required if entry not in text]
if missing:
    marker = "  assets:\n"
    if text.count(marker) != 1:
        raise SystemExit("STOP: assets section is ambiguous; no files were changed.")
    updated = text.replace(marker, marker + "\n".join(missing) + "\n", 1)
else:
    updated = text

# Backup first, then copy files, then write pubspec.
backup = PUBSPEC.with_name("pubspec.yaml.projectiles-backup")
if backup.exists():
    raise SystemExit(f"STOP: backup already exists: {backup}")
shutil.copy2(PUBSPEC, backup)
try:
    for source in files:
        target = TARGET_ASSETS / source.parent.name / source.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    PUBSPEC.write_text(updated, encoding="utf-8")
except Exception:
    # Remove only files created by this run and restore pubspec.
    for source in files:
        target = TARGET_ASSETS / source.parent.name / source.name
        if target.exists():
            target.unlink()
    shutil.copy2(backup, PUBSPEC)
    raise

print("SAFE INSTALL COMPLETE")
print("6 transparent PNG projectile candidates copied.")
print("pubspec.yaml updated only if the two asset folders were missing.")
print("No Dart source files or gameplay behavior were changed.")
print("Next: run flutter pub get, flutter test, and flutter build web --release.")
