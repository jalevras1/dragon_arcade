DRAGON LUNARYVELL — RUN 37: SMOOTH FLIGHT & QUICKER LOADING

Requires successful Run 36 Corrected v2. Keep all old PNGs and GitHub setup.

STEP 1 — Upload this ONE ZIP to your existing repair branch:
https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs
Select Commit Changes (directly to dragon-lunaryvell-repairs).

STEP 2 — In ONE existing Codespaces terminal paste exactly this one line:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run37_Smooth_Flight_Polish.zip && python3 run37_install.py

STEP 3 — Wait for RUN 37 COMPLETE, then refresh the SAME 8765 game tab.
No new server required if 8765 is already serving build/web.

What changed:
- ASTRALIS retains its original 8-frame wing loop untouched.
- All other 5 dragons have an independent 4-pose / 6-step ping-pong loop
  whose 0.8-second cadence matches ASTRALIS. No more mismatched modulo wrap.
- Subtle directional banking and wing-synchronous hovering.
- Optional enemy sprite decoding moves off the startup-critical path.
- Tiny, brief enemy-defeat sparkles and an unobtrusive wave label.
- No existing PNG, enemy, dragon, menu, ability, campaign or HUD asset changed.

Safety: Checks the EXACT installed Run 36 v2 code SHA, runs original Run 35
and Run 36 guards, Run 37 guards, 4 Flutter tests and a web release build.
It backs up previous files + working web output, restoring both on failure.

If an error occurs, do not keep retrying. Tell ChatGPT the final error line.
