#!/usr/bin/env python3
"""Run 37 safe Flutter/Flame update on top of successful Run 36 corrected v2."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path, PurePosixPath
import argparse
import json
import shutil
import subprocess
import sys

ROOT = Path.cwd().resolve()
BRANCH = 'dragon-lunaryvell-repairs'


def digest(path: Path) -> str:
    h = sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def checked_path(relative: str) -> Path:
    parts = PurePosixPath(relative)
    if parts.is_absolute() or '..' in parts.parts or not parts.parts:
        raise ValueError('Unsafe path in update ZIP: ' + relative)
    for i in range(1, len(parts.parts) + 1):
        if ROOT.joinpath(*parts.parts[:i]).is_symlink():
            raise ValueError('Symlink target refused: ' + relative)
    return ROOT.joinpath(*parts.parts)


def run(command: list[str], limit: int) -> None:
    print('Checking:', ' '.join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True, timeout=limit)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--skip-build', action='store_true',
                        help='Local verification only; does not create a playable build')
    options = parser.parse_args()
    if not (ROOT / '.git').is_dir() or not (ROOT / 'pubspec.yaml').is_file():
        print('STOP: Open the existing dragon_arcade Codespace first.')
        return 2
    branch = subprocess.check_output(
        ['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip()
    if branch != BRANCH:
        print(f'STOP: Wrong branch {branch!r}. No files were changed.')
        return 2
    manifest_path = ROOT / 'run37_manifest.json'
    if not manifest_path.is_file():
        print('STOP: Extract the Run 37 ZIP first. No files were changed.')
        return 2
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('run') != 37 or manifest.get('branch') != BRANCH:
        print('STOP: Invalid Run 37 manifest. No files were changed.')
        return 2
    flutter = shutil.which('flutter')
    if not options.skip_build and not flutter:
        fallback = Path.home() / 'flutter/bin/flutter'
        flutter = str(fallback) if fallback.is_file() else None
    if not options.skip_build and not flutter:
        print('STOP: Flutter unavailable. No files were changed.')
        return 2

    pending: list[tuple[str, Path, Path]] = []
    for entry in manifest['files']:
        rel = entry['path']
        target = checked_path(rel)
        source = ROOT / 'run37_payload' / rel
        if not source.is_file() or digest(source) != entry['new_sha256']:
            print('STOP: Update ZIP payload is incomplete:', rel)
            return 2
        old = entry['old_sha256']
        if target.is_file():
            current = digest(target)
            if current == entry['new_sha256']:
                continue
            if current != old:
                print('STOP: Existing file is not the expected Run 36 version:', rel)
                print('No files changed. Your custom work remains safe.')
                return 2
        elif old is not None:
            print('STOP: Required previous file is missing:', rel)
            return 2
        pending.append((rel, source, target))

    if not pending:
        print('RUN 37 ALREADY INSTALLED. Refresh your port 8765 game page.')
        return 0

    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    backup = ROOT / '.run37_backups' / stamp
    saved_web = backup / 'previous_web'
    build = ROOT / 'build/web'
    backup.mkdir(parents=True)
    originals: list[tuple[str, Path, bool]] = []
    moved_web = False
    try:
        for rel, source, target in pending:
            existed = target.is_file()
            originals.append((rel, target, existed))
            if existed:
                dest = backup / 'original_files' / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, dest)
        for rel, source, target in pending:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        run([sys.executable, 'tools/run35_verify.py'], 100)
        run([sys.executable, 'tools/run36_verify.py'], 30)
        run([sys.executable, 'tools/run37_verify.py'], 30)
        if not options.skip_build:
            run([flutter, 'test', 'test/widget_test.dart',
                 'test/special_ability_rules_test.dart',
                 'test/campaign_story_test.dart',
                 'test/dragon_flight_cycle_test.dart'], 360)
            if build.is_dir():
                shutil.move(str(build), str(saved_web))
                moved_web = True
            run([flutter, 'build', 'web', '--release', '--no-pub',
                 '--dart-define=DL_DEV_TOOLS=true'], 900)
            if not (build / 'index.html').is_file():
                raise RuntimeError('Flutter web index.html missing')
        (backup / 'SUCCESS.txt').write_text(
            'Run 37 verified and ' +
            ('not compiled\n' if options.skip_build else 'built for web\n'))
        print('\nRUN 37 COMPLETE — wings, startup and enemy effects updated.')
        print('Earlier files saved in', backup.relative_to(ROOT))
        if options.skip_build:
            print('NOTE: --skip-build did not make a playable web preview.')
        else:
            print('Refresh the SAME port 8765 browser preview.')
        return 0
    except BaseException as error:
        print('\nUPDATE OR BUILD FAILED:', error)
        print('Restoring working Run 36 files…', flush=True)
        for rel, target, existed in reversed(originals):
            if existed:
                original = backup / 'original_files' / rel
                if original.is_file():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(original, target)
            elif target.is_file():
                target.unlink()
        if moved_web:
            if build.is_dir():
                shutil.rmtree(build)
            shutil.move(str(saved_web), str(build))
        print('ROLLBACK COMPLETE — Run 36 was restored.')
        return 1


if __name__ == '__main__':
    sys.exit(main())
