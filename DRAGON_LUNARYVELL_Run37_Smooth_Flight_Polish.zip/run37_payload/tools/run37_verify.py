#!/usr/bin/env python3
"""Non-mutating Run 37 checks before Flutter compiles the update."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent
game = (root / 'lib/game/dragon_lunaryvell_game.dart').read_text()
flight = (root / 'lib/game/dragon_flight_cycle.dart').read_text()
test = (root / 'test/dragon_flight_cycle_test.dart').read_text()

for token in [
    'DragonFlightCycle.fourPoseFrameAt(_wingMotionSeconds)',
    '_wingMotionSeconds += step;',
    '_flightBank',
    'canvas.rotate(_flightBank);',
    'unawaited(_preloadEnemySprites());',
    '_DefeatGlimmer.duration',
    'final frame = _flightFrames[_flightFrame];',
]:
    assert token in game, f'missing Run 37 integration: {token}'
assert '_run32WingCycle' not in game, 'old eight-step index bug still present'
assert 'path\n          ..lineTo(x - 10, floor)' in game
assert 'path..lineTo(size.x, size.y)..close();' in game
assert 'static const secondsPerCycle = 0.8' in flight
assert 'static const wingPositions = <int>[0, 1, 2, 3, 2, 1]' in flight
assert 'four-pose dragons follow' in test
for dragon in ['tempestryx', 'ignivar', 'nyxariel', 'solarion', 'aquaryth']:
    images = list((root / 'assets/images/run32/dragons' / dragon /
                   'flight').glob(f'{dragon}_flight_??.png'))
    assert len(images) == 4, f'{dragon}: expected 4 intact Run 34 frames'
print('RUN 37 PREFLIGHT PASS: six natural flight cycles, original sprites safe')
