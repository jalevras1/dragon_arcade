import 'package:flutter_test/flutter_test.dart';
import 'package:dragon_lunaryvell/game/dragon_flight_cycle.dart';

void main() {
  test('four-pose dragons follow the same 0.8s rhythm as ASTRALIS', () {
    expect(DragonFlightCycle.astralisFrames, 8);
    final seen = List.generate(6, (i) =>
        DragonFlightCycle.fourPoseFrameAt(i * (0.8 / 6) + .001));
    expect(seen, [0, 1, 2, 3, 2, 1]);
    expect(DragonFlightCycle.fourPoseFrameAt(.801), 0);
    expect(DragonFlightCycle.fourPoseFrameAt(1.601), 0);
  });

  test('paused, invalid and first frames have safe values', () {
    expect(DragonFlightCycle.fourPoseFrameAt(0), 0);
    expect(DragonFlightCycle.fourPoseFrameAt(-3), 0);
    expect(DragonFlightCycle.fourPoseFrameAt(double.nan), 0);
    for (var i = 0; i < 100; i++) {
      expect(DragonFlightCycle.fourPoseFrameAt(i / 60), inInclusiveRange(0, 3));
    }
  });
}
