/// Shared wing cadence for all playable dragons.
///
/// ASTRALIS is authored as eight distinct frames at 0.10 seconds/frame.
/// The other five use four complete illustrated poses. A reversible cycle
/// needs six steps: raise -> extend -> lower -> fold -> lower -> extend.
/// Keeping each cycle at 0.8 seconds matches ASTRALIS's actual flap tempo.
class DragonFlightCycle {
  const DragonFlightCycle._();

  static const astralisFrames = 8;
  static const wingPositions = <int>[0, 1, 2, 3, 2, 1];
  static const secondsPerCycle = 0.8;

  static int fourPoseFrameAt(double elapsedSeconds) {
    if (elapsedSeconds <= 0 || !elapsedSeconds.isFinite) return 0;
    final cycles = elapsedSeconds / secondsPerCycle;
    final phase = (cycles * wingPositions.length).floor() %
        wingPositions.length;
    return wingPositions[phase];
  }
}
