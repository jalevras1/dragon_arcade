DRAGON LUNARYVELL — RUN 36: DRAGON MAGIC + CAMPAIGN

Keep your existing GitHub Codespaces + Flutter + Flame project. No new app.
This update is a tiny, verified set of changes ON TOP OF WORKING RUN 35.

1) Upload only this ZIP on the GitHub branch dragon-lunaryvell-repairs:
   https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs
   (The real URL has NO SPACE in dragon-lunaryvell-repairs.)

2) In your ONE existing Codespaces terminal paste ONE line:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run36_Dragon_Magic_Campaign.zip && python3 run36_install.py

3) Wait for RUN 36 COMPLETE and refresh the SAME port 8765 game page.
   You do not need to restart the web server; it serves build/web.

What changed:
 - Each of the six dragons has different enemy-seeking/chaining magic
   rather than oversized ability art. Dragonfire is magical breath, NOT rockets.
 - Temporary HASTE, CRITICAL and SHIELD pickups drop from defeated enemies.
 - Campaign button, five story chapters, narrative breaks, boss every 5 waves.
 - Bosses escalate health, attacks and spread at waves 5, 10, 15, 20, 25.
 - Enemy sprite flutter, richer low-cost background and premium HUD styling.
 - Arcade remains endless. Existing dragon frames and enemy PNGs untouched.

SAFETY: Compares every file to the exact Run 35 installed version; stops
on local changes; backs up originals before writing; runs code/asset checks,
Flutter widget tests and web build, and rolls back automatically on failure.
The prior known-good build/web is moved into a backup and restored on failure.

TROUBLESHOOT: If no progress for a few minutes, copy the last terminal line.
Never paste the --skip-build option for normal testing: it cannot build web.

Corrected v2: fixed invalid Dart Path.lineTo cascade syntax in game background renderer.
