# DRAGON LUNARYVELL — First Enemy Sprite Integration Pack

This pack extracts isolated transparent PNG poses from the saved Priority Enemy and Gameplay Atlas 03.

## Included
- Goblin Sky Raider: 4 pose frames
- Harpy: 3 pose frames
- Shadow Wyvern: 3 pose frames
- All frames normalized to 144 x 144 RGBA cells with transparent backgrounds and bottom-center alignment.
- `ENEMY_SPRITE_CONTACT_SHEET.png` is a visual review sheet, not a runtime asset.

## Runtime use
The included installer copies the images into `assets/images/enemies/`, registers those folders in `pubspec.yaml`, and updates the existing Flame game to randomly spawn these three enemy families and cycle their available pose frames.

## Validation note
These are isolated pose samples from a composite art atlas, not newly authored full animation cycles. Their frame cadence is a first integration prototype and should be reviewed in the running game. They are kept separate from the existing ASTRALIS flight animation, which is not modified.
