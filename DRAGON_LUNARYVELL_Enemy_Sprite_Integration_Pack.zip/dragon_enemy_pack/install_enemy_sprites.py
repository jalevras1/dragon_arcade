from pathlib import Path
import shutil

ROOT = Path.cwd()
SOURCE = ROOT / 'lib/game/dragon_lunaryvell_game.dart'
PUBSPEC = ROOT / 'pubspec.yaml'
PACK = Path(__file__).resolve().parent

if not SOURCE.is_file() or not PUBSPEC.is_file():
    raise SystemExit('Run this installer from the dragon_arcade project root.')

source = SOURCE.read_text()
pubspec = PUBSPEC.read_text()

if '_enemyFrames' in source and 'goblin_sky_raider' in source:
    print('Enemy sprites are already integrated. No source changes were made.')
    raise SystemExit(0)

old_foe = """class _Foe {
  _Foe(
      {required this.x,
      required this.y,
      required this.hp,
      required this.radius,
      required this.speed,
      this.boss = false});
  double x, y, hp, radius, speed;
  bool boss;
  double fireClock = 0;
}"""
new_foe = """class _Foe {
  _Foe(
      {required this.x,
      required this.y,
      required this.hp,
      required this.radius,
      required this.speed,
      this.boss = false,
      this.typeIndex = 0,
      this.spriteSize = 60});
  double x, y, hp, radius, speed, spriteSize;
  bool boss;
  int typeIndex;
  double fireClock = 0;
  double animationClock = 0;
  int animationFrame = 0;
}"""

old_field = '  List<ui.Image> _flightFrames = [];\n'
new_field = old_field + '  List<List<ui.Image>> _enemyFrames = [];\n'

old_load = """    _flightFrames = await Future.wait(
      List.generate(
        8,
        (i) => images.load(
          'dragons/astralis/flight/astralis_flight_wing_${i.toString().padLeft(2, '0')}.png',
        ),
      ),
    );
"""
new_load = old_load + """    _enemyFrames = [
      await Future.wait(List.generate(4, (i) => images.load(
          'enemies/goblin_sky_raider/goblin_${i.toString().padLeft(2, '0')}.png'))),
      await Future.wait(List.generate(3, (i) => images.load(
          'enemies/harpy/harpy_${i.toString().padLeft(2, '0')}.png'))),
      await Future.wait(List.generate(3, (i) => images.load(
          'enemies/shadow_wyvern/shadow_wyvern_${i.toString().padLeft(2, '0')}.png'))),
    ];
"""

old_spawn = """        _foes.add(_Foe(
          x: 24 + _random.nextDouble() * math.max(1.0, size.x - 48).toDouble(),
          y: -24,
          hp: 1.0 + (_wave ~/ 3),
          radius: 13 + _random.nextDouble() * 5,
          speed: 65 + _wave * 4,
        ));"""
new_spawn = """        final enemyType = _random.nextInt(3);
        final enemyRadius = [13.0, 15.0, 17.0][enemyType];
        final enemySpeed = [78.0, 68.0, 58.0][enemyType] + _wave * 4;
        final enemySize = [56.0, 64.0, 72.0][enemyType];
        _foes.add(_Foe(
          x: 24 + _random.nextDouble() * math.max(1.0, size.x - 48).toDouble(),
          y: -24,
          hp: 1.0 + (_wave ~/ 3),
          radius: enemyRadius,
          speed: enemySpeed,
          typeIndex: enemyType,
          spriteSize: enemySize,
        ));"""

old_update = """    for (final foe in _foes) {
      foe.y += foe.speed * step;"""
new_update = """    for (final foe in _foes) {
      if (foe.typeIndex >= 0 && foe.typeIndex < _enemyFrames.length) {
        final frames = _enemyFrames[foe.typeIndex];
        if (frames.isNotEmpty) {
          foe.animationClock += step;
          while (foe.animationClock >= .14) {
            foe.animationClock -= .14;
            foe.animationFrame = (foe.animationFrame + 1) % frames.length;
          }
        }
      }
      foe.y += foe.speed * step;"""

old_render = """    for (final foe in _foes) {
      canvas.drawCircle(Offset(foe.x, foe.y), foe.radius, red);
      canvas.drawCircle(
          Offset(foe.x, foe.y),
          foe.radius + 4,
          Paint()
            ..color = red.color.withOpacity(.18)
            ..style = PaintingStyle.stroke);
    }"""
new_render = """    for (final foe in _foes) {
      if (foe.typeIndex >= 0 && foe.typeIndex < _enemyFrames.length &&
          _enemyFrames[foe.typeIndex].isNotEmpty) {
        final frames = _enemyFrames[foe.typeIndex];
        final frame = frames[foe.animationFrame % frames.length];
        canvas.drawImageRect(
          frame,
          Rect.fromLTWH(0, 0, frame.width.toDouble(), frame.height.toDouble()),
          Rect.fromCenter(
            center: Offset(foe.x, foe.y),
            width: foe.spriteSize,
            height: foe.spriteSize,
          ),
          Paint()..filterQuality = FilterQuality.high,
        );
      } else {
        canvas.drawCircle(Offset(foe.x, foe.y), foe.radius, red);
        canvas.drawCircle(
            Offset(foe.x, foe.y),
            foe.radius + 4,
            Paint()
              ..color = red.color.withOpacity(.18)
              ..style = PaintingStyle.stroke);
      }
    }"""

replacements = [
    (old_foe, new_foe, 'foe model'),
    (old_field, new_field, 'enemy image field'),
    (old_load, new_load, 'enemy image loading'),
    (old_spawn, new_spawn, 'enemy spawning'),
    (old_update, new_update, 'enemy animation update'),
    (old_render, new_render, 'enemy sprite rendering'),
]
for old, new, label in replacements:
    count = source.count(old)
    if count != 1:
        raise SystemExit(f'Safe stop: expected one matching section for {label}, found {count}. No project files were changed.')
    source = source.replace(old, new, 1)

asset_marker = '    - assets/images/dragons/astralis/flight/\n'
if pubspec.count(asset_marker) != 1:
    raise SystemExit('Safe stop: could not identify the existing ASTRALIS asset registration. No project files were changed.')
asset_lines = asset_marker + (
    '    - assets/images/enemies/goblin_sky_raider/\n'
    '    - assets/images/enemies/harpy/\n'
    '    - assets/images/enemies/shadow_wyvern/\n'
)
pubspec = pubspec.replace(asset_marker, asset_lines, 1)

asset_source = PACK / 'assets/images/enemies'
if not asset_source.is_dir():
    raise SystemExit('Enemy asset folders are missing from this pack. No project files were changed.')

# All text patches are validated before copying or writing.
target_assets = ROOT / 'assets/images/enemies'
target_assets.parent.mkdir(parents=True, exist_ok=True)
shutil.copytree(asset_source, target_assets, dirs_exist_ok=True)
SOURCE.write_text(source)
PUBSPEC.write_text(pubspec)
print('Enemy sprite assets installed and Flame source updated.')
print('ASTRALIS flight assets and all existing untracked files were left untouched.')
