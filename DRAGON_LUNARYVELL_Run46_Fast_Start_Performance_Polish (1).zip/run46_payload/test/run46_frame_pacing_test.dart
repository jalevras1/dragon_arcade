import 'package:dragon_lunaryvell/game/frame_pacing_meter.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('60 Hz frames result in stable 60 FPS without false slow frames', () {
    final meter = FramePacingMeter();
    for (var frame = 0; frame < 120; frame++) {
      meter.sample(1 / 60);
    }
    expect(meter.fps, closeTo(60, .5));
    expect(meter.hitchCount, 0);
    expect(meter.diagnosticLine, contains('FPS'));
  });

  test('slow frame counts are visible and background gaps are ignored', () {
    final meter = FramePacingMeter();
    for (var frame = 0; frame < 26; frame++) {
      meter.sample(.04);
    }
    expect(meter.fps, closeTo(25, .5));
    expect(meter.hitchCount, 26);
    final peak = meter.worstFrameMs;
    meter.sample(2.5); // Phone browser tab resumed after suspension.
    expect(meter.hitchCount, 26);
    expect(meter.worstFrameMs, peak);
    meter.reset();
    expect(meter.fps, 60);
    expect(meter.hitchCount, 0);
  });
}
