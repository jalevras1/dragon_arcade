import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

/// Lightweight, original 2D magic layered over the existing Run 43 sprites.
///
/// The visual direction has no effect on projectile velocity, damage, or
/// collision radii. Everything is painted with bounded Canvas operations:
/// no blur filters, saveLayers, third-party shaders or new image decoding.
class PremiumProjectileFx {
  PremiumProjectileFx._();

  static const Map<String, _MagicPalette> _palettes = {
    'astralis': _MagicPalette(
      Color(0xFFBEF3FF), Color(0xFF489BEE), Color(0xFFF8D990)),
    'temperstryx': _MagicPalette(
      Color(0xFFD8EBFF), Color(0xFF685BFF), Color(0xFF9DF3FF)),
    'ignivar': _MagicPalette(
      Color(0xFFFFF2BB), Color(0xFFEF522C), Color(0xFFFFB252)),
    'nyxariel': _MagicPalette(
      Color(0xFFF3C8FF), Color(0xFF7534C9), Color(0xFFBB80E9)),
    'solarion': _MagicPalette(
      Color(0xFFFFF9D8), Color(0xFFFFB632), Color(0xFFFFE597)),
    'aquaryth': _MagicPalette(
      Color(0xFFD1FFFF), Color(0xFF1CAFC4), Color(0xFF8FEEEC)),
  };
  static const _boss = _MagicPalette(
    Color(0xFFFFBCD3), Color(0xFFB24192), Color(0xFFFF778C));

  static Color colorFor(String id) => (_palettes[id] ?? _boss).accent;

  static bool hasTheme(String id) => _palettes.containsKey(id);

  static void drawPlayerUnderlay(
      Canvas canvas, Offset center, String id, double time) {
    _drawUnderlay(canvas, center, 0, _palettes[id] ?? _boss, time,
        hostile: false);
  }

  static void drawEnemyUnderlay(Canvas canvas, Offset center,
      Offset velocity, String id, double time) {
    _drawUnderlay(canvas, center,
        math.atan2(velocity.dy, velocity.dx) + math.pi / 2,
        _palettes[id] ?? _boss, time, hostile: true);
  }

  static void _drawUnderlay(Canvas canvas, Offset center, double angle,
      _MagicPalette palette, double time, {required bool hostile}) {
    final scale = hostile ? .82 : 1.0;
    final tail = hostile ? 30.0 : 45.0;
    final phase = time * 17 + center.dx * .027 + center.dy * .013;
    final sway = math.sin(phase) * (hostile ? 1.6 : 2.2);
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(angle);
    canvas.scale(scale);

    // Two translucent, tapered streamers follow the projectile's actual
    // travel direction. The wide layer stays dim so HUD and enemies remain
    // readable on a phone.
    final tailShape = Path()
      ..moveTo(0, -14)
      ..cubicTo(11, 2, 7 + sway, tail * .65, 0, tail)
      ..cubicTo(-7 - sway, tail * .66, -11, 2, 0, -14)
      ..close();
    canvas.drawPath(
        tailShape,
        Paint()
          ..shader = ui.Gradient.linear(
              const Offset(0, -14), Offset(0, tail), [
            palette.energy.withValues(alpha: .56),
            palette.energy.withValues(alpha: .20),
            palette.energy.withValues(alpha: 0),
          ], [
            0, .35, 1
          ]));

    for (var side = -1; side <= 1; side += 2) {
      final ribbon = Path()
        ..moveTo(side * 3.5, 0)
        ..cubicTo(side * 10, 11, side * 4 + sway, tail * .6,
            side * 1.5, tail * .86);
      canvas.drawPath(
          ribbon,
          Paint()
            ..color = palette.accent.withValues(alpha: hostile ? .29 : .43)
            ..strokeWidth = hostile ? 1.0 : 1.3
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke);
    }

    canvas.drawCircle(
        const Offset(0, -2),
        hostile ? 17 : 20,
        Paint()
          ..shader = ui.Gradient.radial(
              const Offset(0, -2), hostile ? 17 : 20, [
            palette.energy.withValues(alpha: hostile ? .35 : .43),
            palette.energy.withValues(alpha: .14),
            palette.energy.withValues(alpha: 0),
          ], [
            0, .46, 1
          ]));
    for (var i = 0; i < 3; i++) {
      final jitter = math.sin(phase + i * 2.6);
      final mote = Offset(
          math.sin(phase * .44 + i * 2.1) * (hostile ? 6 : 8),
          12 + i * (hostile ? 5.0 : 8.0) + jitter * 2);
      canvas.drawCircle(
          mote,
          hostile ? .8 : 1.1,
          Paint()..color = palette.accent.withValues(alpha: .32 + .2 * jitter.abs()));
    }
    canvas.restore();
  }

  static void drawPlayerOverlay(
      Canvas canvas, Offset center, String id, double time) {
    _drawOverlay(canvas, center, 0, id, time, hostile: false);
  }

  static void drawEnemyOverlay(Canvas canvas, Offset center, Offset velocity,
      String id, double time) {
    _drawOverlay(canvas, center,
        math.atan2(velocity.dy, velocity.dx) + math.pi / 2,
        id, time, hostile: true);
  }

  static void _drawOverlay(Canvas canvas, Offset center, double angle,
      String id, double time, {required bool hostile}) {
    final palette = _palettes[id] ?? _boss;
    final shimmer = .5 + .5 * math.sin(time * 23 + center.dx * .037);
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(angle);
    canvas.scale(hostile ? .76 : 1.0);
    final accent = Paint()
      ..color = palette.accent.withValues(alpha: .72 + shimmer * .23)
      ..strokeWidth = 1.45
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    final core = Paint()..color = palette.core.withValues(alpha: .89);

    switch (id) {
      case 'astralis':
        final star = Path();
        for (var i = 0; i < 10; i++) {
          final a = -math.pi / 2 + i * math.pi / 5;
          final r = i.isEven ? 9.5 : 4.0;
          final p = Offset(math.cos(a) * r, math.sin(a) * r);
          if (i == 0) {
            star.moveTo(p.dx, p.dy);
          } else {
            star.lineTo(p.dx, p.dy);
          }
        }
        star.close();
        canvas.drawPath(star, Paint()..color = palette.energy.withValues(alpha: .55));
        canvas.drawPath(star, accent);
        canvas.drawCircle(Offset.zero, 2.7, core);
        break;
      case 'temperstryx':
        final lightning = Path()
          ..moveTo(2, -15)
          ..lineTo(-5, -3)
          ..lineTo(1, -2)
          ..lineTo(-3, 12)
          ..lineTo(7, -2)
          ..lineTo(1, -3)
          ..lineTo(2, -15);
        canvas.drawPath(lightning,
            Paint()..color = palette.energy.withValues(alpha: .69));
        canvas.drawPath(lightning, accent);
        canvas.drawLine(const Offset(-8, 1), const Offset(-4, 5), accent);
        canvas.drawLine(const Offset(7, -7), const Offset(11, -11), accent);
        break;
      case 'ignivar':
        final flame = Path()
          ..moveTo(0, -15)
          ..cubicTo(10, -5, 10, 5, 0, 12)
          ..cubicTo(-10, 5, -9, -5, 0, -15)
          ..close();
        canvas.drawPath(flame,
            Paint()..color = palette.energy.withValues(alpha: .72));
        canvas.drawPath(flame, accent);
        final tongue = Path()
          ..moveTo(0, -11)
          ..quadraticBezierTo(-4, 0, 0, 8)
          ..quadraticBezierTo(4, 0, 0, -11);
        canvas.drawPath(tongue, core);
        break;
      case 'nyxariel':
        // Two thin, offset shadow crescents rather than a generic orb.
        canvas.drawArc(const Rect.fromLTWH(-10, -13, 20, 26),
            -.85 * math.pi, 1.7 * math.pi, false, accent);
        canvas.drawArc(const Rect.fromLTWH(-5, -11, 17, 23),
            .12 * math.pi, 1.5 * math.pi, false,
            Paint()
              ..color = palette.core.withValues(alpha: .72)
              ..style = PaintingStyle.stroke
              ..strokeWidth = 1.4);
        canvas.drawCircle(Offset.zero, 2.0, core);
        break;
      case 'solarion':
        canvas.drawCircle(Offset.zero, 7.2,
            Paint()..color = palette.energy.withValues(alpha: .52));
        for (var i = 0; i < 8; i++) {
          final a = i * math.pi / 4 + time * .19;
          final inner = Offset(math.cos(a) * 8, math.sin(a) * 8);
          final outer = Offset(math.cos(a) * (i.isEven ? 14 : 12),
              math.sin(a) * (i.isEven ? 14 : 12));
          canvas.drawLine(inner, outer, accent);
        }
        canvas.drawCircle(Offset.zero, 3.9, core);
        break;
      case 'aquaryth':
        for (var side = -1; side <= 1; side += 2) {
          final helix = Path()..moveTo(0, -14);
          for (var i = 1; i <= 9; i++) {
            final y = -14 + i * 3.1;
            final x = side * math.sin(i * .77 + time * 6) * 6;
            helix.lineTo(x, y);
          }
          canvas.drawPath(helix, accent);
        }
        canvas.drawCircle(Offset.zero, 2.7, core);
        break;
      default:
        // Boss projectiles retain their legacy sprites, with a red-violet
        // warning rim and a small diamond at the center.
        final diamond = Path()
          ..moveTo(0, -10)
          ..lineTo(8, 0)
          ..lineTo(0, 10)
          ..lineTo(-8, 0)
          ..close();
        canvas.drawPath(diamond, accent);
        canvas.drawCircle(Offset.zero, 2.1, core);
    }
    canvas.restore();
  }
}

/// Capped, sub-quarter-second feedback for launch and impact. Kept separate
/// from damage and hitbox calculations so it can never alter combat rules.
class PremiumProjectileImpact {
  PremiumProjectileImpact(this.center, this.tint,
      {this.muzzle = false, this.hostile = false});

  final Offset center;
  final Color tint;
  final bool muzzle, hostile;
  double age = 0;

  double get duration => muzzle ? .14 : .23;

  void render(Canvas canvas) {
    final progress = (age / duration).clamp(0.0, 1.0).toDouble();
    final opacity = (1 - progress) * (hostile ? .54 : .7);
    final radius = (muzzle ? 3.5 : 5.0) + progress * (muzzle ? 9 : 17);
    final ring = Paint()
      ..color = tint.withValues(alpha: opacity * .54)
      ..style = PaintingStyle.stroke
      ..strokeWidth = (1.8 - progress).clamp(.55, 1.8).toDouble();
    canvas.drawCircle(center, radius, ring);
    final spokes = muzzle ? 4 : 6;
    final rotation = center.dx * .017 + center.dy * .012;
    for (var i = 0; i < spokes; i++) {
      final a = i * math.pi * 2 / spokes + rotation;
      final inner = Offset(
          center.dx + math.cos(a) * radius * .55,
          center.dy + math.sin(a) * radius * .55);
      final outer = Offset(
          center.dx + math.cos(a) * (radius + 2.8),
          center.dy + math.sin(a) * (radius + 2.8));
      canvas.drawLine(inner, outer,
          Paint()
            ..color = tint.withValues(alpha: opacity * .75)
            ..strokeWidth = muzzle ? .9 : 1.3
            ..strokeCap = StrokeCap.round);
    }
    canvas.drawCircle(center, (muzzle ? 2.5 : 4) * (1 - progress),
        Paint()..color = Colors.white.withValues(alpha: opacity * .33));
  }
}

class _MagicPalette {
  const _MagicPalette(this.core, this.energy, this.accent);
  final Color core, energy, accent;
}
