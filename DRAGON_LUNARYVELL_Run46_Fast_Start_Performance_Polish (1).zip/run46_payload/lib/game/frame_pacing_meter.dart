/// Lightweight frame-pacing diagnostics for the built-in developer test hub.
/// It does no allocations during sample() and never changes gameplay speed.
class FramePacingMeter {
  double fps = 60;
  double worstFrameMs = 0;
  int hitchCount = 0;

  double _windowSeconds = 0;
  int _windowFrames = 0;

  void sample(double elapsedSeconds) {
    // Ignore app suspension/resume gaps; they are not rendering hitches.
    if (elapsedSeconds <= 0 || elapsedSeconds > .50) return;
    _windowSeconds += elapsedSeconds;
    _windowFrames++;
    final millis = elapsedSeconds * 1000;
    if (millis > worstFrameMs) worstFrameMs = millis;
    if (elapsedSeconds > .034) hitchCount++;
    if (_windowSeconds >= .75) {
      fps = (_windowFrames / _windowSeconds)
          .clamp(1.0, 240.0).toDouble();
      _windowSeconds = 0;
      _windowFrames = 0;
    }
  }

  void reset() {
    fps = 60;
    worstFrameMs = 0;
    hitchCount = 0;
    _windowSeconds = 0;
    _windowFrames = 0;
  }

  String get diagnosticLine =>
      'Frame ${fps.toStringAsFixed(0)} FPS  •  '
      'Slow $hitchCount  •  Peak ${worstFrameMs.toStringAsFixed(0)}ms';
}
