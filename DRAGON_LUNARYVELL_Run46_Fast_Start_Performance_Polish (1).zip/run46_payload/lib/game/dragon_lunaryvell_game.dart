import 'dart:async' show unawaited;
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'dragon_profile.dart';
import 'special_ability_rules.dart';
import 'campaign_story.dart';
import 'dragon_flight_cycle.dart';
import 'premium_projectile_fx.dart';
import 'enemy_archetypes.dart';
import 'boss_encounter_rules.dart';
import 'boss_encounter_fx.dart';
import 'frame_pacing_meter.dart';

class DragonHudState {
  const DragonHudState({
    this.score = 0,
    this.wave = 1,
    this.health = 3,
    this.paused = false,
    this.bossActive = false,
    this.dragonName = 'ASTRALIS',
    this.specialRemaining = 0,
    this.specialMax = 11,
    this.hasteRemaining = 0,
    this.critRemaining = 0,
    this.shields = 0,
    this.campaignMode = false,
    this.campaignIntermission = false,
    this.campaignComplete = false,
    this.chapterTitle = '',
  });
  final int score;
  final int wave;
  final int health;
  final bool paused;
  final bool bossActive;
  final String dragonName;
  final double specialRemaining;
  final double specialMax;
  final double hasteRemaining, critRemaining;
  final int shields;
  final bool campaignMode, campaignIntermission, campaignComplete;
  final String chapterTitle;

  DragonHudState copyWith(
          {int? score,
          int? wave,
          int? health,
          bool? paused,
          bool? bossActive,
          String? dragonName,
          double? specialRemaining,
          double? specialMax,
          double? hasteRemaining,
          double? critRemaining,
          int? shields,
          bool? campaignMode,
          bool? campaignIntermission,
          bool? campaignComplete,
          String? chapterTitle}) =>
      DragonHudState(
        score: score ?? this.score,
        wave: wave ?? this.wave,
        health: health ?? this.health,
        paused: paused ?? this.paused,
        bossActive: bossActive ?? this.bossActive,
        dragonName: dragonName ?? this.dragonName,
        specialRemaining: specialRemaining ?? this.specialRemaining,
        specialMax: specialMax ?? this.specialMax,
        hasteRemaining: hasteRemaining ?? this.hasteRemaining,
        critRemaining: critRemaining ?? this.critRemaining,
        shields: shields ?? this.shields,
        campaignMode: campaignMode ?? this.campaignMode,
        campaignIntermission: campaignIntermission ?? this.campaignIntermission,
        campaignComplete: campaignComplete ?? this.campaignComplete,
        chapterTitle: chapterTitle ?? this.chapterTitle,
      );
}

class _Bolt {
  _Bolt(this.x, this.y, this.dragonId);
  double x, y;
  final double speed = 520;
  final String dragonId;
}

class _EnemyBolt {
  _EnemyBolt(this.x, this.y, this.vx, this.vy, {this.typeIndex = -1});
  double x, y;
  final double vx, vy;
  final int typeIndex;
}

class _Foe {
  _Foe(
      {required this.x,
      required this.y,
      required this.hp,
      required this.radius,
      required this.speed,
      this.boss = false,
      this.typeIndex = 0,
      this.spriteSize = 60,
      this.shield = 0}) {
    maxHealth = hp;
    maxShield = shield;
    homeX = x;
  }
  double x, y, hp, radius, speed, spriteSize;
  late final double maxHealth, maxShield, homeX;
  double shield;
  double patternClock = 0;
  double shieldHitRemaining = 0;
  double shieldRecoverClock = 0;
  int volleysFired = 0;
  bool boss;
  int typeIndex;
  double fireClock = 0;
  double animationClock = 0;
  int animationFrame = 0;
}

class _SpellLine {
  _SpellLine(this.from, this.to, this.color, this.kind,
      {this.life = .66})
      : initialLife = life;
  final Offset from, to;
  final Color color;
  final String kind;
  final double initialLife;
  double life;
}

class _SeekingFlame {
  _SeekingFlame(this.x, this.y, this.target, this.seed)
      : previous = Offset(x, y);
  double x, y;
  Offset previous;
  _Foe? target;
  final int seed;
  double life = 2.1;
}

class _SolarMark {
  _SolarMark(this.target, this.position, this.delay);
  _Foe? target;
  Offset position;
  double delay;
}

class _SpellZone {
  _SpellZone(this.kind, this.center, this.radius, this.life)
      : initialLife = life;
  final String kind;
  final Offset center;
  final double radius, initialLife;
  double life;
  double pulse = 0;
}

enum _PickupKind { haste, critical, shield }

class _Pickup {
  _Pickup(this.x, this.y, this.kind);
  double x, y;
  final _PickupKind kind;
  double age = 0;
}

class _DefeatGlimmer {
  _DefeatGlimmer(this.center, this.tint);
  final Offset center;
  final Color tint;
  double age = 0;
  static const double duration = .26;
}

class DragonLunaryvellGame extends FlameGame {
  DragonLunaryvellGame({this.dragon = DragonProfile.astralis,
    this.campaignMode = false});
  DragonProfile dragon;
  final bool campaignMode;
  bool _campaignIntermission = false;
  bool _campaignComplete = false;
  final ValueNotifier<DragonHudState> hud =
      ValueNotifier(const DragonHudState());
  final List<_Bolt> _bolts = [];
  final List<_EnemyBolt> _enemyBolts = [];
  final List<_Foe> _foes = [];
  final math.Random _random = math.Random(17);
  final FramePacingMeter _framePacing = FramePacingMeter();

  double _playerX = 0, _playerY = 0;
  double _targetX = 0, _targetY = 0;
  double _fireClock = 0, _spawnClock = 0, _hudClock = 0;
  double _waveElapsed = 0;
  double _waveBannerRemaining = 1.6;
  double _playerInvulnerable = 0;
  double _bossAttackClock = 0;
  double _bossFlightClock = 0;
  double _bossChargeRemaining = 0;
  double _bossChargeDuration = 0;
  double _bossHitPulse = 0;
  double _bossPhasePulse = 0;
  int _bossVolleys = 0;
  BossCombatPhase _bossPhase = BossCombatPhase.guarded;
  List<BossShotVector> _bossPreparedShots = <BossShotVector>[];
  double _specialCooldown = 0;
  double _specialClock = 0;
  double _specialInitialClock = .75;
  double _fxTime = 0;
  Offset _specialOrigin = Offset.zero;
  Offset _dashOrigin = Offset.zero;
  String _activeSpecialId = 'astralis';
  final List<_SpellLine> _spellLines = [];
  final List<_SeekingFlame> _seekingFlames = [];
  final List<_SolarMark> _solarMarks = [];
  _SpellZone? _spellZone;
  final List<_Pickup> _pickups = [];
  final List<_DefeatGlimmer> _defeatGlimmers = [];
  // Bounded, short-lived feedback; this never participates in collision.
  final List<PremiumProjectileImpact> _projectileImpacts = [];
  double _hasteRemaining = 0;
  double _critRemaining = 0;
  double _shieldRemaining = 0;
  double _shieldPulse = 0;
  int _shieldCharges = 0;
  int _spawnedThisWave = 0, _defeatedThisWave = 0;
  int _score = 0, _wave = 1, _health = 3;
  bool _touching = false, _paused = false, _gameOver = false;
  // Developer-only testing state: no effect in normal player sessions.
  bool _developerPanelOpen = false;
  bool _developerShowcase = false;
  _Foe? _boss;
  List<ui.Image> _flightFrames = [];
  List<List<ui.Image>> _enemyFrames = [];
  static const _enemyRadii = <double>[15, 17, 19, 20, 18, 19];
  static const _enemySpeeds = <double>[78, 68, 58, 56, 83, 70];
  static const _enemySpriteSizes = <double>[64, 72, 82, 90, 84, 88];
  static const _enemyMagicIds = <String>[
    'solarion', 'temperstryx', 'nyxariel',
    'aquaryth', 'ignivar', 'astralis',
  ];
  static const _run43EnemyNames = <String>[
    'crystal_gargoyle', 'ember_manticore', 'void_moth',
  ];
  ui.Image? _battlefieldArt;
  // Optional chapter scenery and complete 8-frame boss cycles. Every boss
  // uses the same flight cadence as the existing animated player dragons.
  final List<ui.Image?> _chapterBattlefieldArt =
      List<ui.Image?>.filled(5, null);
  final List<List<ui.Image>> _chapterBossFrames =
      List<List<ui.Image>>.generate(5, (_) => <ui.Image>[]);
  static const double _chapterFadeSeconds = 1.4;
  int _currentChapterScene = 0;
  int? _outgoingChapterScene;
  double _chapterFadeRemaining = 0;
  double _flightClock = 0;
  int _flightFrame = 0;
  double _wingMotionSeconds = 0;
  double _flightBank = 0;
  static const double _dragonCrossfadeSeconds = .18;
  DragonProfile? _outgoingDragon;
  double _dragonCrossfadeRemaining = 0;
  final Map<String, ui.Image> _run31DragonStills = {};
  final Map<String, List<ui.Image>> _run32DragonFlights = {};
  final Map<String, List<ui.Image>> _run42DragonFlights = {};
  final Map<String, Future<void>> _run42LoadsInProgress = {};
  int _dragonSelectionEpoch = 0;
  List<ui.Image> _run32PlayerBoltFrames = [];
  List<ui.Image> _run32EnemyBoltFrames = [];
  final Map<String, List<ui.Image>> _run43PlayerMagic = {};
  final Map<String, List<ui.Image>> _run43EnemyMagic = {};
  final Map<String, Future<void>> _run43PlayerLoads = {};
  ui.Image? _run31BossImage;
  // Sprite file names use 'tempestryx'; the existing profile ID is
  // 'temperstryx'. Keep that historical ID so saves and selection still work.
  static const Map<String, String> _run32DragonPaths = {
    'temperstryx': 'tempestryx',
    'ignivar': 'ignivar',
    'nyxariel': 'nyxariel',
    'solarion': 'solarion',
    'aquaryth': 'aquaryth',
  };
  static const Map<String, String> _run31DragonPaths = {
    'temperstryx': 'run31/dragons/tempestryx_flight_base.png',
    'ignivar': 'run31/dragons/ignivar_flight_base.png',
    'nyxariel': 'run31/dragons/nyxariel_flight_base.png',
    'solarion': 'run31/dragons/solarion_flight_base.png',
    'aquaryth': 'run31/dragons/aquaryth_flight_base.png',
  };

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    // Start these loads together. Finish them before Flame's first gameplay
    // frame so the previous gradient, shape-only enemies, or older dragon
    // stills never flash underneath Run 38 artwork for a frame.
    final battlefieldReady = _preloadBattlefield();
    final enemiesReady = _preloadEnemySprites();
    final projectilesReady = _preloadRun32Projectiles();
    final selectedMagicReady = _loadRun43PlayerMagic(dragon.id);
    final selectedDragonReady = _loadDragonArtwork(dragon);
    _flightFrames = await Future.wait(
      List.generate(
        8,
        (i) => images.load(
          'dragons/astralis/flight/astralis_flight_wing_${i.toString().padLeft(2, '0')}.png',
        ),
      ),
    );
    await Future.wait<void>([
      battlefieldReady, enemiesReady,
      projectilesReady, selectedDragonReady, selectedMagicReady,
    ]);
    // Run 46: the four future chapter JPEGs are *not* part of the opening
    // load. They decode after first gameplay paint and fade in only when
    // needed; this removes a large batch of work from cold phone startup.
    unawaited(_preloadChapterScenery());
    // Decode optional Run 31 artwork in the background, not on the critical
    // path for the existing eight-frame ASTRALIS animation.
    unawaited(_preloadRun31Assets());
    // Decode other dragons in the background. Each 16-frame cycle is
    // activated atomically, never one frame at a time while the user flies.
    unawaited(_preloadRun42DragonCycles());
    // Boss cycles are decoded in the background to keep first launch quick.
    // All eight frames of a chapter become active atomically after loading.
    unawaited(_preloadRun41BossFrames());
    // Extra enemy families and non-selected spell colors decode after launch,
    // so premium art does not make the phone sit on the loading screen.
    unawaited(_preloadRun43EnemiesAndMagic());
    // The loadingBuilder remains visible during the parallel decode above.
  }

  Future<void> _preloadBattlefield() async {
    try {
      _battlefieldArt = await images.load(
          'run38/backgrounds/battlefield_moon_citadel.png');
    } catch (error) {
      debugPrint('Optional Run 38 scenery unavailable: $error');
    }
  }

  Future<void> _preloadChapterScenery() async {
    const scenes = <String>[
      '',
      'run41/backgrounds/ember_spires.jpg',
      'run41/backgrounds/moonveil_abyss.jpg',
      'run41/backgrounds/glacier_cathedral.jpg',
      'run41/backgrounds/eclipse_throne.jpg',
    ];
    // A bounded sequential queue avoids decoding four big JPGs together.
    for (var tier = 1; tier <= 4; tier++) {
      try {
        _chapterBattlefieldArt[tier] = await images.load(scenes[tier]);
        // If a tester jumped to this chapter before it decoded, start a
        // fresh eased dissolve instead of popping the artwork in abruptly.
        final activeTier = ((_wave - 1) ~/ 5).clamp(0, 4).toInt();
        if (tier == activeTier && _chapterFadeRemaining == 0) {
          _outgoingChapterScene = tier - 1;
          _chapterFadeRemaining = _chapterFadeSeconds;
        }
      } catch (error) {
        debugPrint('Optional chapter $tier scene unavailable: $error');
      }
    }
  }

  Future<void> _preloadRun41BossFrames() async {
    const bosses = <String>[
      'eclipse_gargoyle_warden',
      'ashen_drake_colossus',
      'moonveil_serpent',
      'frost_harpy_matriarch',
      'eclipse_sovereign',
    ];
    // Chapter I loads first; the remaining assets do not block play or
    // introduce temporary half-frame animations while decoding.
    for (var chapter = 0; chapter < bosses.length; chapter++) {
      try {
        final name = bosses[chapter];
        final frames = await Future.wait(List.generate(8, (i) => images.load(
          'run41/bosses/${name}_${i.toString().padLeft(2, '0')}.png',
        )));
        if (frames.length == 8) _chapterBossFrames[chapter] = frames;
      } catch (error) {
        debugPrint('Optional animated chapter boss $chapter unavailable: $error');
      }
    }
  }

  Future<void> _preloadEnemySprites() async {
    try {
      // Three remastered enemies now have distinct painted up/down/recovery
      // wing poses instead of barely changing 3-frame originals.
      _enemyFrames = await Future.wait(<Future<List<ui.Image>>>[
        Future.wait(List.generate(8, (i) => images.load(
            'run38/enemies/goblin_sky_raider/goblin_${i.toString().padLeft(2, '0')}.png'))),
        Future.wait(List.generate(7, (i) => images.load(
            'run38/enemies/harpy/harpy_${i.toString().padLeft(2, '0')}.png'))),
        Future.wait(List.generate(7, (i) => images.load(
            'run38/enemies/shadow_wyvern/shadow_wyvern_${i.toString().padLeft(2, '0')}.png'))),
      ]);
    } catch (error) {
      debugPrint('Run 38 enemies unavailable, trying original art: $error');
      try {
        _enemyFrames = await Future.wait(<Future<List<ui.Image>>>[
          Future.wait(List.generate(4, (i) => images.load(
              'enemies/goblin_sky_raider/goblin_${i.toString().padLeft(2, '0')}.png'))),
          Future.wait(List.generate(3, (i) => images.load(
              'enemies/harpy/harpy_${i.toString().padLeft(2, '0')}.png'))),
          Future.wait(List.generate(3, (i) => images.load(
              'enemies/shadow_wyvern/shadow_wyvern_${i.toString().padLeft(2, '0')}.png'))),
        ]);
      } catch (fallbackError) {
        debugPrint('Optional enemy art unavailable: $fallbackError');
      }
    }
    // Keep fixed type indices even if one optional legacy family failed.
    while (_enemyFrames.length < 6) {
      _enemyFrames.add(<ui.Image>[]);
    }
  }

  Future<void> _preloadRun43EnemiesAndMagic() async {
    for (var i = 0; i < _run43EnemyNames.length; i++) {
      final name = _run43EnemyNames[i];
      try {
        final frames = await Future.wait(List.generate(12, (frame) =>
            images.load('run43/enemies/$name/${name}_${frame.toString().padLeft(2, '0')}.png')));
        // Publish the complete cycle together: no missing-frame flash.
        _enemyFrames[i + 3] = frames;
      } catch (error) {
        debugPrint('Run 43 optional enemy $name unavailable: $error');
      }
    }
    for (final id in _enemyMagicIds) {
      try {
        final frames = await Future.wait(List.generate(4, (frame) =>
            images.load('run43/projectiles/enemy/$id/${id}_${frame.toString().padLeft(2, '0')}.png')));
        _run43EnemyMagic[id] = frames;
      } catch (error) {
        debugPrint('Run 43 optional enemy spell $id unavailable: $error');
      }
    }
    for (final profile in DragonProfile.all) {
      if (profile.id != dragon.id) await _loadRun43PlayerMagic(profile.id);
    }
  }

  Future<void> _loadRun43PlayerMagic(String id) {
    if (_run43PlayerMagic.containsKey(id)) return Future<void>.value();
    return _run43PlayerLoads.putIfAbsent(id, () async {
      try {
        final frames = await Future.wait(List.generate(4, (frame) =>
            images.load('run43/projectiles/player/$id/${id}_${frame.toString().padLeft(2, '0')}.png')));
        _run43PlayerMagic[id] = frames;
      } catch (error) {
        debugPrint('Run 43 optional dragon breath $id unavailable: $error');
      }
    });
  }

  Future<void> _preloadRun32Projectiles() async {
    try {
      _run32PlayerBoltFrames = await Future.wait(List.generate(
        3,
        (i) => images.load(
          'projectiles/player/celestial_bolt_${i.toString().padLeft(2, '0')}.png',
        ),
      ));
    } catch (error) {
      debugPrint('Existing player projectile sprites unavailable: $error');
    }
    try {
      _run32EnemyBoltFrames = await Future.wait(List.generate(
        3,
        (i) => images.load(
          'projectiles/enemy/ember_bolt_${i.toString().padLeft(2, '0')}.png',
        ),
      ));
    } catch (error) {
      debugPrint('Existing enemy projectile sprites unavailable: $error');
    }
  }

  Future<void> _preloadRun31Assets() async {
    // Run 31 artwork is optional at runtime: preserve existing sprites if a
    // new asset is absent, and keep the ASTRALIS flight cycle untouched.
    try {
      _run31BossImage =
          await images.load('run31/bosses/eclipse_gargoyle_warden.png');
    } catch (error) {
      debugPrint('Run 31 boss art unavailable: $error');
    }
    // Run 36 draws unique lightweight 2D ability effects. Preserve the old
    // illustrations on disk as references but do not decode or overlay them.
  }

  @override
  void onRemove() {
    hud.dispose();
    super.onRemove();
  }

  @override
  Color backgroundColor() => const Color(0xFF050817);

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    if (_playerX == 0) {
      _playerX = size.x / 2;
      _playerY = size.y * .78;
      _targetX = _playerX;
      _targetY = _playerY;
    }
  }

  void setTouchTarget(Offset point) {
    if (size.x <= 0 || size.y <= 0) return;
    _touching = true;
    // Full-screen free flight. Only the dragon's visible half-width/height
    // remain on screen; there is no artificial 38%-from-top restriction.
    final left = math.min(43.0, size.x / 2);
    final top = math.min(57.0, size.y / 2);
    _targetX = point.dx.clamp(left, math.max(left, size.x - left)).toDouble();
    _targetY = point.dy.clamp(top, math.max(top, size.y - top)).toDouble();
  }

  void releaseTouch() => _touching = false;

  Future<void> selectDragon(DragonProfile profile) async {
    final request = ++_dragonSelectionEpoch;
    if (profile.id == dragon.id) return;
    // Keep rendering the CURRENT complete dragon until the replacement's
    // whole flight loop has decoded; this prevents a temporary flat vector
    // placeholder and partial animation on the switching frame.
    await Future.wait<void>([
      _loadDragonArtwork(profile), _loadRun43PlayerMagic(profile.id),
    ]);
    if (request != _dragonSelectionEpoch) return;
    _outgoingDragon = dragon;
    _dragonCrossfadeRemaining = _dragonCrossfadeSeconds;
    dragon = profile;
    _specialClock = 0;
    // Preserve the wingbeat's exact phase across dragon switches.
    _flightBank = 0;
    _publishHud(force: true);
  }

  Future<void> _preloadRun42DragonCycles() async {
    for (final entry in _run32DragonPaths.entries) {
      await _loadRun42Dragon(entry.key, entry.value);
    }
  }

  Future<void> _loadRun42Dragon(String id, String name) {
    if (_run42DragonFlights.containsKey(id)) return Future<void>.value();
    // A developer's rapid switches and the idle preloader share this Future;
    // the same 16 PNGs never decode twice simultaneously.
    return _run42LoadsInProgress.putIfAbsent(id, () async {
      try {
        final frames = await Future.wait(List.generate(16, (i) => images.load(
          'run42/dragons/$name/flight/${name}_flight_${i.toString().padLeft(2, '0')}.png',
        )));
        if (frames.length == 16) _run42DragonFlights[id] = frames;
      } catch (error) {
        debugPrint('Optional Run 42 dragon cycle unavailable: $id $error');
      }
    });
  }

  Future<void> _loadDragonArtwork(DragonProfile profile) async {
    // Run 38: all six playable dragons have eight actual painted frames,
    // identically registered and sampled at ASTRALIS's exact 100ms cadence.
    // Run 42 adds five 16-frame refined cycles at 50ms each (still 0.8s);
    // Run 38/34 art remains an emergency fallback.
    final flightName = _run32DragonPaths[profile.id];
    if (flightName != null) {
      await _loadRun42Dragon(profile.id, flightName);
    }
    if (flightName != null && !_run42DragonFlights.containsKey(profile.id) &&
        !_run32DragonFlights.containsKey(profile.id)) {
      try {
        _run32DragonFlights[profile.id] = await Future.wait(List.generate(
          8,
          (i) => images.load(
            'run38/dragons/$flightName/flight/${flightName}_flight_${i.toString().padLeft(2, '0')}.png',
          ),
        ));
      } catch (error) {
        debugPrint('Run 38 dragon animation unavailable; using Run 34: $error');
        try {
          _run32DragonFlights[profile.id] = await Future.wait(List.generate(
            4,
            (i) => images.load(
              'run32/dragons/$flightName/flight/${flightName}_flight_${i.toString().padLeft(2, '0')}.png',
            ),
          ));
        } catch (fallbackError) {
          debugPrint('Legacy dragon flight unavailable: $fallbackError');
        }
      }
    }
    if (!_run42DragonFlights.containsKey(profile.id) &&
        !_run32DragonFlights.containsKey(profile.id)) {
      final stillPath = _run31DragonPaths[profile.id];
      if (stillPath != null && !_run31DragonStills.containsKey(profile.id)) {
        try {
          _run31DragonStills[profile.id] = await images.load(stillPath);
        } catch (error) {
          debugPrint('Run 31 dragon art unavailable: $error');
        }
      }
    }
  }

  void togglePause() {
    if (_gameOver || _campaignIntermission || _campaignComplete) return;
    _paused = !_paused;
    _publishHud(force: true);
  }

  @override
  void update(double dt) {
    super.update(dt);
    _framePacing.sample(dt);
    if (_developerPanelOpen || _paused || _gameOver || size.x <= 0 || size.y <= 0) return;
    final step = dt.clamp(0.0, .05).toDouble();
    if (_chapterFadeRemaining > 0) {
      _chapterFadeRemaining =
          math.max(0.0, _chapterFadeRemaining - step).toDouble();
      if (_chapterFadeRemaining == 0) _outgoingChapterScene = null;
    }
    if (_dragonCrossfadeRemaining > 0) {
      _dragonCrossfadeRemaining =
          math.max(0.0, _dragonCrossfadeRemaining - step).toDouble();
      if (_dragonCrossfadeRemaining == 0) _outgoingDragon = null;
    }
    _wingMotionSeconds += step;
    _waveBannerRemaining = math.max(0.0, _waveBannerRemaining - step).toDouble();
    for (final glimmer in _defeatGlimmers) {
      glimmer.age += step;
    }
    _defeatGlimmers.removeWhere((fx) =>
        fx.age >= _DefeatGlimmer.duration);
    for (final impact in _projectileImpacts) {
      impact.age += step;
    }
    _projectileImpacts.removeWhere((impact) => impact.age >= impact.duration);
    _bossHitPulse = math.max(0.0, _bossHitPulse - step * 2.6).toDouble();
    _bossPhasePulse = math.max(0.0, _bossPhasePulse - step * 1.2).toDouble();
    if (_flightFrames.isNotEmpty) {
      _flightClock += step;
      while (_flightClock >= .1) {
        _flightClock -= .1;
        _flightFrame = (_flightFrame + 1) % _flightFrames.length;
      }
    }
    if (_specialCooldown > 0) {
      _specialCooldown = math.max(0.0, _specialCooldown - step).toDouble();
    }
    if (_specialClock > 0) {
      _specialClock = math.max(0.0, _specialClock - step).toDouble();
    }
    _waveElapsed += step;
    if (_playerInvulnerable > 0) {
      _playerInvulnerable =
          math.max(0.0, _playerInvulnerable - step).toDouble();
    }

    if (_touching) {
      // Close finger-following without instantaneous teleportation; keep the
      // haste pickup meaningfully faster while preserving smooth movement.
      final blend = (step * (_hasteRemaining > 0 ? 25 : 18))
          .clamp(0.0, 1.0).toDouble();
      _playerX += (_targetX - _playerX) * blend;
      _playerY += (_targetY - _playerY) * blend;
    }
    final bankGoal = _touching
        ? ((_targetX - _playerX) / math.max(120.0, size.x))
            .clamp(-.075, .075).toDouble()
        : 0.0;
    _flightBank += (bankGoal - _flightBank) *
        (step * 7).clamp(0.0, 1.0).toDouble();

    _updateSpecialsAndPickups(step);

    _fireClock += step;
    if (_fireClock >= .22) {
      _fireClock = 0;
      _bolts.add(_Bolt(_playerX, _playerY - 22, dragon.id));
      _addProjectileImpact(Offset(_playerX, _playerY - 22),
          PremiumProjectileFx.colorFor(dragon.id), muzzle: true);
    }

    final quota = 7 + _wave * 2;
    final bossWave = _wave % 5 == 0;
    if (!_developerShowcase && _boss == null && _spawnedThisWave < quota) {
      _spawnClock += step;
      final interval = math.max(.32, .95 - _wave * .035);
      if (_spawnClock >= interval) {
        _spawnClock = 0;
        _spawnedThisWave++;
        // Three established enemies appear immediately. New premium families
        // arrive gradually in waves 4 and 8, never all at once on wave one.
        final available = _wave >= 8 ? 6 : _wave >= 4 ? 5 : 3;
        final enemyType = _random.nextInt(available);
        final enemyRadius = _enemyRadii[enemyType];
        final archetype = EnemyArchetypes.forType(enemyType);
        final enemySpeed = (_enemySpeeds[enemyType] + _wave * 4) *
            archetype.speedFactor;
        final enemySize = _enemySpriteSizes[enemyType];
        _foes.add(_Foe(
          x: 24 + _random.nextDouble() * math.max(1.0, size.x - 48).toDouble(),
          y: -24,
          hp: archetype.healthAtWave(_wave),
          shield: archetype.shieldAtWave(_wave),
          radius: enemyRadius,
          speed: enemySpeed,
          typeIndex: enemyType,
          spriteSize: enemySize,
        ));
      }
    }

    for (final bolt in _bolts) {
      bolt.y -= bolt.speed * step;
    }
    _bolts.removeWhere((b) => b.y < -30);

    for (final foe in _foes) {
      final archetype = EnemyArchetypes.forType(foe.typeIndex);
      foe.patternClock += step;
      foe.shieldHitRemaining = math.max(
          0.0, foe.shieldHitRemaining - step).toDouble();
      if (archetype.ability == EnemyAbilityStyle.crystalRegeneration &&
          foe.maxShield > 0 && foe.shield < foe.maxShield) {
        foe.shieldRecoverClock += step;
        if (foe.shieldRecoverClock > 4.8) {
          foe.shield = math.min(
              foe.maxShield, foe.shield + .30 * step).toDouble();
        }
      }
      if (foe.typeIndex >= 0 && foe.typeIndex < _enemyFrames.length) {
        final frames = _enemyFrames[foe.typeIndex];
        if (frames.isNotEmpty) {
          foe.animationClock += step;
          // Twelve Run 43 poses complete the same 800ms wingbeat as the
          // original 8-frame dragons, rather than flapping 50% too slowly.
          final frameSeconds = frames.length == 12 ? .8 / 12 : .1;
          while (foe.animationClock >= frameSeconds) {
            foe.animationClock -= frameSeconds;
            foe.animationFrame = (foe.animationFrame + 1) % frames.length;
          }
        }
      }
      final enraged = archetype.ability == EnemyAbilityStyle.emberRage &&
          foe.hp < foe.maxHealth * .5;
      foe.y += foe.speed * archetype.verticalMultiplier(foe.patternClock) *
          (enraged ? 1.24 : 1.0) *
          (_spellZone?.kind == 'aquaryth' &&
                  _distance(foe.x, foe.y, _spellZone!.center.dx,
                          _spellZone!.center.dy) < _spellZone!.radius
              ? .44
              : 1.0) * step;
      // Each enemy owns a stable, species-specific flight signature.
      // Developer gallery specimens remain in place for visual inspection.
      if (!_developerShowcase) {
        final phase = foe.homeX * .021 + foe.typeIndex * 1.7;
        foe.x = (foe.homeX + archetype.horizontalOffset(
                foe.patternClock, phase))
            .clamp(foe.radius + 15, size.x - foe.radius - 15).toDouble();
      }
      foe.fireClock += step;
      if (foe.fireClock >= archetype.attackIntervalAtWave(_wave) *
              (enraged ? .75 : 1.0) &&
          foe.y > 8 && foe.y < size.y * .72) {
        foe.fireClock = 0;
        _fireEnemyVolley(foe, archetype);
      }
    }

    for (final bolt in _bolts.toList()) {
      for (final foe in _foes.toList()) {
        if (_distance(bolt.x, bolt.y, foe.x, foe.y) < foe.radius + 5) {
          _addProjectileImpact(Offset(bolt.x, bolt.y),
              PremiumProjectileFx.colorFor(bolt.dragonId));
          _damageTarget(foe,
              _critRemaining > 0 && _random.nextDouble() < .25 ? 2 : 1);
          _bolts.remove(bolt);
          break;
        }
      }
    }

    for (final foe in _foes.toList()) {
      if (_distance(_playerX, _playerY, foe.x, foe.y) < foe.radius + 13) {
        _foes.remove(foe);
        _damagePlayer();
      } else if (foe.y > size.y + 25) {
        _foes.remove(foe);
        _damagePlayer();
      }
    }

    for (final shot in _enemyBolts) {
      shot.x += shot.vx * step;
      shot.y += shot.vy * step;
    }
    _enemyBolts.removeWhere(
        (shot) => shot.y > size.y + 24 || shot.x < -24 || shot.x > size.x + 24);
    for (final shot in _enemyBolts.toList()) {
      if (_distance(_playerX, _playerY, shot.x, shot.y) < 17) {
        final magicId = shot.typeIndex >= 0 &&
                shot.typeIndex < _enemyMagicIds.length
            ? _enemyMagicIds[shot.typeIndex]
            : '';
        _addProjectileImpact(Offset(shot.x, shot.y),
            PremiumProjectileFx.colorFor(magicId), hostile: true);
        _enemyBolts.remove(shot);
        _damagePlayer();
      }
    }

    if (!_developerShowcase && _spawnedThisWave >= quota &&
        _foes.isEmpty && _boss == null) {
      if (bossWave) {
        _summonBoss();
      } else {
        _advanceWave();
      }
    }

    if (_boss case final boss?) {
      boss.y = math.min(size.y * .23, boss.y + boss.speed * step).toDouble();
      _bossFlightClock += step * (1 + _bossPhase.index * .08);
      boss.x = (size.x / 2 + BossEncounterRules.horizontalOffset(
              _wave, _bossFlightClock, size.x))
          .clamp(boss.radius + 24, size.x - boss.radius - 24).toDouble();
      for (final bolt in _bolts.toList()) {
        if (_distance(bolt.x, bolt.y, boss.x, boss.y) < boss.radius + 5) {
          _addProjectileImpact(Offset(bolt.x, bolt.y),
              PremiumProjectileFx.colorFor(bolt.dragonId));
          _damageTarget(boss, 1);
          _bolts.remove(bolt);
        }
      }
      if (boss.hp <= 0) {
        _defeatBoss(boss);
      } else {
        final phase = BossEncounterRules.phaseForHealth(
            boss.hp, boss.maxHealth);
        if (phase != _bossPhase) {
          _bossPhase = phase;
          _bossPhasePulse = 1.0;
          // A phase shift cancels a queued volley. No untelegraphed fire.
          _bossChargeRemaining = 0;
          _bossPreparedShots = <BossShotVector>[];
          _bossAttackClock = 0;
        }
        if (_bossChargeRemaining > 0) {
          _bossChargeRemaining = math.max(0.0,
              _bossChargeRemaining - step).toDouble();
          if (_bossChargeRemaining == 0) _releaseBossVolley(boss);
        } else {
          _bossAttackClock += step;
          if (_bossAttackClock >=
                  BossEncounterRules.attackInterval(_wave, _bossPhase) &&
              boss.y > 0) {
            _bossAttackClock = 0;
            _bossPreparedShots = BossEncounterRules.volley(
                wave: _wave,
                phase: _bossPhase,
                originX: boss.x,
                originY: boss.y + boss.radius,
                targetX: _playerX,
                targetY: _playerY,
                volleyIndex: _bossVolleys);
            _bossChargeDuration = BossEncounterRules.warningSeconds(
                _wave, _bossPhase);
            _bossChargeRemaining = _bossChargeDuration;
          }
        }
        if (_distance(_playerX, _playerY, boss.x, boss.y) <
            boss.radius + 12) {
          _damagePlayer();
        }
      }
    }

    _hudClock += step;
    if (_hudClock >= .12) {
      _hudClock = 0;
      _publishHud();
    }
  }

  void _summonBoss({bool instant = false}) {
    _boss = _Foe(
      x: size.x / 2,
      y: instant ? size.y * .23 : -60,
      hp: 20 + _wave * 4,
      shield: BossEncounterRules.shieldForWave(_wave),
      radius: 34,
      speed: 48,
      boss: true,
    );
    _bossPhase = BossCombatPhase.guarded;
    _bossFlightClock = 0;
    _bossPhasePulse = .8;
    _bossHitPulse = 0;
    _bossAttackClock = 0;
    _bossChargeRemaining = 0;
    _bossChargeDuration = 0;
    _bossVolleys = 0;
    _bossPreparedShots = <BossShotVector>[];
    // The transition must not inherit off-screen shots from the last wave.
    _enemyBolts.clear();
  }

  void _releaseBossVolley(_Foe boss) {
    final magicType = BossEncounterRules.magicTypeForWave(_wave);
    for (final shot in _bossPreparedShots) {
      if (_enemyBolts.length >= 36) break;
      _enemyBolts.add(_EnemyBolt(
          boss.x + shot.sourceDx, boss.y + boss.radius,
          shot.vx, shot.vy, typeIndex: magicType));
    }
    if (_bossPreparedShots.isNotEmpty) {
      _addProjectileImpact(Offset(boss.x, boss.y + boss.radius),
          BossEncounterFx.hue(_wave), muzzle: true, hostile: true);
    }
    _bossVolleys++;
    _bossPreparedShots = <BossShotVector>[];
  }

  void _defeatBoss(_Foe boss) {
    final tint = BossEncounterFx.hue(_wave);
    // Compact dissolve: no frame-stalling screen flash and no lingering hitbox.
    for (final dx in <double>[-18, 0, 18]) {
      if (_defeatGlimmers.length >= 12) break;
      _defeatGlimmers.add(_DefeatGlimmer(
          Offset(boss.x + dx, boss.y + dx.abs() * .25), tint));
    }
    _score += 2500 + BossEncounterRules.chapterForWave(_wave) * 500;
    _boss = null;
    _bossChargeRemaining = 0;
    _bossPreparedShots = <BossShotVector>[];
    _enemyBolts.clear();
    _advanceWave();
  }

  void _advanceWave() {
    if (campaignMode && _wave >= CampaignChapter.finalWave) {
      _campaignComplete = true;
      _paused = true;
      _publishHud(force: true);
      return;
    }
    final finishedChapter = campaignMode && _wave % 5 == 0;
    _wave++;
    _transitionChapterScenery();
    _spawnedThisWave = 0;
    _defeatedThisWave = 0;
    _spawnClock = 0;
    _waveElapsed = 0;
    _waveBannerRemaining = 1.55;
    if (finishedChapter) {
      _campaignIntermission = true;
      _paused = true;
      _publishHud(force: true);
    }
  }

  void _transitionChapterScenery() {
    final next = ((_wave - 1) ~/ 5).clamp(0, 4).toInt();
    if (next == _currentChapterScene) return;
    _outgoingChapterScene = _currentChapterScene;
    _currentChapterScene = next;
    _chapterFadeRemaining = _chapterFadeSeconds;
  }

  void continueCampaign() {
    if (!_campaignIntermission || _campaignComplete) return;
    _campaignIntermission = false;
    _paused = false;
    _publishHud(force: true);
  }

  CampaignChapter get currentChapter => CampaignChapter.forWave(_wave);

  void _damagePlayer() {
    if (_playerInvulnerable > 0 || _gameOver) return;
    if (_shieldCharges > 0) {
      _shieldCharges--;
      _playerInvulnerable = .75;
      _shieldPulse = .5;
      _publishHud(force: true);
      return;
    }
    _playerInvulnerable = 1.0;
    _health--;
    _enemyBolts.clear();
    if (_health <= 0) {
      _gameOver = true;
      _health = 0;
    }
    _publishHud(force: true);
  }

  void _addProjectileImpact(Offset center, Color tint,
      {bool muzzle = false, bool hostile = false}) {
    // Hard upper bound prevents frame-time spikes in heavy waves.
    if (_projectileImpacts.length >= 28) return;
    _projectileImpacts.add(
        PremiumProjectileImpact(center, tint, muzzle: muzzle, hostile: hostile));
  }

  void _fireEnemyVolley(_Foe foe, EnemyArchetype archetype) {
    // All wave enemies share one bounded projectile system. Each species has
    // its own persistent volley signature and predictable difficulty ramp.
    if (_enemyBolts.length >= 36) return;
    final dx = _playerX - foe.x;
    final dy = _playerY - foe.y;
    final aim = math.atan2(dy, dx);
    const shotSpeed = 165.0;
    void cast(double spread, {double? speed}) {
      if (_enemyBolts.length >= 36) return;
      final angle = aim + spread;
      final velocity = speed ?? shotSpeed;
      _enemyBolts.add(_EnemyBolt(
        foe.x, foe.y + foe.radius,
        math.cos(angle) * velocity,
        math.sin(angle) * velocity,
        typeIndex: foe.typeIndex,
      ));
    }
    switch (archetype.volley) {
      case EnemyVolleyStyle.aimed:
        cast(0);
        break;
      case EnemyVolleyStyle.harpyCrossfire:
        cast(-.14, speed: 173);
        cast(.14, speed: 173);
        break;
      case EnemyVolleyStyle.wyvernLance:
        cast(0, speed: 216);
        if (_wave >= 7) {
          cast(-.11, speed: 193);
          cast(.11, speed: 193);
        }
        break;
      case EnemyVolleyStyle.crystalFan:
        cast(-.25, speed: 146);
        cast(0, speed: 146);
        cast(.25, speed: 146);
        break;
      case EnemyVolleyStyle.emberDouble:
        cast(-.09, speed: 202);
        cast(.09, speed: 202);
        break;
      case EnemyVolleyStyle.voidFork:
        final offset = foe.volleysFired.isEven ? -.20 : .20;
        cast(offset, speed: 181);
        cast(-offset * .6, speed: 155);
        break;
    }
    foe.volleysFired++;
    _addProjectileImpact(Offset(foe.x, foe.y + foe.radius),
        PremiumProjectileFx.colorFor(_enemyMagicIds[foe.typeIndex]),
        muzzle: true, hostile: true);
  }

  bool activateSpecial() {
    if (_paused || _gameOver || _specialCooldown > 0) return false;
    final rule = SpecialAbilityRules.forDragon(dragon.id);
    _specialCooldown = rule.cooldown;
    _specialInitialClock = .76;
    _specialClock = _specialInitialClock;
    _activeSpecialId = dragon.id;
    _specialOrigin = Offset(_playerX, _playerY);
    final targets = _closestEnemies(_specialOrigin, rule.targetCount);
    switch (dragon.id) {
      case 'astralis':
        // A searching constellation: nearby stars lock onto multiple targets.
        final radius = math.max(235.0, size.x * .85);
        for (final foe in targets) {
          if (_distance(_playerX, _playerY, foe.x, foe.y) > radius) continue;
          _spellLines.add(_SpellLine(_specialOrigin,
              Offset(foe.x, foe.y), const Color(0xFF8ED9FF), 'astralis'));
          _damageTarget(foe, 3.5);
        }
        _enemyBolts.removeWhere((shot) =>
            _distance(_playerX, _playerY, shot.x, shot.y) < radius * .7);
        break;
      case 'temperstryx':
        // Dodge upwards, then bounce bright lightning between nearby foes.
        _dashOrigin = _specialOrigin;
        _playerY = math.max(math.min(57.0, size.y / 2), _playerY - 105).toDouble();
        _targetY = _playerY;
        _playerInvulnerable = math.max(_playerInvulnerable, 1.6).toDouble();
        var from = Offset(_playerX, _playerY);
        _spellLines.add(_SpellLine(_dashOrigin, from,
            const Color(0xFFB394FF), 'temperstryx', life: .8));
        for (final foe in targets) {
          _spellLines.add(_SpellLine(from,
              Offset(foe.x, foe.y), const Color(0xFFDCC5FF),
              'temperstryx', life: .7));
          from = Offset(foe.x, foe.y);
          _damageTarget(foe, 3.3);
        }
        break;
      case 'ignivar':
        // Six living dragonfire wisps seek enemies like enchanted breath.
        for (var i = 0; i < rule.targetCount; i++) {
          _seekingFlames.add(_SeekingFlame(
            _playerX + (i - 2.5) * 7,
            _playerY - 30,
            targets.isEmpty ? null : targets[i % targets.length],
            i,
          ));
        }
        break;
      case 'nyxariel':
        // Leave a hostile void rift while shifting out of incoming fire.
        final near = targets.isNotEmpty ? targets.first : null;
        final direction = near == null || near.x < _playerX ? 1.0 : -1.0;
        _playerX = (_playerX + direction * 75)
            .clamp(30.0, size.x - 30.0).toDouble();
        _targetX = _playerX;
        _playerInvulnerable = math.max(_playerInvulnerable, 2.1).toDouble();
        _spellZone = _SpellZone('nyxariel',
            near == null ? Offset(_specialOrigin.dx, _playerY - 125) :
                Offset(near.x, near.y),
            115, rule.effectSeconds);
        _spellLines.add(_SpellLine(_specialOrigin,
            Offset(_playerX, _playerY), const Color(0xFFD185FF), 'nyxariel'));
        break;
      case 'solarion':
        // Actual delayed sunstrikes track marked enemies before impact.
        for (var i = 0; i < targets.length; i++) {
          final foe = targets[i];
          _solarMarks.add(_SolarMark(
              foe, Offset(foe.x, foe.y), .36 + i * .11));
        }
        if (targets.isEmpty) {
          _solarMarks.add(_SolarMark(null,
              Offset(_playerX, math.max(90, _playerY - 170).toDouble()), .4));
        }
        break;
      case 'aquaryth':
        // A persistent moving current controls an enemy cluster.
        final anchor = targets.isEmpty ? Offset(_playerX, _playerY - 155) :
            Offset(targets.first.x, targets.first.y);
        _spellZone = _SpellZone('aquaryth', anchor, 128,
            rule.effectSeconds);
        break;
      default:
        break;
    }
    _publishHud(force: true);
    return true;
  }

  List<_Foe> _closestEnemies(Offset center, int limit) {
    final result = <_Foe>[..._foes];
    if (_boss != null) result.add(_boss!);
    result.sort((a, b) {
      final da = _distance(center.dx, center.dy, a.x, a.y);
      final db = _distance(center.dx, center.dy, b.x, b.y);
      return da.compareTo(db);
    });
    return result.take(limit).toList();
  }

  void _damageTarget(_Foe foe, double amount) {
    final isBoss = identical(foe, _boss);
    if (!isBoss && !_foes.contains(foe)) return;
    var remaining = amount;
    if (foe.shield > 0) {
      final absorbed = math.min(foe.shield, remaining);
      foe.shield = math.max(0.0, foe.shield - absorbed).toDouble();
      foe.shieldHitRemaining = .24;
      foe.shieldRecoverClock = 0;
      remaining -= absorbed;
      _addProjectileImpact(Offset(foe.x, foe.y),
          isBoss ? BossEncounterFx.hue(_wave) : _shieldTint(foe.typeIndex));
    }
    if (remaining > 0) foe.hp -= remaining;
    if (isBoss) {
      _bossHitPulse = .28;
    } else if (foe.hp <= 0) {
      _defeatFoe(foe);
    }
  }

  Color _shieldTint(int typeIndex) {
    if (typeIndex == 3) return const Color(0xFF80EDFF);
    if (typeIndex == 5) return const Color(0xFFC99BFF);
    return const Color(0xFF82C5F8);
  }

  void _defeatFoe(_Foe foe) {
    if (!_foes.remove(foe)) return;
    _defeatedThisWave++;
    _score += EnemyArchetypes.forType(foe.typeIndex).scoreReward;
    if (_defeatGlimmers.length < 12) {
      _defeatGlimmers.add(_DefeatGlimmer(Offset(foe.x, foe.y),
          const [Color(0xFFC2A5DB), Color(0xFFAAE2E9),
            Color(0xFFBE91DC), Color(0xFF78F1E8),
            Color(0xFFFFAE77), Color(0xFFC7AAFF)]
              [foe.typeIndex.clamp(0, 5).toInt()]));
    }
    if (_pickups.length < 3 &&
        (_defeatedThisWave % 6 == 0 || _random.nextDouble() < .13)) {
      _pickups.add(_Pickup(foe.x, foe.y,
          _PickupKind.values[_random.nextInt(_PickupKind.values.length)]));
    }
  }

  void _collectPickup(_PickupKind kind) {
    switch (kind) {
      case _PickupKind.haste:
        _hasteRemaining = 7;
        break;
      case _PickupKind.critical:
        _critRemaining = 8;
        break;
      case _PickupKind.shield:
        _shieldCharges = math.min(2, _shieldCharges + 1);
        _shieldRemaining = 14;
        _shieldPulse = .55;
        break;
    }
    _publishHud(force: true);
  }

  void _updateSpecialsAndPickups(double step) {
    _fxTime += step;
    _hasteRemaining = math.max(0.0, _hasteRemaining - step).toDouble();
    _critRemaining = math.max(0.0, _critRemaining - step).toDouble();
    _shieldRemaining = math.max(0.0, _shieldRemaining - step).toDouble();
    _shieldPulse = math.max(0.0, _shieldPulse - step).toDouble();
    if (_shieldRemaining <= 0) _shieldCharges = 0;

    for (final trace in _spellLines) {
      trace.life -= step;
    }
    _spellLines.removeWhere((trace) => trace.life <= 0);

    for (final flame in _seekingFlames.toList()) {
      flame.life -= step;
      if (flame.life <= 0) {
        _seekingFlames.remove(flame);
        continue;
      }
      if (flame.target == null ||
          (!identical(flame.target, _boss) &&
              !_foes.contains(flame.target))) {
        final nearest = _closestEnemies(Offset(flame.x, flame.y), 1);
        flame.target = nearest.isEmpty ? null : nearest.first;
      }
      flame.previous = Offset(flame.x, flame.y);
      final foe = flame.target;
      if (foe == null) {
        flame.y -= 330 * step;
      } else {
        final distance = _distance(flame.x, flame.y, foe.x, foe.y);
        final move = math.min(distance, (365 + flame.seed * 10) * step);
        if (distance > 0) {
          flame.x += (foe.x - flame.x) / distance * move;
          flame.y += (foe.y - flame.y) / distance * move;
        }
        if (distance <= move + foe.radius + 10) {
          final center = Offset(foe.x, foe.y);
          _damageTarget(foe, 4.3);
          for (final other in _foes.toList()) {
            if (_distance(other.x, other.y, center.dx, center.dy) < 32) {
              _damageTarget(other, 1.2);
            }
          }
          _spellLines.add(_SpellLine(center.translate(-12, 0),
              center.translate(12, 0), const Color(0xFFFFA34E),
              'ignivar', life: .3));
          _seekingFlames.remove(flame);
        }
      }
      if (flame.y < -20) _seekingFlames.remove(flame);
    }

    for (final mark in _solarMarks.toList()) {
      final target = mark.target;
      if (target != null &&
          (identical(target, _boss) || _foes.contains(target))) {
        mark.position = Offset(target.x, target.y);
      }
      mark.delay -= step;
      if (mark.delay > 0) continue;
      final center = mark.position;
      for (final foe in _closestEnemies(center, 30).toList()) {
        if (_distance(foe.x, foe.y, center.dx, center.dy) < 62) {
          _damageTarget(foe, identical(foe, target) ? 6.5 : 2.2);
        }
      }
      _enemyBolts.removeWhere((shot) =>
          _distance(shot.x, shot.y, center.dx, center.dy) < 52);
      _spellLines.add(_SpellLine(Offset(center.dx, -10), center,
          const Color(0xFFFFCE68), 'solarion', life: .5));
      _solarMarks.remove(mark);
    }

    if (_spellZone case final zone?) {
      zone.life -= step;
      zone.pulse += step;
      // Pull lightly; enemies remain controllable/readable and are never
      // teleported directly onto the player.
      for (final foe in _foes) {
        if (_distance(foe.x, foe.y, zone.center.dx, zone.center.dy) <
            zone.radius * 1.2) {
          foe.x += (zone.center.dx - foe.x) * .58 * step;
          foe.y += (zone.center.dy - foe.y) * .37 * step;
        }
      }
      if (zone.pulse >= .3) {
        zone.pulse -= .3;
        for (final foe in _closestEnemies(zone.center, 30).toList()) {
          if (_distance(foe.x, foe.y, zone.center.dx, zone.center.dy) <
              zone.radius) {
            _damageTarget(foe, zone.kind == 'aquaryth' ? .8 : 1.2);
          }
        }
        _enemyBolts.removeWhere((shot) =>
            _distance(shot.x, shot.y, zone.center.dx, zone.center.dy) <
            zone.radius * .58);
      }
      if (zone.life <= 0) _spellZone = null;
    }

    for (final pickup in _pickups.toList()) {
      pickup.age += step;
      pickup.y += 45 * step;
      pickup.x += math.sin(_fxTime * 2.5 + pickup.y * .03) * 10 * step;
      if (_distance(_playerX, _playerY, pickup.x, pickup.y) < 29) {
        _collectPickup(pickup.kind);
        _pickups.remove(pickup);
      } else if (pickup.age > 10 || pickup.y > size.y + 25) {
        _pickups.remove(pickup);
      }
    }
  }

  double get specialCooldownRemaining => _specialCooldown;

  void restartGame() {
    _developerShowcase = false;
    _bolts.clear();
    _enemyBolts.clear();
    _foes.clear();
    _defeatGlimmers.clear();
    _projectileImpacts.clear();
    _waveBannerRemaining = 1.6;
    _boss = null;
    _spellLines.clear();
    _seekingFlames.clear();
    _solarMarks.clear();
    _pickups.clear();
    _spellZone = null;
    _hasteRemaining = 0;
    _critRemaining = 0;
    _shieldRemaining = 0;
    _shieldCharges = 0;
    _shieldPulse = 0;
    _campaignIntermission = false;
    _campaignComplete = false;
    _score = 0;
    _wave = 1;
    _currentChapterScene = 0;
    _outgoingChapterScene = null;
    _chapterFadeRemaining = 0;
    _health = 3;
    _spawnedThisWave = 0;
    _defeatedThisWave = 0;
    _fireClock = 0;
    _spawnClock = 0;
    _hudClock = 0;
    _waveElapsed = 0;
    _playerInvulnerable = 0;
    _bossAttackClock = 0;
    _bossFlightClock = 0;
    _bossChargeRemaining = 0;
    _bossChargeDuration = 0;
    _bossHitPulse = 0;
    _bossPhasePulse = 0;
    _bossVolleys = 0;
    _bossPhase = BossCombatPhase.guarded;
    _bossPreparedShots = <BossShotVector>[];
    _specialCooldown = 0;
    _specialClock = 0;
    _wingMotionSeconds = 0;
    _flightClock = 0;
    _flightFrame = 0;
    _flightBank = 0;
    _outgoingDragon = null;
    _dragonCrossfadeRemaining = 0;
    _paused = false;
    _gameOver = false;
    _touching = false;
    _framePacing.reset();
    if (size.x > 0 && size.y > 0) {
      _playerX = size.x / 2;
      _playerY = size.y * .78;
      _targetX = _playerX;
      _targetY = _playerY;
    }
    _publishHud(force: true);
  }

  // Run 35 tester hooks. The UI exposes these only when explicitly compiled
  // with --dart-define=DL_DEV_TOOLS=true; normal player UI never shows them.
  void developerSetPanelOpen(bool open) {
    _developerPanelOpen = open;
    if (open) _touching = false;
  }

  String get developerSnapshot =>
      'Dragon ${dragon.name}  •  Wave $_wave  •  Hull $_health\n'
      'Score $_score  •  Enemies ${_foes.length}  •  '
      'Boss ${_boss == null ? "NO" : "YES"}  •  '
      'Power ${_specialCooldown <= 0 ? "READY" : "COOLDOWN"}\n'
      'Run43 art: ${_enemyFrames.where((f) => f.isNotEmpty).length}/6 enemies  •  '
      '${_run43PlayerMagic.length}/6 dragon breaths  •  '
      '${_run43EnemyMagic.length}/6 enemy magics\n'
      'Run45 boss: ${_boss == null ? "NONE" : BossEncounterRules.nameForWave(_wave)} '
      '• ${BossEncounterRules.phaseName(_bossPhase)}\n'
      'Run46 ${_framePacing.diagnosticLine}\n'
      'Assets ${_chapterBattlefieldArt.whereType<ui.Image>().length}/4 '
      'scenes  •  ${_chapterBossFrames.where((f) => f.length == 8).length}/5 bosses';

  void developerJumpToWave(int requestedWave, {bool boss = false}) {
    if (size.x <= 0 || size.y <= 0) return;
    // A fully reproducible level test. This is not a save-game operation.
    restartGame();
    _wave = requestedWave.clamp(1, CampaignChapter.finalWave).toInt();
    if (boss) {
      _wave = (((_wave - 1) ~/ 5) + 1) * 5;
      _spawnedThisWave = 7 + _wave * 2;
      _summonBoss(instant: true);
    }
    _transitionChapterScenery();
    _paused = false;
    _waveBannerRemaining = 1.6;
    _publishHud(force: true);
  }

  void developerClearArena() {
    _developerShowcase = true;
    _foes.clear();
    _enemyBolts.clear();
    _bolts.clear();
    _projectileImpacts.clear();
    _boss = null;
    _bossChargeRemaining = 0;
    _bossPreparedShots = <BossShotVector>[];
    _paused = false;
    _campaignIntermission = false;
    _campaignComplete = false;
    _gameOver = false;
    _health = 3;
    _publishHud(force: true);
  }

  void developerEnemyGallery() {
    if (size.x <= 0 || size.y <= 0) return;
    developerClearArena();
    // Two rows of three fit the portrait screen and give each enemy room to
    // flap. Hold them still so it is easy to spot bad or missing frames.
    for (var type = 0; type < 6; type++) {
      _foes.add(_Foe(
        x: size.x * (type % 3 + 1) / 4,
        y: size.y * (type < 3 ? .24 : .40),
        hp: 60,
        shield: EnemyArchetypes.forType(type)
            .shieldAtWave(type == 5 ? 8 : math.max(4, _wave)),
        radius: _enemyRadii[type],
        speed: 0,
        typeIndex: type,
        spriteSize: _enemySpriteSizes[type],
      ));
    }
    _publishHud(force: true);
  }

  void developerForceAbilityReady() {
    _specialCooldown = 0;
    _publishHud(force: true);
  }

  void developerGrantBoost(String kind, {bool drop = false}) {
    final pickup = switch (kind) {
      'haste' => _PickupKind.haste,
      'critical' => _PickupKind.critical,
      'shield' => _PickupKind.shield,
      _ => null,
    };
    if (pickup == null) return;
    if (drop && size.y > 0) {
      _pickups.add(_Pickup(_playerX,
          math.max(65.0, _playerY - 85).toDouble(), pickup));
    } else {
      _collectPickup(pickup);
    }
  }

  void developerTestDamage() {
    _playerInvulnerable = 0;
    _damagePlayer();
  }

  void developerNextWave() {
    _foes.clear();
    _enemyBolts.clear();
    _bolts.clear();
    _projectileImpacts.clear();
    _boss = null;
    _bossChargeRemaining = 0;
    _bossPreparedShots = <BossShotVector>[];
    _developerShowcase = false;
    _paused = false;
    _gameOver = false;
    _health = math.max(_health, 1);
    _advanceWave();
    _publishHud(force: true);
  }

  void developerHeal() {
    _health = 3;
    _gameOver = false;
    _playerInvulnerable = 1.5;
    _publishHud(force: true);
  }

  void developerSpawnEnemy(int typeIndex) {
    if (typeIndex < 0 || typeIndex > 5 || size.x <= 0) return;
    final archetype = EnemyArchetypes.forType(typeIndex);
    _foes.add(_Foe(
      x: size.x / 2,
      y: 100,
      hp: archetype.healthAtWave(math.max(1, _wave)),
      shield: archetype.shieldAtWave(math.max(4, _wave)),
      radius: _enemyRadii[typeIndex],
      speed: 20,
      typeIndex: typeIndex,
      spriteSize: _enemySpriteSizes[typeIndex],
    ));
  }

  double _distance(double ax, double ay, double bx, double by) =>
      math.sqrt((ax - bx) * (ax - bx) + (ay - by) * (ay - by));

  void _publishHud({bool force = false}) {
    final next = DragonHudState(
        score: _score,
        wave: _wave,
        health: _health,
        paused: _paused,
        bossActive: _boss != null,
        dragonName: dragon.name,
        specialRemaining: _specialCooldown,
        specialMax: SpecialAbilityRules.forDragon(dragon.id).cooldown,
        hasteRemaining: _hasteRemaining,
        critRemaining: _critRemaining,
        shields: _shieldCharges,
        campaignMode: campaignMode,
        campaignIntermission: _campaignIntermission,
        campaignComplete: _campaignComplete,
        chapterTitle: currentChapter.title);
    if (force ||
        next.score != hud.value.score ||
        next.wave != hud.value.wave ||
        next.health != hud.value.health ||
        next.paused != hud.value.paused ||
        next.bossActive != hud.value.bossActive ||
        next.dragonName != hud.value.dragonName ||
        (next.specialRemaining - hud.value.specialRemaining).abs() > .09 ||
        next.shields != hud.value.shields ||
        (next.hasteRemaining - hud.value.hasteRemaining).abs() > .09 ||
        (next.critRemaining - hud.value.critRemaining).abs() > .09 ||
        next.campaignMode != hud.value.campaignMode ||
        next.campaignIntermission != hud.value.campaignIntermission ||
        next.campaignComplete != hud.value.campaignComplete) {
      hud.value = next;
    }
  }

  void _drawEnemyStatus(Canvas canvas, _Foe foe) {
    final elite = foe.maxShield > 0;
    // Hide unnecessary UI on fragile early scouts; stronger creatures have
    // readable health and an independently tracked overshield.
    if (!elite && foe.hp >= foe.maxHealth && foe.maxHealth < 2.5) return;
    final barWidth = (foe.spriteSize * .57).clamp(35.0, 55.0).toDouble();
    final top = foe.y - foe.spriteSize * .5 - 10;
    final left = foe.x - barWidth / 2;
    final outline = RRect.fromRectAndRadius(
        Rect.fromLTWH(left, top, barWidth, 3.7),
        const Radius.circular(3));
    canvas.drawRRect(outline,
        Paint()..color = const Color(0xCC10132B));
    final health = (foe.hp / foe.maxHealth).clamp(0.0, 1.0).toDouble();
    if (health > 0) {
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(left, top, barWidth * health, 3.7),
              const Radius.circular(3)),
          Paint()
            ..shader = ui.Gradient.linear(
                Offset(left, top), Offset(left + barWidth, top), [
              const Color(0xFFFF747B), const Color(0xFFFFBD86),
            ]));
    }
    if (foe.typeIndex == 4 && foe.hp < foe.maxHealth * .5) {
      // The manticore's haste/ember-rage state is visibly telegraphed.
      canvas.drawArc(
          Rect.fromCircle(
              center: Offset(foe.x, foe.y), radius: foe.radius + 8),
          -_fxTime * 2.4,
          math.pi * 1.15,
          false,
          Paint()
            ..color = const Color(0xAFFF913A)
            ..strokeWidth = 1.7
            ..style = PaintingStyle.stroke);
    }
    if (!elite) return;
    final tint = _shieldTint(foe.typeIndex);
    final shieldY = top - 6.3;
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(left, shieldY, barWidth, 3.3),
            const Radius.circular(3)),
        Paint()..color = const Color(0xAA121A32));
    final shield = (foe.shield / foe.maxShield).clamp(0.0, 1.0).toDouble();
    if (shield > 0) {
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(left, shieldY, barWidth * shield, 3.3),
              const Radius.circular(3)),
          Paint()..color = tint.withValues(alpha: .84));
      final pulse = .19 + math.sin(_fxTime * 4 + foe.homeX * .021) * .07 +
          foe.shieldHitRemaining * 1.2;
      canvas.drawArc(
          Rect.fromCircle(center: Offset(foe.x, foe.y),
              radius: foe.radius + 8),
          _fxTime * .35 + foe.typeIndex,
          math.pi * 1.5,
          false,
          Paint()
            ..color = tint.withValues(alpha: pulse.clamp(0.0, .62).toDouble())
            ..strokeWidth = 1.6
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke);
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    _drawStars(canvas);
    for (final glimmer in _defeatGlimmers) {
      final fade = (1 - glimmer.age / _DefeatGlimmer.duration)
          .clamp(0.0, 1.0).toDouble();
      for (var i = 0; i < 4; i++) {
        final angle = i * math.pi / 2 + glimmer.center.dx * .012;
        final reach = 6 + glimmer.age * 32;
        final mote = Offset(glimmer.center.dx + math.cos(angle) * reach,
            glimmer.center.dy + math.sin(angle) * reach);
        canvas.drawCircle(mote, 1.7 * fade,
            Paint()..color = glimmer.tint.withValues(alpha: fade * .48));
      }
    }
    _drawSpecialEffects(canvas, behind: true);
    for (final impact in _projectileImpacts) {
      impact.render(canvas);
    }
    final gold = Paint()..color = const Color(0xFFFFD77A);
    final red = Paint()..color = const Color(0xFFFF667E);

    for (final bolt in _bolts) {
      final center = Offset(bolt.x, bolt.y);
      PremiumProjectileFx.drawPlayerUnderlay(
          canvas, center, bolt.dragonId, _fxTime);
      final magic = _run43PlayerMagic[bolt.dragonId];
      final frames = magic != null && magic.isNotEmpty
          ? magic : _run32PlayerBoltFrames;
      if (frames.isNotEmpty) {
        final frame = frames[(_fxTime * 15).floor() % frames.length];
        canvas.drawImageRect(
          frame,
          Rect.fromLTWH(0, 0, frame.width.toDouble(), frame.height.toDouble()),
          Rect.fromCenter(center: Offset(bolt.x, bolt.y), width: 23, height: 33),
          Paint()..filterQuality = FilterQuality.medium,
        );
      } else {
        canvas.drawRRect(
            RRect.fromRectAndRadius(
                Rect.fromCenter(
                    center: Offset(bolt.x, bolt.y), width: 4, height: 18),
                const Radius.circular(3)),
            gold);
      }
      PremiumProjectileFx.drawPlayerOverlay(
          canvas, center, bolt.dragonId, _fxTime);
    }
    for (final shot in _enemyBolts) {
      final id = shot.typeIndex >= 0 && shot.typeIndex < _enemyMagicIds.length
          ? _enemyMagicIds[shot.typeIndex] : '';
      final center = Offset(shot.x, shot.y);
      final travel = Offset(shot.vx, shot.vy);
      PremiumProjectileFx.drawEnemyUnderlay(
          canvas, center, travel, id, _fxTime);
      final magic = _run43EnemyMagic[id];
      final frames = magic != null && magic.isNotEmpty
          ? magic : _run32EnemyBoltFrames;
      if (frames.isNotEmpty) {
        final frame = frames[(_fxTime * 14).floor() % frames.length];
        canvas.drawImageRect(
          frame,
          Rect.fromLTWH(0, 0, frame.width.toDouble(), frame.height.toDouble()),
          Rect.fromCenter(center: Offset(shot.x, shot.y), width: 22, height: 22),
          Paint()..filterQuality = FilterQuality.medium,
        );
      } else {
        canvas.drawCircle(Offset(shot.x, shot.y), 5,
            Paint()..color = const Color(0xFFFF7895));
        canvas.drawCircle(
            Offset(shot.x, shot.y),
            9,
            Paint()
              ..color = const Color(0x55FF7895)
              ..style = PaintingStyle.stroke);
      }
      PremiumProjectileFx.drawEnemyOverlay(
          canvas, center, travel, id, _fxTime);
    }
    for (final foe in _foes) {
      if (foe.typeIndex >= 0 && foe.typeIndex < _enemyFrames.length &&
          _enemyFrames[foe.typeIndex].isNotEmpty) {
        final frames = _enemyFrames[foe.typeIndex];
        final frame = frames[foe.animationFrame % frames.length];
        // Subtle motion synchronized with the illustrated wings. Previously
        // the separate rapid 3% squash/stretch visibly fought the frames.
        final frameSeconds = frames.length == 12 ? .8 / 12 : .1;
        final phase = 2 * math.pi * (foe.animationFrame +
            foe.animationClock / frameSeconds) / frames.length;
        final wingbeat = math.sin(phase);
        canvas.save();
        canvas.translate(foe.x, foe.y + wingbeat * .65);
        canvas.rotate(math.sin(_fxTime * 1.4 + foe.y * .02) * .012);
        canvas.scale(1 + wingbeat * .007, 1 - wingbeat * .009);
        canvas.drawImageRect(
          frame,
          Rect.fromLTWH(0, 0, frame.width.toDouble(), frame.height.toDouble()),
          Rect.fromCenter(
            center: Offset.zero,
            width: foe.spriteSize,
            height: foe.spriteSize,
          ),
          Paint()
            ..filterQuality = FilterQuality.high
            ..colorFilter = foe.typeIndex == 5
                ? ColorFilter.mode(
                    Colors.white.withValues(alpha: 
                        .7 + .3 * (.5 + .5 *
                            math.sin(foe.patternClock * 3.6))),
                    BlendMode.modulate)
                : null,
        );
        canvas.restore();
      } else {
        canvas.drawCircle(Offset(foe.x, foe.y), foe.radius, red);
        canvas.drawCircle(
            Offset(foe.x, foe.y),
            foe.radius + 4,
            Paint()
              ..color = red.color.withValues(alpha: .18)
              ..style = PaintingStyle.stroke);
      }
      _drawEnemyStatus(canvas, foe);
    }
    if (_boss case final boss?) {
      BossEncounterFx.drawAura(canvas, Offset(boss.x, boss.y),
          wave: _wave,
          seconds: _fxTime,
          phase: _bossPhase,
          shieldFraction: boss.maxShield > 0
              ? (boss.shield / boss.maxShield).clamp(0.0, 1.0).toDouble()
              : 0,
          hitPulse: _bossHitPulse,
          phasePulse: _bossPhasePulse);
      final bossChapter = ((_wave - 1) ~/ 5).clamp(0, 4).toInt();
      final flight = _chapterBossFrames[bossChapter];
      final ui.Image? bossArt = flight.isNotEmpty
          ? flight[(_fxTime / .1).floor() % flight.length]
          : _run31BossImage;
      if (bossArt != null) {
        canvas.drawImageRect(
          bossArt,
          Rect.fromLTWH(0, 0, bossArt.width.toDouble(), bossArt.height.toDouble()),
          Rect.fromCenter(
            center: Offset(boss.x, boss.y),
            width: 126,
            height: 96,
          ),
          Paint()..filterQuality = FilterQuality.medium,
        );
      } else {
        canvas.drawCircle(Offset(boss.x, boss.y), boss.radius + 8,
            Paint()..color = const Color(0xFFFF5577).withValues(alpha: .18));
        canvas.drawCircle(Offset(boss.x, boss.y), boss.radius, red);
      }
      BossEncounterFx.drawStatus(canvas,
          battlefieldWidth: size.x,
          bossName: BossEncounterRules.nameForWave(_wave),
          wave: _wave,
          phase: _bossPhase,
          health: boss.hp,
          maxHealth: boss.maxHealth,
          shield: boss.shield,
          maxShield: boss.maxShield);
      if (_bossChargeRemaining > 0 && _bossChargeDuration > 0) {
        final progress = 1 - _bossChargeRemaining / _bossChargeDuration;
        BossEncounterFx.drawCharge(canvas, Offset(boss.x, boss.y),
            _bossPreparedShots, progress, _wave, _fxTime);
      }
    }
    // Spell work is vector-drawn to fit the battlefield; giant pre-rendered
    // ability pictures previously obscured the dragons and are no longer used.
    _drawSpecialEffects(canvas, behind: false);
    // Preserve the existing animated ASTRALIS sprite and vector fallback.
    final path = Path()
      ..moveTo(_playerX, _playerY - 22)
      ..quadraticBezierTo(_playerX + 22, _playerY + 5, _playerX, _playerY + 15)
      ..quadraticBezierTo(_playerX - 22, _playerY + 5, _playerX, _playerY - 22)
      ..close();
    if (_playerInvulnerable <= 0 || (_playerInvulnerable * 12).floor().isEven) {
      final previous = _outgoingDragon;
      if (previous != null && _dragonCrossfadeRemaining > 0) {
        final departing = (_dragonCrossfadeRemaining /
            _dragonCrossfadeSeconds).clamp(0.0, 1.0).toDouble();
        _drawPlayableDragon(canvas, previous, path, opacity: departing);
        _drawPlayableDragon(canvas, dragon, path, opacity: 1 - departing);
      } else {
        _drawPlayableDragon(canvas, dragon, path, opacity: 1);
      }
    } else {
      canvas.drawPath(path, Paint()..color = const Color(0x88FFFFFF));
    }
    if (_playerInvulnerable > 0) {
      canvas.drawCircle(
          Offset(_playerX, _playerY),
          25,
          Paint()
            ..color = const Color(0x665CCFFF)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2);
    }
    if (_shieldCharges > 0) {
      final shieldColor = const Color(0xFF69E3FF)
          .withValues(alpha: .55 + _shieldPulse * .6);
      canvas.drawCircle(Offset(_playerX, _playerY), 46,
          Paint()..color = shieldColor.withValues(alpha: .13));
      canvas.drawCircle(Offset(_playerX, _playerY), 46,
          Paint()..color = shieldColor
            ..style = PaintingStyle.stroke..strokeWidth = 2.4);
      canvas.drawArc(Rect.fromCircle(
          center: Offset(_playerX, _playerY), radius: 51),
          -_fxTime * 2.4, 1.4, false,
          Paint()..color = const Color(0xFFBDF7FF)
            ..style = PaintingStyle.stroke..strokeWidth = 2.0);
    }
    canvas.drawCircle(Offset(_playerX, _playerY - 2), 4, gold);
    if (_waveBannerRemaining > 0 && !_gameOver && !_paused) {
      final fade = (_waveBannerRemaining / .5).clamp(0.0, 1.0).toDouble();
      final headline = campaignMode
          ? 'CHAPTER ${currentChapter.number}  •  WAVE $_wave'
          : 'WAVE $_wave';
      final text = TextPainter(
        text: TextSpan(text: headline,
            style: TextStyle(color: const Color(0xFFFFDE9C)
                .withValues(alpha: fade * .82), letterSpacing: 2.2,
                fontSize: 14, fontWeight: FontWeight.bold)),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: size.x);
      text.paint(canvas, Offset((size.x - text.width) / 2, size.y * .13));
    }
    if (_paused || _gameOver) {
      final overlay = Paint()..color = const Color(0xBB050817);
      canvas.drawRect(Offset.zero & Size(size.x, size.y), overlay);
      final text = TextPainter(
        text: TextSpan(
            text: _gameOver ? 'FLIGHT ENDED' : 'PAUSED',
            style: const TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
                letterSpacing: 3)),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: size.x);
      text.paint(canvas, Offset((size.x - text.width) / 2, size.y * .46));
      if (_gameOver) {
        final hint = TextPainter(
          text: const TextSpan(
              text: 'Tap FLY AGAIN to restart',
              style: TextStyle(color: Color(0xFF9CC7D8), fontSize: 12)),
          textDirection: TextDirection.ltr,
        )..layout(maxWidth: size.x);
        hint.paint(
            canvas, Offset((size.x - hint.width) / 2, size.y * .46 + 42));
      }
    }
  }

  void _drawPlayableDragon(Canvas canvas, DragonProfile selected,
      Path fallback, {required double opacity}) {
    if (opacity <= 0) return;
    final paint = Paint()..filterQuality = FilterQuality.high;
    if (opacity < 1) {
      paint.colorFilter = ui.ColorFilter.mode(
        Color.fromARGB((opacity * 255).round(), 255, 255, 255),
        ui.BlendMode.modulate,
      );
    }
    ui.Image? sprite;
    var width = 86.0;
    var height = 114.0;
    if (selected.id == 'astralis' && _flightFrames.isNotEmpty) {
      sprite = _flightFrames[_flightFrame];
    } else {
      final frames = _run42DragonFlights[selected.id] ??
          _run32DragonFlights[selected.id];
      if (frames != null && frames.isNotEmpty) {
        // Every species completes one beat in 0.8s. Extra Run 42 poses
        // insert genuine mid-strokes at 50ms without speeding up its wings.
        final index = frames.length == 16
            ? (_wingMotionSeconds * 20).floor() % frames.length
            : frames.length == 8
                ? _flightFrame
                : DragonFlightCycle.fourPoseFrameAt(_wingMotionSeconds);
        sprite = frames[index % frames.length];
      } else {
        sprite = _run31DragonStills[selected.id];
        width = 90;
        height = 108;
      }
    }
    if (sprite != null) {
      canvas.drawImageRect(sprite,
        Rect.fromLTWH(0, 0, sprite.width.toDouble(),
            sprite.height.toDouble()),
        Rect.fromCenter(center: Offset(_playerX, _playerY),
            width: width, height: height), paint);
    } else {
      canvas.drawPath(fallback,
          Paint()..color = selected.palette.withValues(alpha: opacity));
    }
  }

  void _drawSpecialEffects(Canvas canvas, {required bool behind}) {
    if (behind) {
      // Different spell circles occupy enemy space, never the entire screen.
      if (_spellZone case final zone?) {
        final aqua = zone.kind == 'aquaryth';
        final hue = aqua ? const Color(0xFF54EAE7)
            : const Color(0xFFC18BFF);
        final opacity = (zone.life / zone.initialLife)
            .clamp(0.0, 1.0).toDouble();
        canvas.drawCircle(zone.center, zone.radius,
            Paint()..color = hue.withValues(alpha: .10 * opacity));
        for (var i = 0; i < 3; i++) {
          final radius = zone.radius * (.38 + i * .24);
          canvas.drawArc(Rect.fromCircle(center: zone.center, radius: radius),
              _fxTime * (aqua ? 1.8 : -2.3) + i * 2.2,
              aqua ? 3.2 : 2.4, false,
              Paint()..color = hue.withValues(alpha: (.48 - i * .08) * opacity)
                ..style = PaintingStyle.stroke..strokeWidth = 2.4);
        }
        if (!aqua) {
          canvas.drawCircle(zone.center, 15 + math.sin(_fxTime * 12) * 2,
              Paint()..color = const Color(0xBB4D1A80));
        }
      }
      for (final mark in _solarMarks) {
        final radius = 31 + math.sin(_fxTime * 10) * 2;
        canvas.drawCircle(mark.position, radius,
            Paint()..color = const Color(0x99FFBC4A)
              ..style = PaintingStyle.stroke..strokeWidth = 2.2);
        canvas.drawCircle(mark.position, 7,
            Paint()..color = const Color(0xAAFFF1B5));
      }
      if (_specialClock > 0 && _activeSpecialId == 'astralis') {
        final progress = 1 - _specialClock / _specialInitialClock;
        canvas.drawCircle(_specialOrigin, 25 + progress * size.x * .4,
            Paint()..color = const Color(0xFF9AD9FF)
              .withValues(alpha: (1 - progress) * .75)
              ..style = PaintingStyle.stroke..strokeWidth = 3);
      }
      for (final pickup in _pickups) {
        final center = Offset(pickup.x, pickup.y);
        final color = switch (pickup.kind) {
          _PickupKind.haste => const Color(0xFF72EAF1),
          _PickupKind.critical => const Color(0xFFFFCE5D),
          _PickupKind.shield => const Color(0xFF79AFFF),
        };
        final pulse = 1 + math.sin(_fxTime * 5 + pickup.age) * .12;
        canvas.drawCircle(center, 17 * pulse,
            Paint()..color = color.withValues(alpha: .18));
        canvas.drawCircle(center, 13 * pulse,
            Paint()..color = color.withValues(alpha: .8)
              ..style = PaintingStyle.stroke..strokeWidth = 1.9);
        if (pickup.kind == _PickupKind.shield) {
          canvas.drawCircle(center, 7, Paint()..color = color);
        } else {
          final glyph = Path()
            ..moveTo(center.dx - 6, center.dy + 8)
            ..lineTo(center.dx + 1, center.dy - 8)
            ..lineTo(center.dx + 6, center.dy - 1)
            ..lineTo(center.dx - 1, center.dy + 8)
            ..close();
          canvas.drawPath(glyph, Paint()..color = color);
        }
      }
      return;
    }
    for (final line in _spellLines) {
      final fade = (line.life / line.initialLife).clamp(0.0, 1.0).toDouble();
      final base = Paint()..color = line.color.withValues(alpha: .16 * fade)
          ..strokeWidth = line.kind == 'solarion' ? 20 : 12
          ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
      final bright = Paint()..color = line.color.withValues(alpha: fade)
          ..strokeWidth = line.kind == 'solarion' ? 4.5 : 2.8
          ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
      final path = Path()..moveTo(line.from.dx, line.from.dy);
      if (line.kind == 'temperstryx') {
        final midpoint = Offset((line.from.dx + line.to.dx) / 2,
            (line.from.dy + line.to.dy) / 2);
        path.lineTo(midpoint.dx + math.sin(_fxTime * 24) * 13,
            midpoint.dy - 8);
      }
      path.lineTo(line.to.dx, line.to.dy);
      canvas.drawPath(path, base);
      canvas.drawPath(path, bright);
      canvas.drawCircle(line.to,
          line.kind == 'solarion' ? 18 * fade : 7 * fade,
          Paint()..color = line.color.withValues(alpha: .45 * fade));
    }
    // Animated plumes of dragonfire: flowing magic that bends toward foes.
    for (final flame in _seekingFlames) {
      final center = Offset(flame.x, flame.y);
      final tail = flame.previous;
      final glow = Paint()..color = const Color(0x77FF5C26)
        ..strokeWidth = 15..strokeCap = StrokeCap.round;
      canvas.drawLine(tail, center, glow);
      final flicker = 7.0 + math.sin(_fxTime * 23 + flame.seed) * 3;
      canvas.drawCircle(center, flicker + 5,
          Paint()..color = const Color(0x55FF7133));
      canvas.drawCircle(center, flicker,
          Paint()..color = const Color(0xFFFF842E));
      canvas.drawCircle(center.translate(0, -3), flicker * .44,
          Paint()..color = const Color(0xFFFFE7A1));
    }
  }

  void _drawStars(Canvas canvas) {
    final bounds = Offset.zero & Size(size.x, size.y);
    final tier = ((_wave - 1) ~/ 5).clamp(0, 4).toInt();
    final scene = _chapterBattlefieldArt[tier] ?? _battlefieldArt;
    if (scene != null) {
      // Both pre-decoded scenes keep the same cover crop and fixed position.
      // Only opacity changes: no resizing or alignment changes mid-transition.
      final outgoing = _outgoingChapterScene;
      final from = outgoing == null ? null :
          (_chapterBattlefieldArt[outgoing] ?? _battlefieldArt);
      if (_chapterFadeRemaining > 0 && from != null &&
          !identical(from, scene)) {
        _paintChapterScene(canvas, from, bounds);
        final progress =
            (1 - _chapterFadeRemaining / _chapterFadeSeconds)
                .clamp(0.0, 1.0).toDouble();
        // Smoothstep eases the start and end of the 1.4s chapter dissolve.
        final eased = progress * progress * (3 - 2 * progress);
        _paintChapterScene(canvas, scene, bounds, opacity: eased);
      } else {
        _paintChapterScene(canvas, scene, bounds);
      }
      canvas.drawRect(bounds, Paint()..color = const Color(0x16030920));
      // Sparse moving motes give depth without obscuring the battlefield.
      final mote = Paint()..color = const Color(0x77BADDF7);
      for (var i = 0; i < 25; i++) {
        final x = (i * 97.0 + 21) % math.max(1.0, size.x);
        final y = (i * 163.0 + _waveElapsed * (9 + i % 4 * 3)) %
            math.max(1.0, size.y);
        canvas.drawCircle(Offset(x, y), i % 7 == 0 ? 1.1 : .55, mote);
      }
      return;
    }
    canvas.drawRect(bounds, Paint()..shader = const LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter,
      colors: [Color(0xFF111E40), Color(0xFF161D3C), Color(0xFF071226)],
    ).createShader(bounds));
    // A restrained astral nebula with empty center for gameplay visibility.
    canvas.drawRect(bounds, Paint()..shader = RadialGradient(
      center: const Alignment(-.72, -.38), radius: 1.1,
      colors: [const Color(0xFF5A4686).withValues(alpha: .34),
        const Color(0xFF254C84).withValues(alpha: .08), Colors.transparent],
    ).createShader(bounds));
    canvas.drawRect(bounds, Paint()..shader = RadialGradient(
      center: const Alignment(.9, .2), radius: .9,
      colors: [const Color(0xFF236E81).withValues(alpha: .22), Colors.transparent],
    ).createShader(bounds));
    // Silhouettes of Lunaryvell's distant floating citadel, parallax layers.
    for (var layer = 0; layer < 2; layer++) {
      final depth = layer == 0 ? .20 : .12;
      final floor = size.y * (layer == 0 ? .94 : .99);
      final color = layer == 0 ? const Color(0x88203057)
          : const Color(0xCC101931);
      final path = Path()..moveTo(0, size.y)
        ..lineTo(0, floor - size.y * depth * .8);
      for (var i = 0; i < 8; i++) {
        final x = i * size.x / 7;
        final height = (i % 3 + 1) * size.y * depth / 3;
        path
          ..lineTo(x - 10, floor)
          ..lineTo(x - 7, floor - height)
          ..lineTo(x, floor - height - 14)
          ..lineTo(x + 7, floor - height)
          ..lineTo(x + 10, floor);
      }
      path..lineTo(size.x, size.y)..close();
      canvas.drawPath(path, Paint()..color = color);
    }
    final paint = Paint()..color = const Color(0xFFB6D6FF).withValues(alpha: .55);
    for (var i = 0; i < 68; i++) {
      final x = (i * 73.0) % math.max(1.0, size.x).toDouble();
      final y = ((i * 131.0) + _waveElapsed * (12 + i % 4 * 5)) %
          math.max(1.0, size.y).toDouble();
      canvas.drawCircle(Offset(x, y), i % 9 == 0 ? 1.5 : .65, paint);
    }
  }

  void _paintChapterScene(Canvas canvas, ui.Image scene, Rect destination,
      {double opacity = 1}) {
    final scale = math.max(size.x / scene.width, size.y / scene.height);
    final crop = Rect.fromCenter(
      center: Offset(scene.width / 2, scene.height / 2),
      width: size.x / scale,
      height: size.y / scale,
    );
    final alpha = (opacity.clamp(0.0, 1.0) * 255).round();
    canvas.drawImageRect(scene, crop, destination, Paint()
      ..filterQuality = FilterQuality.medium
      ..colorFilter = ui.ColorFilter.mode(
          Color.fromARGB(alpha, 255, 255, 255), ui.BlendMode.modulate));
  }
}
