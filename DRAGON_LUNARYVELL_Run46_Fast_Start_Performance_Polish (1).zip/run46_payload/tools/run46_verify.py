#!/usr/bin/env python3
"""Run 46 preflight: faster launch, smooth late scenery, bounded diagnostics."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
game = (ROOT / 'lib/game/dragon_lunaryvell_game.dart').read_text()
ui = (ROOT / 'lib/ui/dragon_shell.dart').read_text()
fx = (ROOT / 'lib/game/premium_projectile_fx.dart').read_text()
rules = (ROOT / 'lib/game/boss_encounter_rules.dart').read_text()
meter = (ROOT / 'lib/game/frame_pacing_meter.dart').read_text()
test = (ROOT / 'test/run46_frame_pacing_test.dart').read_text()

for token in (
    'unawaited(_preloadChapterScenery());',
    'final enemiesReady = _preloadEnemySprites();',
    'final battlefieldReady = _preloadBattlefield();',
    'selectedDragonReady, selectedMagicReady',
    '_chapterFadeRemaining = _chapterFadeSeconds;',
    'for (var tier = 1; tier <= 4; tier++)',
    '_enemyFrames = await Future.wait(<Future<List<ui.Image>>>[',
    'final FramePacingMeter _framePacing = FramePacingMeter();',
    '_framePacing.sample(dt);',
    '_framePacing.reset();',
    '_framePacing.diagnosticLine',
    '_chapterBossFrames.where((f) => f.length == 8).length',
    'math.sqrt((ax - bx) * (ax - bx) + (ay - by) * (ay - by))',
):
    assert token in game, f'Missing Run 46 performance hook: {token}'

assert 'chapterSceneryReady' not in game, 'Future chapter scenes block startup'
assert 'math.pow(' not in game, 'Expensive power in per-frame distances'
assert 'void sample(double elapsedSeconds)' in meter
assert 'elapsedSeconds > .50' in meter
assert 'elapsedSeconds > .034' in meter
assert 'slow frame counts are visible' in test
for name, content in (
    ('game', game), ('shell', ui), ('projectile FX', fx),
):
    assert '.withOpacity(' not in content, f'Unmigrated opacity in {name}'
assert 'BossEncounterRules.phaseForHealth(' in game
assert '_bossChargeRemaining' in game
assert 'BossEncounterRules.volley(' in game
assert 'PremiumProjectileFx.drawPlayerUnderlay(' in game
assert '_fireEnemyVolley(foe, archetype)' in game
assert 'unawaited(_preloadRun43EnemiesAndMagic())' in game
assert 'BossCombatPhase.unleashed' in rules
assert 'ALL SIX ENEMIES' in ui
assert 'Run46 ${_framePacing.diagnosticLine}' in game
assert 'test(' in test

print('RUN 46 PREFLIGHT PASS — four chapter images no longer gate startup; '
      'parallel first-wave enemy decode; smooth late chapter fades; '
      'bounded FPS diagnostics; faster distance math; obsolete opacity '
      'calls removed; Run 45 boss and Run 44 enemy contracts retained.')
