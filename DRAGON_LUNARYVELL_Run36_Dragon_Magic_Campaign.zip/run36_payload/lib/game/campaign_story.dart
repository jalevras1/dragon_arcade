/// Five connected acts of DRAGON LUNARYVELL. Each act shares the same wave
/// scheduler as Arcade; only the story gates and final victory differ.
class CampaignChapter {
  const CampaignChapter(this.number, this.title, this.story, this.bossTitle);

  final int number;
  final String title;
  final String story;
  final String bossTitle;

  static const chapters = <CampaignChapter>[
    CampaignChapter(1, 'The Shattered Moonheart',
        'The eclipse has broken the Moonheart above Lunaryvell. From the '
        'Astral Citadel, six dragon guardians take flight to rescue its first '
        'scattered fragment before the sky raiders carry it into shadow.',
        'THE SKYWARD WARDEN'),
    CampaignChapter(2, 'The Emberfall March',
        'A stolen Moonheart shard awakens an ancient firestorm. Follow the '
        'burning wind across the Emberfall peaks and reclaim the flame before '
        'the mountains fall silent.',
        'THE ASHEN TYRANT'),
    CampaignChapter(3, 'Whispers of the Hollow',
        'Shadow wyverns now gather around a tear in the night. Their master '
        'is feeding the eclipse with stolen starlight. Close the rift.',
        'THE HOLLOW SOVEREIGN'),
    CampaignChapter(4, 'The Drowned Constellation',
        'Under stormbound seas, an ancient sanctuary shields the last free '
        'fragment. Guard its awakening against the creatures of the deep.',
        'THE ABYSSAL SENTINEL'),
    CampaignChapter(5, 'The Eclipse Throne',
        'The Moonheart fragments reunite at the Astral Citadel. One final '
        'guardian stands between the dragons and a dawn without stars. '
        'Fly together into the heart of the eclipse.',
        'THE ECLIPSE WARDEN'),
  ];

  static const int wavesPerChapter = 5;
  static const int finalWave = 25;

  static CampaignChapter forWave(int wave) {
    final index = ((wave - 1) ~/ wavesPerChapter)
        .clamp(0, chapters.length - 1).toInt();
    return chapters[index];
  }
}
