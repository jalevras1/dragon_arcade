/// Small, immutable gameplay contracts for the six approved dragon powers.
/// Visual art remains 2D; no additional asset/network loading is required.
class SpecialAbilityRule {
  const SpecialAbilityRule({
    required this.dragonId,
    required this.name,
    required this.cooldown,
    required this.targetCount,
    required this.effectSeconds,
  });

  final String dragonId;
  final String name;
  final double cooldown;
  final int targetCount;
  final double effectSeconds;
}

class SpecialAbilityRules {
  const SpecialAbilityRules._();

  static const Map<String, SpecialAbilityRule> byDragon = {
    'astralis': SpecialAbilityRule(
        dragonId: 'astralis', name: 'Celestial Nova', cooldown: 11,
        targetCount: 6, effectSeconds: .75),
    'temperstryx': SpecialAbilityRule(
        dragonId: 'temperstryx', name: 'Lightning Dash', cooldown: 12,
        targetCount: 5, effectSeconds: .65),
    'ignivar': SpecialAbilityRule(
        dragonId: 'ignivar', name: 'Dragonfire Barrage', cooldown: 11,
        targetCount: 6, effectSeconds: 2.1),
    'nyxariel': SpecialAbilityRule(
        dragonId: 'nyxariel', name: 'Void Shift', cooldown: 12,
        targetCount: 5, effectSeconds: 2.2),
    'solarion': SpecialAbilityRule(
        dragonId: 'solarion', name: 'Solar Collapse', cooldown: 13,
        targetCount: 4, effectSeconds: 1.25),
    'aquaryth': SpecialAbilityRule(
        dragonId: 'aquaryth', name: 'Tidal Vortex', cooldown: 12,
        targetCount: 6, effectSeconds: 2.8),
  };

  static SpecialAbilityRule forDragon(String id) =>
      byDragon[id] ?? byDragon['astralis']!;
}
