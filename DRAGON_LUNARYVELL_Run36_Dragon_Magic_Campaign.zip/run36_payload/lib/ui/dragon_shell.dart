import 'dart:async' show unawaited;
import 'dart:math' as math;

import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../game/dragon_lunaryvell_game.dart';
import '../game/dragon_profile.dart';
import '../game/campaign_story.dart';

const _navy = Color(0xFF050817);
const _blue = Color(0xFF65D9FF);
const _gold = Color(0xFFFFD77A);
const _emblem = 'assets/images/branding/lunaryvell_emblem.png';
const _enableTestTools = bool.fromEnvironment('DL_DEV_TOOLS', defaultValue: false);

class DragonShell extends StatefulWidget {
  const DragonShell({super.key});

  @override
  State<DragonShell> createState() => _DragonShellState();
}

class _DragonShellState extends State<DragonShell> {
  DragonProfile _selected = DragonProfile.astralis;
  bool _playing = false;
  bool _campaign = false;
  int _session = 0;

  Future<void> _beginCampaign() async {
    final start = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF15213E),
        title: const Text('THE SHATTERED MOONHEART',
          style: TextStyle(color: _gold, fontSize: 19)),
        content: const Text(
            'CHAPTER I  ·  WAVES 1–5\n\n'
            'The eclipse has shattered the Moonheart above Lunaryvell. '
            'The dragon guardians must recover five lost fragments. '
            'Each chapter holds five waves and a powerful guardian boss.\n\n'
            'Your story begins at the Astral Citadel.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: const Text('NOT YET')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true),
              child: const Text('TAKE FLIGHT')),
        ],
      ),
    );
    if (start == true && mounted) {
      setState(() { _campaign = true; _session++; _playing = true; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: _playing
              ? _GameScreen(
                  key: ValueKey(_session),
                  dragon: _selected,
                  campaignMode: _campaign,
                  onMenu: () => setState(() => _playing = false),
                  onDragonChanged: (dragon) => _selected = dragon,
                )
              : _TitleScreen(
                  selected: _selected,
                  onPlay: () => setState(() {
                    _campaign = false;
                    _session++;
                    _playing = true;
                  }),
                  onCampaign: _beginCampaign,
                  onChoose: () => _chooseDragon(
                    context,
                    selected: _selected,
                    onChoose: (dragon) => setState(() => _selected = dragon),
                  ),
                ),
        ),
      );
}

class _TitleScreen extends StatelessWidget {
  const _TitleScreen({
    required this.selected,
    required this.onPlay,
    required this.onCampaign,
    required this.onChoose,
  });

  final DragonProfile selected;
  final VoidCallback onPlay;
  final VoidCallback onCampaign;
  final VoidCallback onChoose;

  @override
  Widget build(BuildContext context) => _NightBackdrop(
        child: LayoutBuilder(
          builder: (context, size) => SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: size.maxHeight),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Emblem(size: math.min(size.maxHeight * .3, 218.0)),
                    const Column(
                      children: [
                        Text('DRAGON',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: _gold, fontSize: 31,
                                fontWeight: FontWeight.w900, letterSpacing: 7)),
                        Text('LUNARYVELL',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Colors.white, fontSize: 28,
                                fontWeight: FontWeight.w800, letterSpacing: 2)),
                        SizedBox(height: 8),
                        Text('RISE ABOVE THE ECLIPSE',
                            style: TextStyle(
                                color: _blue, fontSize: 10,
                                letterSpacing: 2.5)),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 350),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          FilledButton.icon(
                            onPressed: onPlay,
                            icon: const Icon(Icons.play_arrow_rounded),
                            label: const Text('BEGIN FLIGHT'),
                            style: FilledButton.styleFrom(
                                backgroundColor: const Color(0xFF2958A8),
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                    vertical: 16)),
                          ),
                          const SizedBox(height: 10),
                          FilledButton.icon(
                            onPressed: onCampaign,
                            icon: const Icon(Icons.menu_book_outlined),
                            label: const Text('CAMPAIGN  ·  STORY MODE'),
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF654786),
                              foregroundColor: _gold,
                              padding: const EdgeInsets.symmetric(vertical: 15),
                              side: const BorderSide(color: Color(0xFFB48DE7)),
                            ),
                          ),
                          const SizedBox(height: 12),
                          OutlinedButton.icon(
                            onPressed: onChoose,
                            icon: const Icon(Icons.auto_awesome),
                            label: Text('DRAGON: ${selected.name}'),
                            style: OutlinedButton.styleFrom(
                                foregroundColor: _gold,
                                side: const BorderSide(
                                    color: Color(0x8885B9F1)),
                                padding: const EdgeInsets.symmetric(
                                    vertical: 14)),
                          ),
                          const SizedBox(height: 10),
                          OutlinedButton.icon(
                            onPressed: () => _info(context, 'HOW TO PLAY',
                                'Drag on the battlefield to fly. Your dragon '
                                'fires automatically. Dodge attacks and survive '
                                'each wave. Tap your special ability to use its '
                                'power. You can also switch dragons mid-flight.'),
                            icon: const Icon(Icons.help_outline),
                            label: const Text('HOW TO PLAY'),
                          ),
                          TextButton(
                            onPressed: () => _info(context, 'ABOUT THE GAME',
                                'DRAGON LUNARYVELL is an original 2D dragon '
                                'arcade adventure featuring six playable dragons. '
                                'Created for portrait touch-screen play.'),
                            child: const Text('ABOUT THE GAME'),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class _GameScreen extends StatefulWidget {
  const _GameScreen({
    super.key,
    required this.dragon,
    required this.campaignMode,
    required this.onMenu,
    required this.onDragonChanged,
  });
  final DragonProfile dragon;
  final bool campaignMode;
  final VoidCallback onMenu;
  final ValueChanged<DragonProfile> onDragonChanged;

  @override
  State<_GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<_GameScreen> {
  late final DragonLunaryvellGame _game;

  @override
  void initState() {
    super.initState();
    _game = DragonLunaryvellGame(
      dragon: widget.dragon, campaignMode: widget.campaignMode);
  }

  @override
  Widget build(BuildContext context) => Stack(
        fit: StackFit.expand,
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onPanDown: (e) => _game.setTouchTarget(e.localPosition),
            onPanUpdate: (e) => _game.setTouchTarget(e.localPosition),
            onPanEnd: (_) => _game.releaseTouch(),
            onPanCancel: _game.releaseTouch,
            child: GameWidget<DragonLunaryvellGame>(
              game: _game,
              loadingBuilder: (context) => const _LoadingScreen(),
              errorBuilder: (context, error) => _NightBackdrop(
                child: Center(child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.error_outline, size: 44, color: _gold),
                    const SizedBox(height: 10),
                    const Text('FLIGHT COULD NOT LOAD'),
                    const SizedBox(height: 12),
                    Text(error.toString(), textAlign: TextAlign.center,
                        maxLines: 5, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 15),
                    FilledButton(onPressed: widget.onMenu,
                        child: const Text('RETURN TO TITLE')),
                  ]),
                )),
              ),
            ),
          ),
          Positioned(
            left: 8, right: 8, top: 8,
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => Row(children: [
                Expanded(child: _HudPill('SCORE', '${state.score}')),
                const SizedBox(width: 5),
                Expanded(child: _HudPill(
                    state.campaignMode ? 'STORY' : 'WAVE',
                    state.campaignMode
                        ? '${(state.wave - 1) ~/ 5 + 1} · ${state.wave}'
                        : '${state.wave}')),
                const SizedBox(width: 5),
                Expanded(child: _HudPill('HULL', '${state.health}')),
                const SizedBox(width: 5),
                IconButton.filledTonal(
                  tooltip: 'Select dragon: ${state.dragonName}',
                  icon: const Icon(Icons.auto_awesome, color: _gold),
                  onPressed: () => _chooseDragon(
                    context,
                    selected: _game.dragon,
                    onChoose: (dragon) {
                      widget.onDragonChanged(dragon);
                      unawaited(_game.selectDragon(dragon));
                    },
                  ),
                ),
              ]),
            ),
          ),
          if (_enableTestTools)
            Positioned(
              right: 8, top: 64,
              child: IconButton.filledTonal(
                tooltip: 'Developer test controls',
                icon: const Icon(Icons.bug_report_outlined),
                onPressed: () => _developerPanel(context, _game),
              ),
            ),
          Positioned(
            bottom: 14, left: 10,
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => Row(children: [
                IconButton.filledTonal(
                  tooltip: state.paused ? 'Resume' : 'Pause',
                  icon: Icon(state.paused ? Icons.play_arrow : Icons.pause),
                  onPressed: _game.togglePause,
                ),
                const SizedBox(width: 5),
                IconButton.filledTonal(
                  tooltip: 'Return to title',
                  icon: const Icon(Icons.home_outlined),
                  onPressed: widget.onMenu,
                ),
              ]),
            ),
          ),
          Positioned(
            bottom: 72, left: 10,
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => Wrap(spacing: 5, children: [
                if (state.hasteRemaining > 0)
                  _BoostChip(Icons.speed, 'HASTE', _blue),
                if (state.critRemaining > 0)
                  _BoostChip(Icons.auto_awesome, 'CRITICAL', _gold),
                if (state.shields > 0)
                  _BoostChip(Icons.shield_outlined,
                      'SHIELD ×${state.shields}', const Color(0xFF93B5FF)),
              ]),
            ),
          ),
          Positioned(
            bottom: 14, right: 8,
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (state.bossActive)
                    Text(state.campaignMode
                        ? CampaignChapter.forWave(state.wave).bossTitle
                        : 'BOSS INBOUND',
                        style: const TextStyle(
                            color: Color(0xFFFFAC92), fontSize: 10,
                            fontWeight: FontWeight.bold)),
                  Text('DRAG TO FLY  ·  AUTO-FIRE',
                      style: TextStyle(
                          color: Colors.white.withOpacity(.7), fontSize: 10)),
                  const SizedBox(height: 6),
                  _SpecialAbilityButton(
                    dragon: _game.dragon,
                    state: state,
                    onPressed: _game.activateSpecial,
                  ),
                ],
              ),
            ),
          ),
          Positioned.fill(
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) => state.health <= 0
                  ? Center(child: FilledButton.icon(
                      onPressed: _game.restartGame,
                      icon: const Icon(Icons.replay),
                      label: const Text('FLY AGAIN')))
                  : const SizedBox.shrink(),
            ),
          ),
          Positioned.fill(
            child: ValueListenableBuilder<DragonHudState>(
              valueListenable: _game.hud,
              builder: (context, state, _) {
                if (!state.campaignIntermission && !state.campaignComplete) {
                  return const SizedBox.shrink();
                }
                final chapter = CampaignChapter.forWave(state.wave);
                return ColoredBox(
                  color: const Color(0xE9050B1E),
                  child: Center(child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(26),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.auto_awesome, color: _gold, size: 48),
                        const SizedBox(height: 12),
                        Text(state.campaignComplete
                            ? 'THE MOONHEART IS RESTORED'
                            : 'CHAPTER ${chapter.number} OF 5',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: _gold,
                              letterSpacing: 2, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                        Text(state.campaignComplete
                            ? 'DAWN OVER LUNARYVELL'
                            : chapter.title.toUpperCase(),
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 23,
                              fontWeight: FontWeight.w900)),
                        const SizedBox(height: 12),
                        Text(state.campaignComplete
                            ? 'You have defeated the Eclipse Warden and reunited '
                                'the Moonheart. The six dragon guardians have '
                                'brought starlight back to Lunaryvell.'
                            : chapter.story,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white70,
                              fontSize: 15, height: 1.5)),
                        const SizedBox(height: 22),
                        FilledButton.icon(
                          onPressed: state.campaignComplete
                              ? widget.onMenu : _game.continueCampaign,
                          icon: Icon(state.campaignComplete
                              ? Icons.home_outlined : Icons.flight_takeoff),
                          label: Text(state.campaignComplete
                              ? 'RETURN TO TITLE' : 'CONTINUE THE STORY'),
                        ),
                      ]),
                    ),
                  )),
                );
              },
            ),
          ),
        ],
      );
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen();
  @override
  Widget build(BuildContext context) => _NightBackdrop(
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _Emblem(size: 168),
              SizedBox(height: 12),
              Text('DRAGON LUNARYVELL',
                  style: TextStyle(color: _gold, fontSize: 17,
                      fontWeight: FontWeight.w800, letterSpacing: 1.8)),
              SizedBox(height: 24),
              CircularProgressIndicator(color: _blue),
              SizedBox(height: 16),
              Text('SUMMONING THE SKIES…',
                  style: TextStyle(color: Colors.white70,
                      fontSize: 11, letterSpacing: 1.5)),
            ],
          ),
        ),
      );
}

class _Emblem extends StatelessWidget {
  const _Emblem({required this.size});
  final double size;
  @override
  Widget build(BuildContext context) => Image.asset(
        _emblem,
        width: size,
        height: size,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stack) => SizedBox(
          width: size,
          height: size,
          child: const Icon(Icons.auto_awesome, color: _gold, size: 90),
        ),
      );
}

class _NightBackdrop extends StatelessWidget {
  const _NightBackdrop({required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -.5),
            radius: 1.3,
            colors: [Color(0xFF243C70), Color(0xFF121A35), _navy],
            stops: [0, .48, 1],
          ),
        ),
        child: Stack(fit: StackFit.expand, children: [
          const IgnorePointer(child: CustomPaint(painter: _Stars())),
          child,
        ]),
      );
}

class _Stars extends CustomPainter {
  const _Stars();
  @override
  void paint(Canvas canvas, Size size) {
    final rand = math.Random(2307);
    for (var i = 0; i < 86; i++) {
      canvas.drawCircle(
          Offset(rand.nextDouble() * size.width,
              rand.nextDouble() * size.height),
          i % 7 == 0 ? 1.25 : .65,
          Paint()..color = Colors.white.withOpacity(
              .15 + rand.nextDouble() * .5));
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _BoostChip extends StatelessWidget {
  const _BoostChip(this.icon, this.label, this.color);
  final IconData icon;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(
      color: const Color(0xE9101930),
      border: Border.all(color: color.withOpacity(.6)),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: color, size: 12),
        const SizedBox(width: 3),
        Text(label, style: TextStyle(color: color,
            fontWeight: FontWeight.bold, fontSize: 9)),
      ]),
    ),
  );
}

class _SpecialAbilityButton extends StatelessWidget {
  const _SpecialAbilityButton({required this.dragon,
      required this.state, required this.onPressed});
  final DragonProfile dragon;
  final DragonHudState state;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final ready = state.specialRemaining <= 0 && !state.paused;
    final color = dragon.palette;
    final icon = switch (dragon.id) {
      'astralis' => Icons.auto_awesome,
      'temperstryx' => Icons.electric_bolt,
      'ignivar' => Icons.local_fire_department,
      'nyxariel' => Icons.nights_stay,
      'solarion' => Icons.sunny,
      'aquaryth' => Icons.water_drop,
      _ => Icons.auto_awesome,
    };
    final progress = state.specialMax <= 0 ? 0.0 :
        (1 - state.specialRemaining / state.specialMax)
            .clamp(0.0, 1.0).toDouble();
    return SizedBox(
      width: 184,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: ready
              ? [const Color(0xFF1F3556), color.withOpacity(.75)]
              : [const Color(0xFF101A2C), const Color(0xFF1A2340)]),
          border: Border.all(color: ready ? _gold
              : const Color(0xFF52627B), width: ready ? 1.5 : 1),
          borderRadius: BorderRadius.circular(14),
          boxShadow: ready ? [BoxShadow(
              color: color.withOpacity(.25), blurRadius: 10)] : [],
        ),
        child: Material(color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: ready ? onPressed : null,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 7),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Row(children: [
                  Icon(icon, color: ready ? _gold : Colors.white54,
                      size: 25),
                  const SizedBox(width: 7),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(dragon.specialAbility.toUpperCase(),
                          maxLines: 2, overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: ready ? Colors.white
                              : Colors.white70, fontSize: 10,
                              fontWeight: FontWeight.w900)),
                      Text(ready ? 'TAP TO UNLEASH' :
                          '${state.specialRemaining.ceil()}s  ·  RECHARGING',
                          style: TextStyle(color: ready ? _gold : _blue,
                              letterSpacing: .3, fontSize: 9)),
                    ],
                  )),
                ]),
                const SizedBox(height: 7),
                ClipRRect(borderRadius: BorderRadius.circular(3),
                  child: LinearProgressIndicator(
                    minHeight: 3,
                    value: progress,
                    color: ready ? _gold : color,
                    backgroundColor: const Color(0xFF33425A),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _HudPill extends StatelessWidget {
  const _HudPill(this.label, this.value);
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xF02A3554), Color(0xEE101A35)]),
          border: Border.all(color: const Color(0x88D2BA85)),
          borderRadius: BorderRadius.circular(10),
          boxShadow: const [BoxShadow(color: Color(0x8804081B), blurRadius: 5)],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 6),
          child: Column(children: [
            Text(label, style: const TextStyle(
                color: _blue, fontSize: 9, letterSpacing: 1.1)),
            Text(value, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white, fontSize: 16,
                    fontWeight: FontWeight.bold)),
          ]),
        ),
      );
}

void _chooseDragon(BuildContext context, {
  required DragonProfile selected,
  required ValueChanged<DragonProfile> onChoose,
}) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF101B35),
    builder: (sheetContext) => SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(sheetContext).height * .77),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: Text('CHOOSE YOUR DRAGON', style: TextStyle(
                color: _gold, fontWeight: FontWeight.bold,
                fontSize: 16, letterSpacing: 1.2)),
          ),
          Flexible(child: ListView.builder(
            shrinkWrap: true,
            itemCount: DragonProfile.all.length,
            itemBuilder: (context, i) {
              final profile = DragonProfile.all[i];
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: profile.palette.withOpacity(.2),
                  child: Icon(Icons.auto_awesome, color: profile.palette),
                ),
                title: Text(profile.name,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${profile.title} · ${profile.playStyle}',
                    maxLines: 2),
                trailing: profile.id == selected.id
                    ? const Icon(Icons.check_circle, color: _gold)
                    : const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.pop(sheetContext);
                  onChoose(profile);
                },
              );
            },
          )),
        ]),
      ),
    ),
  );
}

void _info(BuildContext context, String title, String message) {
  showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx),
          child: const Text('CLOSE'))],
    ),
  );
}

void _developerPanel(BuildContext context, DragonLunaryvellGame game) {
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (sheetContext) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        child: Wrap(spacing: 10, runSpacing: 10, children: [
          const ListTile(
            title: Text('FLIGHT TEST TOOLS'),
            subtitle: Text('Only present in builds made with DL_DEV_TOOLS=true'),
          ),
          OutlinedButton.icon(
            icon: const Icon(Icons.skip_next), label: const Text('NEXT WAVE'),
            onPressed: () { game.developerNextWave(); Navigator.pop(sheetContext); },
          ),
          OutlinedButton.icon(
            icon: const Icon(Icons.favorite), label: const Text('HEAL'),
            onPressed: () { game.developerHeal(); Navigator.pop(sheetContext); },
          ),
          OutlinedButton.icon(
            icon: const Icon(Icons.add), label: const Text('SKY RAIDER'),
            onPressed: () { game.developerSpawnEnemy(0); Navigator.pop(sheetContext); },
          ),
          OutlinedButton.icon(
            icon: const Icon(Icons.add), label: const Text('STORM HARPY'),
            onPressed: () { game.developerSpawnEnemy(1); Navigator.pop(sheetContext); },
          ),
          OutlinedButton.icon(
            icon: const Icon(Icons.add), label: const Text('SHADOW WYVERN'),
            onPressed: () { game.developerSpawnEnemy(2); Navigator.pop(sheetContext); },
          ),
        ]),
      ),
    ),
  );
}
