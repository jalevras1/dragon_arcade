import 'package:flutter_test/flutter_test.dart';
import 'package:dragon_lunaryvell/game/dragon_profile.dart';
import 'package:dragon_lunaryvell/game/special_ability_rules.dart';

void main() {
  test('all six approved dragons have distinct implemented powers', () {
    final ids = DragonProfile.all.map((d) => d.id).toSet();
    expect(SpecialAbilityRules.byDragon.keys.toSet(), ids);
    final names = SpecialAbilityRules.byDragon.values
        .map((rule) => rule.name)
        .toSet();
    expect(names.length, 6);
    for (final profile in DragonProfile.all) {
      final rule = SpecialAbilityRules.forDragon(profile.id);
      expect(rule.name, profile.specialAbility);
      expect(rule.cooldown, greaterThanOrEqualTo(9));
      expect(rule.effectSeconds, greaterThan(0));
      expect(rule.targetCount, greaterThanOrEqualTo(3));
    }
  });
}
