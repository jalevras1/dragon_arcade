import 'package:flutter_test/flutter_test.dart';
import 'package:dragon_lunaryvell/game/campaign_story.dart';

void main() {
  test('five story chapters share existing five-wave boss milestones', () {
    expect(CampaignChapter.chapters.length, 5);
    expect(CampaignChapter.finalWave, 25);
    for (var wave = 1; wave <= CampaignChapter.finalWave; wave++) {
      final chapter = CampaignChapter.forWave(wave);
      expect(chapter.number, ((wave - 1) ~/ 5) + 1);
      expect(chapter.title, isNotEmpty);
      expect(chapter.bossTitle, isNotEmpty);
      if (wave % 5 == 0) {
        expect(wave ~/ 5, chapter.number);
      }
    }
  });
}
