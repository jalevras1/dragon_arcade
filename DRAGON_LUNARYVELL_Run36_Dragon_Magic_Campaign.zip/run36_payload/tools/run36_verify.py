#!/usr/bin/env python3
"""Fast, dependency-free guard for the Run 36 campaign/gameplay delta."""
from pathlib import Path
import re

root = Path(__file__).resolve().parent.parent
game = (root / "lib/game/dragon_lunaryvell_game.dart").read_text()
shell = (root / "lib/ui/dragon_shell.dart").read_text()
story = (root / "lib/game/campaign_story.dart").read_text()
rules = (root / "lib/game/special_ability_rules.dart").read_text()

for token in ["_updateSpecialsAndPickups", "_damageTarget", "_defeatFoe",
              "_collectPickup", "_drawSpecialEffects", "continueCampaign",
              "_campaignComplete", "_campaignIntermission", "_shieldCharges"]:
    assert token in game, "Missing game feature: " + token
for token in ["CAMPAIGN  ·  STORY MODE", "_SpecialAbilityButton",
              "_BoostChip", "Chapter", "TAKE FLIGHT"]:
    assert token in shell or token.lower() in shell.lower(), token
assert "_run31AbilityImages" not in game, "Oversized old ability overlay still present"
assert "final bossWave = _wave % 5 == 0;" in game, "Existing wave logic changed"
assert "CampaignChapter.finalWave" in game and "finalWave = 25" in story
assert len(re.findall(r"CampaignChapter\(\d,", story)) == 5
for dragon in ["astralis", "temperstryx", "ignivar", "nyxariel",
               "solarion", "aquaryth"]:
    assert f"case '{dragon}':" in game, dragon
    assert f"'{dragon}': SpecialAbilityRule" in rules, dragon
assert "missile" not in game.lower(), "Mechanical weapon wording in dragon game"
print("RUN 36 PREFLIGHT PASS: 6 dragon magics, 3 pickups, 5 chapters, 5 boss waves")
