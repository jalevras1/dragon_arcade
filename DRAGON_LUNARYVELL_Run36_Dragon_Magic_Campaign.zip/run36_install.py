#!/usr/bin/env python3
"""Run 36 single-terminal, hash-guarded install with automatic rollback."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path, PurePosixPath
import argparse
import json
import shutil
import subprocess
import sys

ROOT = Path.cwd().resolve()
BRANCH = "dragon-lunaryvell-repairs"


def hash_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_target(relative: str) -> Path:
    parsed = PurePosixPath(relative)
    if parsed.is_absolute() or ".." in parsed.parts or not parsed.parts:
        raise ValueError("Unsafe ZIP path: " + relative)
    for i in range(1, len(parsed.parts) + 1):
        if ROOT.joinpath(*parsed.parts[:i]).is_symlink():
            raise ValueError("Symlink target refused: " + relative)
    return ROOT.joinpath(*parsed.parts)


def run(args: list[str], timeout: int) -> None:
    print("Checking:", " ".join(args), flush=True)
    subprocess.run(args, cwd=ROOT, check=True, timeout=timeout)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-build", action="store_true",
                        help="Only for offline installer QA, no playable update")
    options = parser.parse_args()
    if not (ROOT / ".git").exists() or not (ROOT / "pubspec.yaml").is_file():
        print("STOP: Open the existing dragon_arcade project first. No files changed.")
        return 2
    branch = subprocess.check_output(
        ["git", "branch", "--show-current"], cwd=ROOT, text=True).strip()
    if branch != BRANCH:
        print(f"STOP: Branch {branch!r} differs from expected {BRANCH!r}.")
        return 2
    manifest_file = ROOT / "run36_manifest.json"
    if not manifest_file.is_file():
        print("STOP: Run 36 ZIP was not extracted. No files changed.")
        return 2
    manifest = json.loads(manifest_file.read_text())
    if manifest.get("run") != 36 or manifest.get("branch") != BRANCH:
        print("STOP: Wrong Run 36 manifest. No files changed.")
        return 2
    flutter = shutil.which("flutter")
    if not options.skip_build and not flutter:
        maybe = Path.home() / "flutter/bin/flutter"
        flutter = str(maybe) if maybe.is_file() else None
    if not options.skip_build and not flutter:
        print("STOP: Flutter unavailable here. No files changed.")
        return 2

    pending: list[tuple[str, Path, Path]] = []
    for entry in manifest["files"]:
        rel = entry["path"]
        dst = safe_target(rel)
        src = ROOT / "run36_payload" / rel
        if not src.is_file() or hash_file(src) != entry["new_sha256"]:
            print("STOP: ZIP payload missing/damaged:", rel)
            return 2
        previous = entry["old_sha256"]
        if dst.exists():
            existing = hash_file(dst)
            if existing == entry["new_sha256"]:
                continue
            if existing != previous:
                print("STOP: Local edits/version mismatch:", rel)
                print("No changes made; previous work is preserved.")
                return 2
        elif previous is not None:
            print("STOP: Expected Run 35 file missing:", rel)
            return 2
        pending.append((rel, src, dst))

    if not pending:
        print("RUN 36 ALREADY INSTALLED. Refresh your current game page.")
        return 0

    backup = ROOT / ".run36_backups" / datetime.now(timezone.utc).strftime(
        "%Y%m%d_%H%M%S_%f")
    build = ROOT / "build/web"
    old_web = backup / "previous_web"
    backup.mkdir(parents=True)
    originals = []
    web_moved = False
    try:
        for rel, source, target in pending:
            existed = target.is_file()
            originals.append((rel, target, existed))
            if existed:
                saved = backup / "original_files" / rel
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
        for rel, source, target in pending:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        run([sys.executable, "tools/run36_verify.py"], 25)
        run([sys.executable, "tools/run35_verify.py"], 80)
        if not options.skip_build:
            run([flutter, "test", "test/widget_test.dart",
                 "test/special_ability_rules_test.dart",
                 "test/campaign_story_test.dart"], 300)
            # Retain the known-good served web build in the rollback folder.
            if build.is_dir():
                shutil.move(str(build), str(old_web))
                web_moved = True
            run([flutter, "build", "web", "--release", "--no-pub",
                 "--dart-define=DL_DEV_TOOLS=true"], 900)
            if not (build / "index.html").is_file():
                raise RuntimeError("Web build missing index.html")
        (backup / "SUCCESS.txt").write_text(
            "Run 36 verified " +
            ("without build" if options.skip_build else "and built for web") + "\n")
        print("\nRUN 36 COMPLETE — dragon magic, pickups, campaign ready.")
        print("Previous versions retained at", backup.relative_to(ROOT))
        if options.skip_build:
            print("NOTE: --skip-build did not make a playable web bundle.")
        else:
            print("Refresh your existing port 8765 preview; no new terminal needed.")
        return 0
    except BaseException as error:
        print("\nCHECK OR BUILD FAILED:", error)
        print("Restoring the working Run 35 files…", flush=True)
        for rel, target, existed in reversed(originals):
            if existed:
                saved = backup / "original_files" / rel
                if saved.is_file():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(saved, target)
            elif target.is_file():
                target.unlink()
        if web_moved:
            if build.is_dir():
                shutil.rmtree(build)
            shutil.move(str(old_web), str(build))
        print("ROLLBACK COMPLETE. Your earlier game version remains saved.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
