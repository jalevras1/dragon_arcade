#!/usr/bin/env python3
"""Guarded, non-destructive Run 31 asset/code installer for GitHub Codespaces.

Execute from the Flutter project root after extracting this pack.
It never edits a source file with unknown content and never overwrites an
existing different asset. Pre-existing work is preserved by design.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

PACK = Path(__file__).resolve().parent
ROOT = Path.cwd().resolve()
BACKUP_DIR = ROOT / ".run31_backup"

BASELINE = {
    "lib/game/dragon_lunaryvell_game.dart":
        "2ae7a4ff3a4ae8503cef3c1b094dd601616efd5409d0a36824fe6a5616aefdad",
    "lib/main.dart":
        "b7791ac967eebab264af4619aac2d346cd1d35c5ee700170b208a48ee6a6ccaf",
    "pubspec.yaml":
        "2d126a93432bc794a7ad7af9bc03e16830bfdccb7ea249c32aca8fa423bc27fc",
}

EXPECTED_IMAGES = {
    "dragons/tempestryx_flight_base.png",
    "dragons/ignivar_flight_base.png",
    "dragons/nyxariel_flight_base.png",
    "dragons/solarion_flight_base.png",
    "dragons/aquaryth_flight_base.png",
    "abilities/astralis_celestial_nova.png",
    "abilities/tempestryx_lightning_dash.png",
    "abilities/ignivar_dragonfire_barrage.png",
    "abilities/nyxariel_void_shift.png",
    "abilities/solarion_solar_collapse.png",
    "abilities/aquaryth_tidal_vortex.png",
    "bosses/eclipse_gargoyle_warden.png",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(part)
    return digest.hexdigest()


def stop(reason: str) -> None:
    print("\nRUN31 STOPPED SAFELY:", reason)
    print("No existing code or assets were overwritten.")
    raise SystemExit(2)


def atomic_copy(src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=dest.parent, prefix=".run31_tmp_",
                                     delete=False) as stream:
        temp_path = Path(stream.name)
        try:
            with src.open("rb") as original:
                shutil.copyfileobj(original, stream)
        except BaseException:
            temp_path.unlink(missing_ok=True)
            raise
    try:
        os.replace(temp_path, dest)
    finally:
        temp_path.unlink(missing_ok=True)


def inventory() -> list[tuple[Path, Path]]:
    found = {
        path.relative_to(PACK).as_posix()
        for section in ("dragons", "abilities", "bosses")
        for path in (PACK / section).glob("*.png")
    }
    if found != EXPECTED_IMAGES:
        stop("The ZIP's 12 original PNGs are incomplete or unexpectedly named.")
    files = []
    for relative in sorted(EXPECTED_IMAGES):
        src = PACK / relative
        dest = ROOT / "assets" / "images" / "run31" / relative
        if dest.exists() and sha256(dest) != sha256(src):
            stop("Different artwork already exists at " +
                 dest.relative_to(ROOT).as_posix())
        files.append((src, dest))
    return files


def ensure_project() -> None:
    if not (ROOT / "pubspec.yaml").is_file() or not (
        ROOT / "lib" / "game" / "dragon_lunaryvell_game.dart"
    ).is_file():
        stop("Open the Flutter source project (folder with pubspec.yaml and lib).")


def source_state() -> tuple[str, dict[str, Path]]:
    patches = {}
    states = set()
    for name, baseline_hash in BASELINE.items():
        target = ROOT / name
        patched = PACK / "integration" / name
        if not target.is_file() or not patched.is_file():
            stop("Missing required source or integration file: " + name)
        if sha256(target) == baseline_hash:
            states.add("baseline")
        elif sha256(target) == sha256(patched):
            states.add("integrated")
        else:
            stop("Your " + name + " differs from the reviewed GitHub version. "
                 "I will not replace your newer work.")
        patches[name] = patched
    if len(states) > 1:
        stop("Some files are already integrated while others are not. "
             "Review the current Codespace before applying anything.")
    return states.pop(), patches


def create_backup() -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
    backup = BACKUP_DIR / stamp
    if backup.exists():
        stop("Backup already exists; run again after a moment.")
    backup.mkdir(parents=True)
    for name in BASELINE:
        dest = backup / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, dest)
    return backup


def restore(backup: Path) -> None:
    for name in BASELINE:
        atomic_copy(backup / name, ROOT / name)
    print("RUN31: source code restored from its untouched backup.")


def rollback() -> None:
    marker = BACKUP_DIR / "latest.json"
    if not marker.is_file():
        stop("No completed Run 31 install backup was found.")
    record = json.loads(marker.read_text(encoding="utf-8"))
    backup = BACKUP_DIR / record["stamp"]
    for name in BASELINE:
        target = ROOT / name
        if not (backup / name).is_file() or sha256(target) != sha256(
            PACK / "integration" / name
        ):
            stop("Source changed after installation; refusing to overwrite: " +
                 name)
    restore(backup)
    print("RUN31 ROLLBACK COMPLETE. Added art files remain, unused.")


def run_flutter(args: list[str], timeout: int) -> int:
    print("RUN31 CHECK:", " ".join(args), flush=True)
    try:
        return subprocess.run(args, cwd=ROOT, timeout=timeout, check=False).returncode
    except subprocess.TimeoutExpired:
        print("RUN31 CHECK TIMED OUT: " + " ".join(args))
        return 124


def main() -> None:
    parser = argparse.ArgumentParser(description="Install Run 31 safely")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--rollback", action="store_true")
    parser.add_argument("--skip-flutter-checks", action="store_true",
                        help="For offline packaging tests; not recommended in Codespaces")
    args = parser.parse_args()
    ensure_project()
    if args.rollback:
        rollback()
        return

    files = inventory()
    state, patches = source_state()
    print("RUN31 CHECKED: 12 images, correct Flutter project, and safe code state.")
    if args.dry_run:
        print("RUN31 DRY RUN PASSED. Nothing changed.")
        return

    added = 0
    for src, dest in files:
        if not dest.exists():
            atomic_copy(src, dest)
            added += 1
    print(f"RUN31 ASSETS READY: {len(files)} verified, {added} newly copied.")
    if state == "integrated":
        print("RUN31 CODE ALREADY INTEGRATED. No source files were replaced.")
        return

    backup = create_backup()
    try:
        for name, patched in patches.items():
            atomic_copy(patched, ROOT / name)
        if not args.skip_flutter_checks and shutil.which("flutter"):
            if run_flutter(["flutter", "pub", "get"], 180) != 0:
                raise RuntimeError("Flutter dependency check failed")
            if run_flutter(["flutter", "test", "--no-pub"], 300) != 0:
                raise RuntimeError("Flutter tests failed")
            analyze_result = run_flutter(["flutter", "analyze", "--no-pub"], 180)
            if analyze_result:
                print("RUN31 NOTE: analyzer reported issues; examine them "
                      "before committing. Flutter tests still passed.")
        elif not shutil.which("flutter"):
            print("RUN31 NOTE: Flutter is unavailable here. "
                  "The integration has NOT been compiled or tested.")
        else:
            print("RUN31 NOTE: Flutter checks skipped for local staging.")
    except BaseException as exc:
        restore(backup)
        print("RUN31 CODE ROLLED BACK:", exc)
        print("The 12 new images remain in their isolated run31 directory.")
        raise SystemExit(3)

    marker = BACKUP_DIR / "latest.json"
    marker.write_text(json.dumps({"stamp": backup.name}), encoding="utf-8")
    print("\nRUN31 INTEGRATION COMPLETE.")
    print("ASTRALIS 8-frame animation preserved; five alternate dragon poses, "
          "six special effects and the Gargoyle boss are connected.")
    print("Next: run a Flutter web build and inspect the game on your phone.")
    print("Do not commit the changes until the web build and phone test pass.")


if __name__ == "__main__":
    main()
