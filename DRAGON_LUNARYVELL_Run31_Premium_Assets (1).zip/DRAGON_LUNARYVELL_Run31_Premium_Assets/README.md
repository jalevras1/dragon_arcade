# DRAGON LUNARYVELL — Run 31 Premium Asset Pack

Created November 18, 2026. Original 2D fantasy art, designed for the existing Flutter/Flame portrait shooter. This pack **adds to** the earlier Runs 20–30; it does not replace those packs or recreate the existing ASTRALIS flight cycle, enemy sprites, or Astral Citadel backdrop.

## Safe one-time Codespaces integration

Upload the **whole ZIP file** to your existing Flutter source branch in GitHub Codespaces, at the level where `pubspec.yaml` and `lib/` appear. Keep it zipped on your phone.

Open the Codespaces terminal inside the Flutter repository and run these two commands in order:

```bash
unzip -oq DRAGON_LUNARYVELL_Run31_Premium_Assets.zip -d /tmp/dragon_run31
python3 /tmp/dragon_run31/DRAGON_LUNARYVELL_Run31_Premium_Assets/install_run31.py
```

The installer checks the 12 PNGs, verifies your current source matches the inspected GitHub version, refuses to overwrite any different artwork or newer code, backs up the three files it may modify, and uses the existing Flutter SDK to attempt dependency resolution, tests, and analysis. **If any source file differs from the reviewed version, it stops safely before changing anything.** If a Flutter dependency/test check fails, it restores the source files automatically. It never commits or pushes changes.

On success, the five alternate dragons can be selected by tapping the DRAGON label in the HUD; their poses are static placeholders until proper wing animation cycles exist. The default ASTRALIS keeps the original eight-frame animation. Each dragon has a short special-ability visual; the Gargoyle boss gets its new illustration. All original combat/hitbox logic is retained.

Next, from the same terminal, run a web build and visually test the game before committing:

```bash
flutter build web --no-wasm-dry-run
```

If the web build fails after a successful integration, the safe manual rollback is:

```bash
python3 /tmp/dragon_run31/DRAGON_LUNARYVELL_Run31_Premium_Assets/install_run31.py --rollback
```

That rollback restores the three original source/configuration files from their precise local backup; it intentionally leaves the isolated PNG assets in place. Do not use rollback after independently editing those files: the installer will refuse to overwrite newer work. If Codespaces restarts and removes its temporary extraction, repeat the unzip command before using rollback. No new apps, subscriptions, or tooling are needed beyond the existing GitHub Codespaces/Flutter workflow.

## Included: 12 original transparent PNGs

- `dragons/`: one overhead flying **base pose** each for TEMPESTRYX, IGNIVAR, NYXARIEL, SOLARION, and AQUARYTH (five files). These are **not** animated flight cycles yet.
- `abilities/`: one distinct effect each for ASTRALIS / Celestial Nova, TEMPESTRYX / Lightning Dash, IGNIVAR / Dragonfire Barrage, NYXARIEL / Void Shift, SOLARION / Solar Collapse, and AQUARYTH / Tidal Vortex (six files).
- `bosses/`: one static Eclipse Gargoyle Warden boss illustration (one file). It is **not** a boss animation.

Each file is a full-resolution RGBA PNG. An automated pixel check confirmed an alpha channel with both transparent and visible pixels in all 12 files. Art was inspected during generation, but sizing, safe margins, alpha-edge cleanup, memory use, animation, hitboxes, and gameplay performance are **not yet validated in Flutter**.

## Suggested project integration

1. Preserve the current working branch and all previous asset folders. Do not delete or overwrite any existing asset.
2. Prefer the guarded installer above: it places the PNGs under `assets/images/run31/` and registers those directories in `pubspec.yaml` when the source matches the inspected version.
3. For manual integration, independently verify the appropriate assets directories appear in `pubspec.yaml` under `flutter: assets:`. Do not duplicate a directory declaration if the parent is already registered.
4. Start with the five dragon base poses and the six ability sprites in a test screen. Scale down for runtime use, compare against the ASTRALIS art and tune placement. Keep the original PNGs as masters.
5. Add the Gargoyle Warden as a test boss sprite; gameplay logic, collisions, animation frames, and VFX timing still need to be connected.
6. Run Flutter analyze/build **after** wiring the assets. The included installer prepares and tests a guarded Dart integration, but **no edits were applied to your live Codespaces project from ChatGPT**, and successful compilation cannot be guaranteed until tested there.

## Quality and scope notes

**Current status: integration candidates**, not tested production sprites. Some effects have wispy, semitransparent glows extending to the canvas edges; crop or tighten visually after reviewing them on the live game background. SOLARION has a broad bright aura that may benefit from stronger edge masking. Sprite frame sizes and directions are not yet standardized, and any animation cycle requires additional artwork or rigging.

The source images created in this session are also retained in their original generated-image outputs. No existing DRAGON LUNARYVELL art was replaced. This ZIP is a named, importable **copy** of the new work.
