DRAGON LUNARYVELL RUN 41 - FIVE ANIMATED BOSSES + FOUR CAMPAIGN WORLDS

This update builds on the working Run 40 Developer Hub and preserves every
existing player-dragon frame, enemy frame, ability, menu and game rule.

NEW GAMEPLAY ASSETS
* Chapter I, wave 5: Eclipse Gargoyle Warden, new 8-frame animated wing cycle.
* Chapter II, wave 10: Ashen Drake Colossus, 8 transparent frames.
* Chapter III, wave 15: Moonveil Serpent, 8 transparent frames.
* Chapter IV, wave 20: Frost Harpy Matriarch, 8 transparent frames.
* Chapter V, wave 25: Eclipse Sovereign, 8 transparent frames.
* Four 720x1280 premium backgrounds; original first chapter retained.
* Smooth 1.4-second scene crossfade when entering another chapter.
* Bosses share an eight-frame, 100-ms flight cycle with stable alignment.
* All assets bundled locally; no third-party services, subscriptions or APIs.

INSTALL ON PHONE - THE SAME EXISTING TWO-SCREEN WORKFLOW:
1. Download this ZIP to your phone.
2. Upload to the same GitHub branch and tap Commit changes:
   https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs

3. Paste ONE LINE into the original Codespaces terminal:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run41_Animated_Bosses_Chapter_Worlds.zip && python3 run41_install.py

4. Wait for RUN 41 COMPLETE and refresh your EXISTING port 8765 test page.
5. Tap ARCADE -> DEV -> choose wave 5/10/15/20/25 -> TEST BOSS.
   Also use any wave 6/11/16/21 to inspect the new chapter scenery.

Each file is verified against its exact Run 40 SHA-256 before replacement;
unrecognized local edits are protected, and backups/rollback are automatic.
The installer runs Python preflights, Flutter tests and Flutter web release
build with DL_DEV_TOOLS=true. On failure it restores prior code and web build.
If STOP/FAILED appears, send only that line. Do not run random fixes.

README NOTE: The image-generation source art is already stored for reuse;
these in-game assets are actual registered frames and screen-ready scenery.
Frame animation is deterministic 2D wing deformation from one fixed painted
source per boss (not eight separately hand-painted anatomical poses).
