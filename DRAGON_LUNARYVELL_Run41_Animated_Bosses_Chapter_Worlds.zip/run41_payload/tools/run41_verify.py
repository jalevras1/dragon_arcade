#!/usr/bin/env python3
"""Run 41 gameplay art audit: boss wing cycles, chapter scenes, fades."""

from pathlib import Path
from PIL import Image, ImageChops, ImageStat

ROOT = Path(__file__).resolve().parent.parent
ART = ROOT / 'assets/images/run41'
GAME = (ROOT / 'lib/game/dragon_lunaryvell_game.dart').read_text()
PUBSPEC = (ROOT / 'pubspec.yaml').read_text()

BOSSES = [
    'eclipse_gargoyle_warden',
    'ashen_drake_colossus',
    'moonveil_serpent',
    'frost_harpy_matriarch',
    'eclipse_sovereign',
]
SCENES = [
    'ember_spires',
    'moonveil_abyss',
    'glacier_cathedral',
    'eclipse_throne',
]

for boss in BOSSES:
    alpha_history = []
    centers = []
    for frame in range(8):
        file = ART / 'bosses' / f'{boss}_{frame:02d}.png'
        assert file.is_file(), str(file)
        with Image.open(file) as image:
            assert image.mode == 'RGBA', (boss, frame, image.mode)
            assert image.size == (320, 256), (boss, frame, image.size)
            alpha = image.getchannel('A').copy()
            assert alpha.getpixel((0, 0)) == 0
            assert alpha.getpixel((image.width - 1, image.height - 1)) == 0
            bbox = alpha.point(lambda p: 255 if p > 96 else 0).getbbox()
            assert bbox is not None, (boss, frame, 'empty frame')
            left, top, right, bottom = bbox
            assert left >= 3 and right <= image.width - 3
            assert top >= 3 and bottom <= image.height - 3
            centers.append((left + right) / 2)
            alpha_history.append(alpha)
    assert max(centers) - min(centers) < 5, (boss, centers)
    differences = [
        ImageStat.Stat(ImageChops.difference(
            alpha_history[i], alpha_history[(i + 1) % 8])).mean[0]
        for i in range(8)
    ]
    assert min(differences) > .1, (boss, 'static or duplicate animation pose')
    assert max(differences) < 33, (boss, 'abrupt frame transition')

for name in SCENES:
    file = ART / 'backgrounds' / f'{name}.jpg'
    assert file.is_file(), str(file)
    with Image.open(file) as image:
        assert image.size == (720, 1280), (name, image.size)
        assert image.mode == 'RGB'
        assert file.stat().st_size < 500_000, (name, 'excessive download size')

for text in [
    'chapterSceneryReady = _preloadChapterScenery()',
    'unawaited(_preloadRun41BossFrames())',
    '_chapterBattlefieldArt',
    '_chapterBossFrames',
    'frames.length == 8',
    '(_fxTime / .1).floor() % flight.length',
    '_transitionChapterScenery();',
    '_chapterFadeSeconds = 1.4',
    'final eased = progress * progress * (3 - 2 * progress)',
    '_paintChapterScene(canvas, from, bounds)',
    '_paintChapterScene(canvas, scene, bounds, opacity: eased)',
    'ui.BlendMode.modulate',
]:
    assert text in GAME, text
for text in ['assets/images/run41/bosses/',
             'assets/images/run41/backgrounds/']:
    assert text in PUBSPEC, text

print('RUN 41 PREFLIGHT PASS: 40 authentic transparent 2D boss wing frames, '
      '4 premium chapter backgrounds, deterministic 1.4s smooth crossfades, '
      'Run 40 controls retained')
