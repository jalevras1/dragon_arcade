# DRAGON LUNARYVELL — Production Run 22 Gameplay Patch

This is a cautious source patch based on the saved Production Run 20 scaffold. It contains the seven listed project files at their normal Flutter paths. It is **not** a blind replacement instruction: compare with the live Codespaces project before copying files over.

## Included
- `lib/main.dart`
- `lib/game/dragon_profile.dart`
- `lib/game/dragon_lunaryvell_game.dart`
- `test/widget_test.dart`
- `test/dragon_profile_test.dart`
- `pubspec.yaml`
- `analysis_options.yaml`

## Gameplay/source corrections in this patch
1. Cooldown and invulnerability timers are advanced in `update()`, not mutated during `render()`.
2. Boss attacks no longer reset the player's special cooldown.
3. Ordinary foes now fire aimed projectiles at the player.
4. Projectile/enemy collision checks iterate snapshots so removing an enemy during a hit does not invalidate the active iteration.
5. The HUD `ValueNotifier` is disposed when the game component is removed.

## Important limitations
- This remains the Run 20 vector-placeholder scaffold; it does not load the ASTRALIS sprite frames or individual enemy artwork.
- Ordinary enemies currently share a basic aimed-shot behavior; distinct goblin, harpy, wyvern attack patterns and richer formation choreography remain future work.
- The game structure remains a fixed-screen, Galaga-style fantasy dragon shooter; no spacecraft or 3D models are introduced.
- This patch has not been run through `dart format`, `flutter analyze`, Flutter tests, Android build, or device testing in the generation environment. Run those checks in Codespaces after comparing and integrating the files.

## Safe integration
1. Keep the existing Git checkpoint and safety backup.
2. Inspect the ZIP contents before extraction.
3. Compare each included file with the live project.
4. Copy only files that are appropriate for the live baseline.
5. Run `flutter pub get`, `dart format lib test`, `flutter analyze`, and `flutter test`. Fix any reported issues before building or testing on Android.
