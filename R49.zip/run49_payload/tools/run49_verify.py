#!/usr/bin/env python3
"""Static integration guard for the Run 49 story, boss, UI and marker fixes."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
game = (root / 'lib/game/dragon_lunaryvell_game.dart').read_text()
shell = (root / 'lib/ui/dragon_shell.dart').read_text()
story = (root / 'lib/game/run47_cinematic_story.dart').read_text()
fx = (root / 'lib/game/boss_encounter_fx.dart').read_text()
rules = (root / 'lib/game/boss_encounter_rules.dart').read_text()
widget = (root / 'test/widget_test.dart').read_text()
test = (root / 'test/run49_campaign_boss_premium_test.dart').read_text()

for token in (
    'THE FALLING CITADELS', 'THE ECLIPSE WAR',
    'THE FALLING SPIRES', 'THE ASHEN FRONT', 'THE FALSE NIGHT',
    'THE FROZEN REFUGE', 'THE LAST CITADEL',
    'ASTRALIS', 'TEMPESTRYX', 'IGNIVAR',
    'NYXARIEL', 'SOLARION', 'AQUARYTH',
    'ECLIPSE SOVEREIGN', 'static const bossPreludes',
):
    assert token in story, f'New campaign content missing: {token}'

for old in ('Hollow Choir', 'The Sky Ledger', 'THE SIXTH VOW',
            'The Shattered Moonheart', 'SEVENTH SONG'):
    assert old.lower() not in story.lower(), f'Old story still present: {old}'
    assert old.lower() not in shell.lower(), f'Old story UI still present: {old}'
    assert old.lower() not in rules.lower(), f'Old boss lore still present: {old}'

for token in ('_StoryFiligreePainter', 'RadialGradient(',
              'DRAGON LUNARYVELL', 'THE ECLIPSE WAR',
              'PROLOGUE · THE FALLING CITADELS',
              'SKIP SCENE', 'TAKE FLIGHT', 'Run47Audio.instance.speak('):
    assert token in shell or token in story, token
assert "find.text('THE FALLING CITADELS')" in widget
assert "find.text('SKIP SCENE')" in widget
assert "find.text('NEXT')" in widget

# These were the three visual defects observed directly in the shipped
# draw-player section. Keep the shield collision and HUD charge display.
player_draw = game.split('final path = Path()', 1)[1].split(
    'if (_waveBannerRemaining > 0', 1)[0]
assert 'canvas.drawCircle(Offset(_playerX' not in player_draw
assert 'canvas.drawArc(Rect.fromCircle(center: Offset(_playerX' not in player_draw
assert '_shieldCharges > 0' not in player_draw
assert '_shieldCharges--' in game
assert 'shields: _shieldCharges' in game
assert 'SHIELD' in shell

for token in ('BossEncounterFx.drawArena(',
              'BossEncounterFx.drawVictory(',
              'CITADEL ANCHOR SECURED',
              'BOSS ENCOUNTER',
              '_bossVictoryPending = true;',
              'if (_bossVictoryPending)',
              'BossEncounterFx.drawCharge(',
              'BossEncounterFx.drawStatus('):
    assert token in game, f'Boss integration missing: {token}'
for token in ('static void drawArena(', 'static void drawVictory(',
              'const top = 94.0;', 'final width = battlefieldWidth * .80;'):
    assert token in fx, f'Boss presentation missing: {token}'
for token in ('FURNACE COLLAPSE', 'SIGNAL STORM',
              'BLIZZARD WALL', 'ECLIPSE COLLAPSE'):
    assert token in rules, token
assert "test('all five cinematic bosses use readable" in test

print('RUN49_STATIC_QA_PASS — new five-act story, premium cinematic UI, '
      'boss encounter staging and player marker removal connected')
