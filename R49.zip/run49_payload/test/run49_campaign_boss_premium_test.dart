import 'package:dragon_lunaryvell/game/boss_encounter_rules.dart';
import 'package:dragon_lunaryvell/game/run47_cinematic_story.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('the Eclipse War has five acts, twenty-five missions and six heroes', () {
    const heroes = <String>{
      'ASTRALIS', 'TEMPESTRYX', 'IGNIVAR',
      'NYXARIEL', 'SOLARION', 'AQUARYTH',
    };
    expect(Run47Story.chapterNames.length, 5);
    expect(Run47Story.waveNames.length, 25);
    expect(Run47Story.waveNames.toSet().length, 25);
    expect(Run47Story.openingSequence.length, 5);
    expect(Run47Story.ending.length, 3);
    final script = <StoryBeat>[
      ...Run47Story.opening,
      ...Run47Story.ending,
      for (final chapter in Run47Story.chapters) ...chapter,
      for (final encounter in Run47Story.bossPreludes) ...encounter,
    ];
    for (final dragon in heroes) {
      expect(script.any((beat) => beat.speaker == dragon), isTrue,
          reason: '$dragon must have a speaking role');
    }
    for (final beat in script) {
      expect(beat.line.length, inInclusiveRange(35, 135));
      expect(beat.heading, isNotEmpty);
      expect(beat.art, startsWith('assets/images/run47/story/'));
      expect(beat.line.toLowerCase(), isNot(contains('hollow choir')));
      expect(beat.line.toLowerCase(), isNot(contains('moonheart')));
      expect(beat.line.toLowerCase(), isNot(contains('seventh song')));
    }
  });

  test('each boss warning matches the fifth-wave game pause timing', () {
    for (var chapter = 0; chapter < 5; chapter++) {
      final firstWave = chapter * 5 + 1;
      final bossWave = firstWave + 4;
      expect(Run47Story.forWave(firstWave), isNotEmpty);
      expect(Run47Story.forWave(bossWave).length, 2);
      expect(Run47Story.forWave(bossWave).first.heading,
          contains(chapter == 4 ? 'FINAL BOSS' : 'BOSS'));
      expect(Run47Story.forWave(firstWave + 1), isEmpty);
    }
    expect(Run47Story.forWave(25, completed: true), Run47Story.ending);
  });

  test('all five cinematic bosses use readable, bounded danger lanes', () {
    for (final wave in <int>[5, 10, 15, 20, 25]) {
      for (final phase in BossCombatPhase.values) {
        final warning = BossEncounterRules.warningSeconds(wave, phase);
        expect(warning, greaterThanOrEqualTo(.38));
        expect(BossEncounterRules.attackInterval(wave, phase),
            greaterThanOrEqualTo(.74));
        expect(BossEncounterRules.signatureForWave(wave, phase), isNotEmpty);
        for (var volley = 0; volley < 6; volley++) {
          final shots = BossEncounterRules.volley(
            wave: wave,
            phase: phase,
            originX: 180,
            originY: 145,
            targetX: 150,
            targetY: 620,
            volleyIndex: volley,
          );
          expect(shots.length, inInclusiveRange(3, 7));
          for (final shot in shots) {
            expect(shot.vy, greaterThan(0));
            expect(shot.vx.abs(), lessThan(250));
          }
        }
      }
    }
  });
}
