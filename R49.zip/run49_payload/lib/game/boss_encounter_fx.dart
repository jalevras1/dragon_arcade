import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'boss_encounter_rules.dart';

/// Chapter-specific ritual geometry layered over the animated boss art.
/// Bounded paths, no blur filters, no strobe, no allocations of image textures.
class BossEncounterFx {
  static const hues = <Color>[
    Color(0xFF8DDFFF),
    Color(0xFFFF9A69),
    Color(0xFFCEABFF),
    Color(0xFF90EBEF),
    Color(0xFFFFD37A),
  ];

  static Color hue(int wave) =>
      hues[BossEncounterRules.chapterForWave(wave)];

  /// Painted 2D arena framing during encounters. Designed to sit behind
  /// creatures and projectiles: the central dodge lanes remain unobstructed.
  /// No particle lists, image loads, blur or strobing are required.
  static void drawArena(Canvas canvas, Size field, {
    required int wave,
    required double seconds,
    required BossCombatPhase phase,
    required double phasePulse,
  }) {
    final tint = hue(wave);
    final strength = .22 + phase.index * .065;
    final inset = 8.0 + math.sin(seconds * .95) * 1.8;
    for (final side in <double>[-1, 1]) {
      final x = side < 0 ? inset : field.width - inset;
      final y0 = field.height * .23;
      final y1 = field.height * .74;
      final rail = Paint()
        ..color = tint.withValues(alpha: strength)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2;
      canvas.drawLine(Offset(x, y0), Offset(x, y1), rail);
      for (var i = 0; i < 6; i++) {
        final y = y0 + (y1 - y0) * (i + .5) / 6;
        final inward = side < 0 ? 1.0 : -1.0;
        final mark = Path()
          ..moveTo(x, y - 8)
          ..lineTo(x + inward * 4, y)
          ..lineTo(x, y + 8);
        canvas.drawPath(mark, Paint()
          ..color = tint.withValues(alpha: strength * .9)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.05);
      }
    }
    // A brief, quiet edge pulse marks a phase shift. It cannot conceal a
    // bullet or be mistaken for a damaging collision zone.
    if (phasePulse > 0) {
      final bloom = (phasePulse * .12).clamp(0.0, .12).toDouble();
      final edge = Paint()..shader = ui.Gradient.linear(
        Offset.zero, Offset(field.width, 0), [
          tint.withValues(alpha: bloom),
          tint.withValues(alpha: 0),
          tint.withValues(alpha: bloom),
        ], [0, .5, 1]);
      canvas.drawRect(Offset.zero & field, edge);
    }
  }

  /// A short boss-defeat release, bounded to 12 strokes. The next act waits
  /// until the player has actually seen the victory and recovered anchor.
  static void drawVictory(Canvas canvas, Offset center, {
    required int wave,
    required double progress,
  }) {
    final t = progress.clamp(0.0, 1.0).toDouble();
    final fade = (1 - t).clamp(0.0, 1.0).toDouble();
    final tint = hue(wave);
    final radius = 22 + t * 116;
    canvas.drawCircle(center, radius,
        Paint()..color = tint.withValues(alpha: fade * .61)
          ..style = PaintingStyle.stroke..strokeWidth = 2.4 * fade + .7);
    canvas.drawCircle(center, radius * .58,
        Paint()..color = const Color(0xFFFFEAC7).withValues(alpha: fade * .36)
          ..style = PaintingStyle.stroke..strokeWidth = 1.2);
    for (var i = 0; i < 12; i++) {
      final angle = i * math.pi / 6 + t * .23;
      final inner = radius * .44;
      final outer = radius * (.79 + (i.isEven ? .15 : 0));
      canvas.drawLine(
          Offset(center.dx + math.cos(angle) * inner,
              center.dy + math.sin(angle) * inner),
          Offset(center.dx + math.cos(angle) * outer,
              center.dy + math.sin(angle) * outer),
          Paint()..color = tint.withValues(alpha: fade * .67)
            ..strokeCap = StrokeCap.round..strokeWidth = 1.65);
    }
  }

  static void drawAura(Canvas canvas, Offset center, {
    required int wave,
    required double seconds,
    required BossCombatPhase phase,
    required double shieldFraction,
    required double hitPulse,
    required double phasePulse,
  }) {
    final tint = hue(wave);
    final chapter = BossEncounterRules.chapterForWave(wave);
    final ringRadius = 56.0 + math.sin(seconds * 2) * 2.2;
    // A concentric seal provides a premium sense of depth and scale without
    // putting a giant opaque effect over the actual combat projectiles.
    canvas.drawOval(
        Rect.fromCenter(center: center + const Offset(0, 28),
            width: 134, height: 43),
        Paint()..color = tint.withValues(alpha: .09)
          ..style = PaintingStyle.stroke..strokeWidth = 2.4);
    canvas.drawCircle(
        center,
        82,
        Paint()
          ..shader = ui.Gradient.radial(center, 82, [
            tint.withValues(alpha: .17 + phasePulse * .13),
            tint.withValues(alpha: 0),
          ]));
    // Gold binding ring: fractures at the exact moment an overshield breaks.
    for (var i = 0; i < 8; i++) {
      final a = seconds * .13 + i * math.pi / 4;
      canvas.drawArc(Rect.fromCircle(center: center, radius: 73),
          a, .41, false,
          Paint()..color = const Color(0xFFFFE0A2).withValues(
              alpha: (shieldFraction > 0 ? .30 : .11) + phasePulse * .22)
            ..style = PaintingStyle.stroke..strokeWidth = 1.2);
    }
    final arcs = phase == BossCombatPhase.unleashed ? 3 : 2;
    for (var i = 0; i < arcs; i++) {
      canvas.drawArc(
          Rect.fromCircle(center: center, radius: ringRadius + i * 5),
          seconds * (i.isEven ? .62 : -.48) + i * 2.1,
          1.05 + phase.index * .12,
          false,
          Paint()
            ..color = tint.withValues(alpha: .35 + phasePulse * .27)
            ..strokeWidth = 1.45
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke);
    }
    // The five chapters retain distinct ornaments even with fallback art.
    final count = <int>[4, 6, 5, 6, 7][chapter];
    for (var i = 0; i < count; i++) {
      final angle = seconds * (chapter == 3 ? -.17 : .21) +
          2 * math.pi * i / count;
      final orbit = 64 + math.sin(seconds * 1.8 + i * 1.9) * 1.8;
      final p = Offset(center.dx + math.cos(angle) * orbit,
          center.dy + math.sin(angle) * orbit * .75);
      final sparkle = 2.2 + (phase.index == 2 ? .6 : 0);
      final rune = Path()
        ..moveTo(p.dx, p.dy - sparkle * 1.5)
        ..lineTo(p.dx + sparkle, p.dy)
        ..lineTo(p.dx, p.dy + sparkle * 1.5)
        ..lineTo(p.dx - sparkle, p.dy)
        ..close();
      canvas.drawPath(rune,
          Paint()..color = tint.withValues(alpha: .52));
    }
    if (shieldFraction > 0) {
      canvas.drawCircle(center, 49,
          Paint()..color = tint.withValues(alpha: .075 * shieldFraction));
      canvas.drawArc(
          Rect.fromCircle(center: center, radius: 47),
          -math.pi / 2,
          2 * math.pi * shieldFraction,
          false,
          Paint()
            ..color = tint.withValues(alpha: .48)
            ..strokeWidth = 2.2
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke);
      // Ritual segments break away naturally as the shield is drained.
      final petals = (shieldFraction * 8).ceil();
      for (var i = 0; i < petals; i++) {
        final angle = i * math.pi / 4 - math.pi / 2;
        final seal = Offset(center.dx + math.cos(angle) * 51,
            center.dy + math.sin(angle) * 51);
        canvas.drawCircle(seal, 2.4,
            Paint()..color = const Color(0xFFFFE6B7).withValues(alpha: .8));
      }
    }
    if (hitPulse > 0 || phasePulse > 0) {
      final energy = math.max(hitPulse, phasePulse * .55);
      canvas.drawCircle(
          center,
          42 + (1 - energy) * 18,
          Paint()
            ..color = tint.withValues(alpha: energy * .42)
            ..strokeWidth = 1.8
            ..style = PaintingStyle.stroke);
    }
    // Every boss inherits a DIFFERENT visible magical grammar.
    for (var i = 0; i < 4; i++) {
      final angle = seconds * (chapter.isEven ? .21 : -.17) +
          i * math.pi / 2;
      final runeCenter = Offset(center.dx + math.cos(angle) * 80,
          center.dy + math.sin(angle) * 68);
      final symbol = Path();
      switch (chapter) {
        case 0: // Crystal Warden: razor diamond.
          symbol..moveTo(runeCenter.dx, runeCenter.dy - 8)
            ..lineTo(runeCenter.dx + 5, runeCenter.dy)
            ..lineTo(runeCenter.dx, runeCenter.dy + 8)
            ..lineTo(runeCenter.dx - 5, runeCenter.dy)..close();
          break;
        case 1: // Ash Drake: rising flame claw.
          symbol..moveTo(runeCenter.dx - 5, runeCenter.dy + 7)
            ..quadraticBezierTo(runeCenter.dx - 8, runeCenter.dy - 3,
                runeCenter.dx + 3, runeCenter.dy - 8)
            ..quadraticBezierTo(runeCenter.dx + 9, runeCenter.dy + 3,
                runeCenter.dx - 5, runeCenter.dy + 7);
          break;
        case 2: // Moonveil: double-moon sliver.
          symbol..moveTo(runeCenter.dx + 5, runeCenter.dy - 8)
            ..quadraticBezierTo(runeCenter.dx - 9, runeCenter.dy,
                runeCenter.dx + 5, runeCenter.dy + 8)
            ..quadraticBezierTo(runeCenter.dx - 2, runeCenter.dy,
                runeCenter.dx + 5, runeCenter.dy - 8);
          break;
        case 3: // Frost Matriarch: six-arm ice rune.
          for (var arm = 0; arm < 6; arm++) {
            final a = arm * math.pi / 3;
            symbol..moveTo(runeCenter.dx, runeCenter.dy)
              ..lineTo(runeCenter.dx + math.cos(a) * 9,
                  runeCenter.dy + math.sin(a) * 9);
          }
          break;
        default: // Sovereign: eclipsed star.
          for (var point = 0; point < 8; point++) {
            final a = point * math.pi / 4;
            final r = point.isEven ? 9.0 : 3.0;
            final x = runeCenter.dx + math.cos(a) * r;
            final y = runeCenter.dy + math.sin(a) * r;
            if (point == 0) { symbol.moveTo(x, y); }
            else { symbol.lineTo(x, y); }
          }
          symbol.close();
      }
      canvas.drawPath(symbol,
          Paint()..color = tint.withValues(alpha: .70)
            ..style = PaintingStyle.stroke..strokeWidth = 1.65);
    }
  }

  static void drawCharge(Canvas canvas, Offset bossCenter,
      List<BossShotVector> shots, double chargeProgress, int wave,
      double seconds) {
    if (shots.isEmpty) return;
    final tint = hue(wave);
    final reveal = chargeProgress.clamp(0.0, 1.0).toDouble();
    final pulse = (.58 + .19 * math.sin(seconds * 17)) * reveal;
    final origin = Offset(bossCenter.dx, bossCenter.dy + 37);
    for (final shot in shots) {
      final vx = shot.vx;
      final vy = shot.vy;
      final length = math.max(1.0, math.sqrt(vx * vx + vy * vy));
      final from = Offset(origin.dx + shot.sourceDx, origin.dy);
      final travel = 72 + reveal * 82;
      final to = Offset(from.dx + vx / length * travel,
          from.dy + vy / length * travel);
      canvas.drawLine(
          from,
          to,
          Paint()
            ..color = tint.withValues(alpha: pulse * .21)
            ..strokeWidth = 5.6
            ..strokeCap = StrokeCap.round);
      canvas.drawLine(from, to,
          Paint()..color = const Color(0xFFFFF0CD).withValues(alpha: pulse * .62)
            ..strokeWidth = 1.1..strokeCap = StrokeCap.round);
      canvas.drawCircle(to, 2.2,
          Paint()..color = tint.withValues(alpha: pulse * .75));
      canvas.drawArc(Rect.fromCircle(center: to, radius: 6.5),
          seconds * .9, math.pi * 1.4, false,
          Paint()..color = tint.withValues(alpha: pulse * .44)
            ..style = PaintingStyle.stroke..strokeWidth = 1.1);
    }
    canvas.drawCircle(
        origin,
        10 + reveal * 7,
        Paint()
          ..color = tint.withValues(alpha: .45 * reveal)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.7);
    canvas.drawCircle(origin, 3.5 + reveal * 2,
        Paint()..color = Colors.white.withValues(alpha: .60 * reveal));
  }

  /// A small reusable ceremonial title card: entry, phase transition, reward.
  static void drawCallout(Canvas canvas, {
    required double width,
    required double y,
    required String name,
    required String subtitle,
    required Color tint,
    required double opacity,
  }) {
    final a = opacity.clamp(0.0, 1.0).toDouble();
    if (a <= 0) return;
    final field = Rect.fromCenter(center: Offset(width / 2, y),
        width: width * .81, height: 61);
    final outer = RRect.fromRectAndRadius(field, const Radius.circular(12));
    canvas.drawRRect(outer,
        Paint()..shader = ui.Gradient.linear(field.topLeft, field.bottomRight,
            [const Color(0xF0191833).withValues(alpha: a * .90),
             const Color(0xEC101D35).withValues(alpha: a * .89)]));
    canvas.drawRRect(outer,
        Paint()..color = tint.withValues(alpha: a * .52)
          ..style = PaintingStyle.stroke..strokeWidth = 1.25);
    for (final side in <double>[-1, 1]) {
      final x = width / 2 + side * field.width * .41;
      final p = Path()..moveTo(x, y - 5)
        ..lineTo(x + side * 5, y)
        ..lineTo(x, y + 5)
        ..lineTo(x - side * 5, y)..close();
      canvas.drawPath(p, Paint()..color = tint.withValues(alpha: a * .85));
    }
    final headline = TextPainter(
        text: TextSpan(text: name,
            style: TextStyle(color: const Color(0xFFFFE9C2)
                .withValues(alpha: a), fontSize: 15,
                fontWeight: FontWeight.w800, letterSpacing: 1.4)),
        maxLines: 1, ellipsis: '…',
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: field.width - 28);
    headline.paint(canvas, Offset((width - headline.width) / 2, y - 19));
    final detail = TextPainter(
        text: TextSpan(text: subtitle,
            style: TextStyle(color: tint.withValues(alpha: a * .88),
                fontSize: 9, fontWeight: FontWeight.w600, letterSpacing: 1.05)),
        maxLines: 1, ellipsis: '…',
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: field.width - 25);
    detail.paint(canvas, Offset((width - detail.width) / 2, y + 3));
  }

  static void drawStatus(Canvas canvas, {
    required double battlefieldWidth,
    required String bossName,
    required int wave,
    required BossCombatPhase phase,
    required double health,
    required double maxHealth,
    required double shield,
    required double maxShield,
  }) {
    final hue = BossEncounterFx.hue(wave);
    // A readable boss-specific raid plate sits BELOW the existing score,
    // wave and hull HUD, instead of hiding a seven-pixel bar behind it.
    final width = battlefieldWidth * .80;
    final left = battlefieldWidth * .10;
    const top = 94.0;
    final plate = Rect.fromLTWH(left - 9, top - 8, width + 18, 67);
    canvas.drawRRect(
        RRect.fromRectAndRadius(plate, const Radius.circular(10)),
        Paint()..shader = ui.Gradient.linear(plate.topLeft,
            plate.bottomRight, [const Color(0xE90C1229),
              const Color(0xE9182440)]));
    canvas.drawRRect(
        RRect.fromRectAndRadius(plate, const Radius.circular(10)),
        Paint()..color = hue.withValues(alpha: .65)
          ..style = PaintingStyle.stroke..strokeWidth = 1.05);
    for (final side in <double>[-1, 1]) {
      final x = battlefieldWidth / 2 + side * (width * .45);
      final diamond = Path()..moveTo(x, top - 3)
        ..lineTo(x + 4, top + 1)
        ..lineTo(x, top + 5)
        ..lineTo(x - 4, top + 1)..close();
      canvas.drawPath(diamond, Paint()
          ..color = hue.withValues(alpha: .66));
    }
    final name = TextPainter(
        text: TextSpan(
            text: bossName,
            style: TextStyle(
                color: hue.withValues(alpha: .9),
                fontSize: 11.4,
                letterSpacing: 1.35,
                fontWeight: FontWeight.w900)),
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: battlefieldWidth * .90);
    name.paint(canvas, Offset((battlefieldWidth - name.width) / 2, top));

    final bar = RRect.fromRectAndRadius(
        Rect.fromLTWH(left, top + 22, width, 10),
        const Radius.circular(5));
    canvas.drawRRect(bar, Paint()..color = const Color(0xE9121A31));
    final healthRatio = (health / math.max(1, maxHealth)).clamp(0.0, 1.0)
        .toDouble();
    if (healthRatio > 0) {
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(left, top + 22, width * healthRatio, 10),
              const Radius.circular(5)),
          Paint()
            ..shader = ui.Gradient.linear(
              Offset(left, top + 22), Offset(left + width, top + 22),
              [hue.withValues(alpha: .94), const Color(0xFFFFE8B0)],
            ));
    }
    // Permanently visible phase ticks teach players the boss's thresholds.
    for (final fraction in <double>[.30, .65]) {
      final x = left + width * fraction;
      canvas.drawLine(Offset(x, top + 22), Offset(x, top + 32),
          Paint()..color = const Color(0xE5121A31)..strokeWidth = 1.8);
    }
    if (maxShield > 0) {
      final percent = (shield / maxShield).clamp(0.0, 1.0).toDouble();
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(left, top + 17, width, 3.3),
              const Radius.circular(3)),
          Paint()..color = const Color(0xCC121A31));
      if (percent > 0) {
        canvas.drawRRect(
            RRect.fromRectAndRadius(
                Rect.fromLTWH(left, top + 17, width * percent, 3.3),
                const Radius.circular(3)),
            Paint()..color = hue.withValues(alpha: .85));
      }
    }
    final label = TextPainter(
        text: TextSpan(
            text: '${BossEncounterRules.phaseName(phase)} · '
                '${BossEncounterRules.signatureForWave(wave, phase)}',
            style: TextStyle(
                color: hue.withValues(alpha: .68),
                fontSize: 8.0,
                letterSpacing: 1.15,
                fontWeight: FontWeight.w600)),
        maxLines: 1, ellipsis: '…',
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: battlefieldWidth * .76);
    label.paint(canvas, Offset((battlefieldWidth - label.width) / 2,
        top + 37));
  }
}
