/// DRAGON LUNARYVELL: THE ECLIPSE WAR.
///
/// Five sky citadels, one ruthless sovereign, and six dragons who refuse to
/// abandon the people beneath them. These short, voiced beats are pure data.
/// The previous abstract Moonheart/Choir mythology is intentionally replaced.
class StoryBeat {
  const StoryBeat(this.speaker, this.line, this.art,
      {required this.heading, this.emotion = 'resolve'});

  final String speaker, line, art, heading, emotion;
}

class Run47Story {
  static const _art = 'assets/images/run47/story/';

  static const chapterNames = <String>[
    'THE FALLING SPIRES',
    'THE ASHEN FRONT',
    'THE FALSE NIGHT',
    'THE FROZEN REFUGE',
    'THE LAST CITADEL',
  ];

  /// A fast, high-stakes opening; players can always skip straight to combat.
  static const opening = <StoryBeat>[
    StoryBeat('ASTRALIS',
        'The western sky citadel fell before dawn. We pulled survivors from the clouds. Four cities are next.',
        '${_art}prologue.jpg',
        heading: 'PROLOGUE · THE FALLING CITADELS',
        emotion: 'warning'),
    StoryBeat('TEMPESTRYX',
        'The Eclipse Sovereign turned our own guardians against us. Every city anchor is under attack.',
        '${_art}prologue.jpg',
        heading: 'THE ENEMY AT OUR GATES',
        emotion: 'anger'),
    StoryBeat('NYXARIEL',
        'He wants us afraid enough to run. Let him wait. We take back the first citadel tonight.',
        '${_art}prologue.jpg',
        heading: 'SIX DRAGONS. NO SURRENDER.',
        emotion: 'resolve'),
  ];

  /// Two focused opening exchanges per chapter; no lore dump or filler.
  static const chapters = <List<StoryBeat>>[
    <StoryBeat>[
      StoryBeat('ASTRALIS',
          'The Crystal Warden sealed the city gates with families still inside. Break his sentries. Open the way.',
          '${_art}shattered_spires.jpg',
          heading: 'ACT I · THE FALLING SPIRES',
          emotion: 'warning'),
      StoryBeat('TEMPESTRYX',
          'His armor was made to protect these people. If he will not stand down, we make him.',
          '${_art}shattered_spires.jpg',
          heading: 'MISSION · BREAK THE BLOCKADE',
          emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('IGNIVAR',
          'The Ashen Colossus has chained the forge towers together. One broken link could bring the city down.',
          '${_art}ashen_oath.jpg',
          heading: 'ACT II · THE ASHEN FRONT',
          emotion: 'warning'),
      StoryBeat('AQUARYTH',
          'There is a river beneath the furnaces. I can cool the chains. You find the one controlling them.',
          '${_art}ashen_oath.jpg',
          heading: 'MISSION · FREE THE FORGE',
          emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('NYXARIEL',
          'The serpent is sending false orders in our voices. The sentries cannot tell friend from enemy.',
          '${_art}veil_between.jpg',
          heading: 'ACT III · THE FALSE NIGHT',
          emotion: 'warning'),
      StoryBeat('SOLARION',
          'Then we stop chasing shadows. Find the source. I will burn a path through the lies.',
          '${_art}veil_between.jpg',
          heading: 'MISSION · SILENCE THE SIGNAL',
          emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('AQUARYTH',
          'The Frost Matriarch sealed thousands of refugees in ice. She calls it protection. They cannot survive it.',
          '${_art}frost_memory.jpg',
          heading: 'ACT IV · THE FROZEN REFUGE',
          emotion: 'warning'),
      StoryBeat('TEMPESTRYX',
          'We cannot shatter the sanctuary. Strike only her guard lines. Aquaryth will handle the thaw.',
          '${_art}frost_memory.jpg',
          heading: 'MISSION · OPEN THE SANCTUARY',
          emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('SOLARION',
          'The Sovereign stole the anchors to save one city by abandoning the others. He calls it necessary.',
          '${_art}last_eclipse.jpg',
          heading: 'ACT V · THE LAST CITADEL',
          emotion: 'warning'),
      StoryBeat('ASTRALIS',
          'We recovered four anchors. Together, they can hold the sky. We will not choose who gets to live.',
          '${_art}last_eclipse.jpg',
          heading: 'MISSION · END THE ECLIPSE',
          emotion: 'resolve'),
    ],
  ];

  /// Two beats immediately BEFORE each fifth-wave boss. Game advance
  /// pauses at waves 5/10/15/20; wave 25 ends in the epilogue.
  static const bossPreludes = <List<StoryBeat>>[
    <StoryBeat>[
      StoryBeat('ECLIPSE GARGOYLE WARDEN',
          'I know there are families behind the gates. My orders are to let nobody through. Turn back.',
          '${_art}shattered_spires.jpg',
          heading: 'BOSS · ECLIPSE GARGOYLE WARDEN',
          emotion: 'warning'),
      StoryBeat('ASTRALIS',
          'Those families do not have time for your orders. Move aside, or we break through.',
          '${_art}shattered_spires.jpg',
          heading: 'OBJECTIVE · OPEN THE GATES',
          emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('ASHEN DRAKE COLOSSUS',
          'I was built to hold the forge together. If I release one chain, thousands will fall.',
          '${_art}ashen_oath.jpg',
          heading: 'BOSS · ASHEN DRAKE COLOSSUS',
          emotion: 'warning'),
      StoryBeat('IGNIVAR',
          'Then trust us. I will break the chains. Aquaryth will keep the towers standing.',
          '${_art}ashen_oath.jpg',
          heading: 'OBJECTIVE · BREAK THE CHAINS',
          emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('THE MOONVEIL SERPENT',
          'Your allies are already taking orders in your voices. Which one of you will they shoot first?',
          '${_art}veil_between.jpg',
          heading: 'BOSS · THE MOONVEIL SERPENT',
          emotion: 'warning'),
      StoryBeat('NYXARIEL',
          'You can steal a voice. You cannot steal trust. We will tear down your signal tower.',
          '${_art}veil_between.jpg',
          heading: 'OBJECTIVE · END THE DECEPTION',
          emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('FROST HARPY MATRIARCH',
          'The ice is the only thing keeping them safe. I will freeze the sky before I let you touch it.',
          '${_art}frost_memory.jpg',
          heading: 'BOSS · FROST HARPY MATRIARCH',
          emotion: 'warning'),
      StoryBeat('AQUARYTH',
          'Safe is not the same as alive. Let me bring the water back without hurting your people.',
          '${_art}frost_memory.jpg',
          heading: 'OBJECTIVE · SAVE THE REFUGEES',
          emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('ECLIPSE SOVEREIGN',
          'Five cities cannot survive this eclipse. I chose to save one. You will not make me lose them all.',
          '${_art}last_eclipse.jpg',
          heading: 'FINAL BOSS · THE ECLIPSE SOVEREIGN',
          emotion: 'warning'),
      StoryBeat('THE SIX DRAGONS',
          'You do not get to sacrifice four cities for your fear. We brought every anchor. Stand down.',
          '${_art}last_eclipse.jpg',
          heading: 'OBJECTIVE · BREAK THE ECLIPSE',
          emotion: 'resolve'),
    ],
  ];

  static const ending = <StoryBeat>[
    StoryBeat('THE ECLIPSE SOVEREIGN',
        'I saw the end coming and chose who would survive. You fought for another way. I was wrong.',
        '${_art}last_eclipse.jpg',
        heading: 'EPILOGUE · THE ECLIPSE ENDS',
        emotion: 'warning'),
    StoryBeat('SOLARION',
        'All five anchors are joined. The citadels are holding. Listen—the evacuation bells have stopped.',
        '${_art}last_eclipse.jpg',
        heading: 'A SKY WORTH SAVING',
        emotion: 'resolve'),
    StoryBeat('ASTRALIS',
        'Tomorrow, we rebuild. Tonight, we fly home. Every city is still here to see the dawn.',
        '${_art}prologue.jpg',
        heading: 'DRAGON LUNARYVELL · THE FIRST DAWN',
        emotion: 'resolve'),
  ];

  /// Chapter openings play before waves 1/6/11/16/21; boss introductions
  /// play before waves 5/10/15/20 (wave 25 ends in the epilogue).
  static List<StoryBeat> forWave(int wave, {bool completed = false}) {
    if (completed) return ending;
    if (wave < 1 || wave > 25) return const <StoryBeat>[];
    final chapter = (wave - 1) ~/ 5;
    if (wave % 5 == 0) return bossPreludes[chapter];
    if ((wave - 1) % 5 == 0) return chapters[chapter];
    return const <StoryBeat>[];
  }

  static List<StoryBeat> get openingSequence => <StoryBeat>[
        ...opening,
        ...chapters[0],
      ];

  static const waveNames = <String>[
    'THE LAST EVACUATION', 'SENTINELS ON THE BRIDGE',
    'THE FALLING GATE', 'THE SHATTERED WATCH', 'WARDEN OF THE SPIRES',
    'CITY OF ASH', 'THE CHAIN FIELDS', 'FIRE BELOW',
    'BREAK THE FURNACE', 'THE COLOSSUS\' LAST STAND',
    'FALSE SIGNAL', 'THE MIRROR LEGION', 'SHADOWS AT OUR BACK',
    'THE SERPENT\'S MAZE', 'THE HIDDEN SIGNAL',
    'THE FROZEN REFUGE', 'THE ICEBOUND GUARD', 'THE WHITEOUT',
    'THE FINAL THAW', 'THE MATRIARCH\'S VERDICT',
    'GATE OF ECLIPSE', 'THE FALLING STARS', 'BREAK THE CROWN',
    'THE SOVEREIGN\'S CHOICE', 'THE LAST CITADEL',
  ];

  static String waveName(int wave) => wave >= 1 && wave <= waveNames.length
      ? waveNames[wave - 1] : 'ENDLESS SKIES';
}
