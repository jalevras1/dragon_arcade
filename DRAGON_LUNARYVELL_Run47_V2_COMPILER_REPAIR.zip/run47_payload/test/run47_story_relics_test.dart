import 'dart:math' as math;

import 'package:dragon_lunaryvell/game/run47_cinematic_story.dart';
import 'package:dragon_lunaryvell/game/run47_relic_rules.dart';
import 'package:dragon_lunaryvell/game/boss_encounter_rules.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('each boss has a distinct ritual title for each escalation', () {
    final signatures = <String>{};
    for (final wave in <int>[5, 10, 15, 20, 25]) {
      for (final phase in BossCombatPhase.values) {
        final ritual = BossEncounterRules.signatureForWave(wave, phase);
        expect(ritual.length, greaterThan(8));
        signatures.add(ritual);
      }
    }
    expect(signatures.length, 15);
  });

  test('six dragon mythology spans all five 5-wave acts', () {
    expect(Run47Story.chapterNames.length, 5);
    expect(Run47Story.waveNames.length, 25);
    expect(Run47Story.openingSequence.length, 5);
    expect(Run47Story.ending.length, 3);
    expect(Run47Story.ending[1].line, contains('ELYRA'));
    for (var chapter = 0; chapter < 5; chapter++) {
      final start = 1 + chapter * 5;
      expect(Run47Story.forWave(start), isNotEmpty);
      expect(Run47Story.forWave(start + 4).length, 2);
      for (final scene in <StoryBeat>[
        ...Run47Story.forWave(start),
        ...Run47Story.forWave(start + 4),
      ]) {
        expect(scene.line.length, greaterThan(28));
        expect(scene.heading, isNotEmpty);
        expect(scene.art, startsWith('assets/images/run47/story/'));
      }
    }
    expect(Run47Story.forWave(26), isEmpty);
    expect(Run47Story.forWave(25, completed: true), Run47Story.ending);
  });

  test('ten relics are reachable, bounded and illustrate the inventory', () {
    expect(RelicKind.values.length, 10);
    expect(Run47Relics.labels.length, 10);
    final random = math.Random(9911);
    final observed = <RelicKind>{};
    for (var i = 0; i < 2400; i++) {
      observed.add(Run47Relics.roll(random, 1 + i % 25));
    }
    expect(observed, RelicKind.values.toSet());
    for (final kind in RelicKind.values) {
      expect(Run47Relics.sprite(kind), endsWith('.png'));
      expect(Run47Relics.label(kind), isNotEmpty);
    }
    expect(Run47Relics.maxBolts, lessThan(60));
    expect(Run47Relics.maxPickups, lessThan(8));
    expect(Run47Relics.maxChainTargets, 2);
  });

  test('multi-fire retains one synchronized firing event', () {
    final single = Run47Relics.angles(
        trinity: false, phoenix: false, volleyIndex: 1);
    final trinity = Run47Relics.angles(
        trinity: true, phoenix: false, volleyIndex: 2);
    final wing = Run47Relics.angles(
        trinity: false, phoenix: true, volleyIndex: 4);
    final maximum = Run47Relics.angles(
        trinity: true, phoenix: true, volleyIndex: 4);
    expect(single, <double>[0]);
    expect(trinity, <double>[-.24, 0, .24]);
    expect(wing.length, 3);
    expect(maximum.length, 5);
    expect(maximum, orderedEquals(maximum.reversed.map((x) => -x)));
    expect(Run47Relics.angles(
        trinity: true, phoenix: true, volleyIndex: 3).length, 3);
  });
}
