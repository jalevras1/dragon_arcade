import 'dart:math' as math;

/// One bounded relic language shared by drop weights, player volleys, UI and
/// image/audio assets. Existing haste/critical/shield keep their behavior.
enum RelicKind {
  haste, critical, shield,
  trinity, phoenix, arc, piercer, timeVeil, healing, magnet,
}

class Run47Relics {
  static const assetRoot = 'run47/pickups/';
  static const labels = <String>[
    'WIND DANCE', 'PHOENIX FOCUS', 'AEGIS WARD', 'TRINITY SHOT',
    'PHOENIX WINGS', 'CHAIN LIGHTNING', 'STAR PIERCER',
    'TIME VEIL', 'HEALING BLOOM', 'MOON MAGNET',
  ];
  static const _icons = <String>[
    'time_veil', 'phoenix', 'aegis', 'trinity', 'phoenix',
    'arc', 'piercer', 'time_veil', 'healing', 'magnet',
  ];

  static String label(RelicKind kind) => labels[kind.index];
  static String sprite(RelicKind kind) =>
      '$assetRoot${_icons[kind.index]}.png';

  /// Widen the drop table naturally as the player progresses. Good pickups
  /// are not restricted to deep campaign waves (arcade also gets all eight).
  static RelicKind roll(math.Random random, int wave) {
    final weights = <int>[
      12, 10, 10, 12, 7, wave >= 3 ? 8 : 3,
      wave >= 5 ? 7 : 2, wave >= 6 ? 6 : 2, 9, 7,
    ];
    final total = weights.fold<int>(0, (a, b) => a + b);
    var draw = random.nextInt(total);
    for (var i = 0; i < weights.length; i++) {
      draw -= weights[i];
      if (draw < 0) return RelicKind.values[i];
    }
    return RelicKind.haste;
  }

  /// Symmetric phone-readable dragonfire angles. Phoenix wings add separate
  /// outer bolts every fourth firing beat without flooding a narrow screen.
  static List<double> angles({required bool trinity,
      required bool phoenix, required int volleyIndex}) {
    final result = trinity ? <double>[-.24, 0, .24] : <double>[0];
    if (phoenix && volleyIndex % 4 == 0) {
      result.insert(0, -.46);
      result.add(.46);
    }
    assert(result.length <= 5);
    return result;
  }

  static const maxPickups = 5;
  static const maxBolts = 52;
  static const maxChainTargets = 2;
  static const maxHearts = 5;
  static const spreadSeconds = 11.0;
  static const phoenixSeconds = 13.0;
  static const arcSeconds = 10.0;
  static const pierceSeconds = 9.0;
  static const veilSeconds = 7.0;
  static const magnetSeconds = 12.0;
}
