import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'boss_encounter_rules.dart';

/// Chapter-specific ritual geometry layered over the animated boss art.
/// Bounded paths, no blur filters, no strobe, no allocations of image textures.
class BossEncounterFx {
  static const hues = <Color>[
    Color(0xFF8DDFFF),
    Color(0xFFFF9A69),
    Color(0xFFCEABFF),
    Color(0xFF90EBEF),
    Color(0xFFFFD37A),
  ];

  static Color hue(int wave) =>
      hues[BossEncounterRules.chapterForWave(wave)];

  static void drawAura(Canvas canvas, Offset center, {
    required int wave,
    required double seconds,
    required BossCombatPhase phase,
    required double shieldFraction,
    required double hitPulse,
    required double phasePulse,
  }) {
    final tint = hue(wave);
    final chapter = BossEncounterRules.chapterForWave(wave);
    final ringRadius = 56.0 + math.sin(seconds * 2) * 2.2;
    // A concentric seal provides a premium sense of depth and scale without
    // putting a giant opaque effect over the actual combat projectiles.
    canvas.drawOval(
        Rect.fromCenter(center: center + const Offset(0, 28),
            width: 134, height: 43),
        Paint()..color = tint.withValues(alpha: .09)
          ..style = PaintingStyle.stroke..strokeWidth = 2.4);
    canvas.drawCircle(
        center,
        82,
        Paint()
          ..shader = ui.Gradient.radial(center, 82, [
            tint.withValues(alpha: .17 + phasePulse * .13),
            tint.withValues(alpha: 0),
          ]));
    // Gold binding ring: fractures at the exact moment an overshield breaks.
    for (var i = 0; i < 8; i++) {
      final a = seconds * .13 + i * math.pi / 4;
      canvas.drawArc(Rect.fromCircle(center: center, radius: 73),
          a, .41, false,
          Paint()..color = const Color(0xFFFFE0A2).withValues(
              alpha: (shieldFraction > 0 ? .30 : .11) + phasePulse * .22)
            ..style = PaintingStyle.stroke..strokeWidth = 1.2);
    }
    final arcs = phase == BossCombatPhase.unleashed ? 3 : 2;
    for (var i = 0; i < arcs; i++) {
      canvas.drawArc(
          Rect.fromCircle(center: center, radius: ringRadius + i * 5),
          seconds * (i.isEven ? .62 : -.48) + i * 2.1,
          1.05 + phase.index * .12,
          false,
          Paint()
            ..color = tint.withValues(alpha: .35 + phasePulse * .27)
            ..strokeWidth = 1.45
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke);
    }
    // The five chapters retain distinct ornaments even with fallback art.
    final count = <int>[4, 6, 5, 6, 7][chapter];
    for (var i = 0; i < count; i++) {
      final angle = seconds * (chapter == 3 ? -.17 : .21) +
          2 * math.pi * i / count;
      final orbit = 64 + math.sin(seconds * 1.8 + i * 1.9) * 1.8;
      final p = Offset(center.dx + math.cos(angle) * orbit,
          center.dy + math.sin(angle) * orbit * .75);
      final sparkle = 2.2 + (phase.index == 2 ? .6 : 0);
      final rune = Path()
        ..moveTo(p.dx, p.dy - sparkle * 1.5)
        ..lineTo(p.dx + sparkle, p.dy)
        ..lineTo(p.dx, p.dy + sparkle * 1.5)
        ..lineTo(p.dx - sparkle, p.dy)
        ..close();
      canvas.drawPath(rune,
          Paint()..color = tint.withValues(alpha: .52));
    }
    if (shieldFraction > 0) {
      canvas.drawCircle(center, 49,
          Paint()..color = tint.withValues(alpha: .075 * shieldFraction));
      canvas.drawArc(
          Rect.fromCircle(center: center, radius: 47),
          -math.pi / 2,
          2 * math.pi * shieldFraction,
          false,
          Paint()
            ..color = tint.withValues(alpha: .48)
            ..strokeWidth = 2.2
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke);
      // Ritual segments break away naturally as the shield is drained.
      final petals = (shieldFraction * 8).ceil();
      for (var i = 0; i < petals; i++) {
        final angle = i * math.pi / 4 - math.pi / 2;
        final seal = Offset(center.dx + math.cos(angle) * 51,
            center.dy + math.sin(angle) * 51);
        canvas.drawCircle(seal, 2.4,
            Paint()..color = const Color(0xFFFFE6B7).withValues(alpha: .8));
      }
    }
    if (hitPulse > 0 || phasePulse > 0) {
      final energy = math.max(hitPulse, phasePulse * .55);
      canvas.drawCircle(
          center,
          42 + (1 - energy) * 18,
          Paint()
            ..color = tint.withValues(alpha: energy * .42)
            ..strokeWidth = 1.8
            ..style = PaintingStyle.stroke);
    }
    // Every boss inherits a DIFFERENT visible magical grammar.
    for (var i = 0; i < 4; i++) {
      final angle = seconds * (chapter.isEven ? .21 : -.17) +
          i * math.pi / 2;
      final runeCenter = Offset(center.dx + math.cos(angle) * 80,
          center.dy + math.sin(angle) * 68);
      final symbol = Path();
      switch (chapter) {
        case 0: // Crystal Warden: razor diamond.
          symbol..moveTo(runeCenter.dx, runeCenter.dy - 8)
            ..lineTo(runeCenter.dx + 5, runeCenter.dy)
            ..lineTo(runeCenter.dx, runeCenter.dy + 8)
            ..lineTo(runeCenter.dx - 5, runeCenter.dy)..close();
          break;
        case 1: // Ash Drake: rising flame claw.
          symbol..moveTo(runeCenter.dx - 5, runeCenter.dy + 7)
            ..quadraticBezierTo(runeCenter.dx - 8, runeCenter.dy - 3,
                runeCenter.dx + 3, runeCenter.dy - 8)
            ..quadraticBezierTo(runeCenter.dx + 9, runeCenter.dy + 3,
                runeCenter.dx - 5, runeCenter.dy + 7);
          break;
        case 2: // Moonveil: double-moon sliver.
          symbol..moveTo(runeCenter.dx + 5, runeCenter.dy - 8)
            ..quadraticBezierTo(runeCenter.dx - 9, runeCenter.dy,
                runeCenter.dx + 5, runeCenter.dy + 8)
            ..quadraticBezierTo(runeCenter.dx - 2, runeCenter.dy,
                runeCenter.dx + 5, runeCenter.dy - 8);
          break;
        case 3: // Frost Matriarch: six-arm ice rune.
          for (var arm = 0; arm < 6; arm++) {
            final a = arm * math.pi / 3;
            symbol..moveTo(runeCenter.dx, runeCenter.dy)
              ..lineTo(runeCenter.dx + math.cos(a) * 9,
                  runeCenter.dy + math.sin(a) * 9);
          }
          break;
        default: // Sovereign: eclipsed star.
          for (var point = 0; point < 8; point++) {
            final a = point * math.pi / 4;
            final r = point.isEven ? 9.0 : 3.0;
            final x = runeCenter.dx + math.cos(a) * r;
            final y = runeCenter.dy + math.sin(a) * r;
            if (point == 0) { symbol.moveTo(x, y); }
            else { symbol.lineTo(x, y); }
          }
          symbol.close();
      }
      canvas.drawPath(symbol,
          Paint()..color = tint.withValues(alpha: .70)
            ..style = PaintingStyle.stroke..strokeWidth = 1.65);
    }
  }

  static void drawCharge(Canvas canvas, Offset bossCenter,
      List<BossShotVector> shots, double chargeProgress, int wave,
      double seconds) {
    if (shots.isEmpty) return;
    final tint = hue(wave);
    final reveal = chargeProgress.clamp(0.0, 1.0).toDouble();
    final pulse = (.58 + .19 * math.sin(seconds * 17)) * reveal;
    final origin = Offset(bossCenter.dx, bossCenter.dy + 37);
    for (final shot in shots) {
      final vx = shot.vx;
      final vy = shot.vy;
      final length = math.max(1.0, math.sqrt(vx * vx + vy * vy));
      final from = Offset(origin.dx + shot.sourceDx, origin.dy);
      final travel = 72 + reveal * 82;
      final to = Offset(from.dx + vx / length * travel,
          from.dy + vy / length * travel);
      canvas.drawLine(
          from,
          to,
          Paint()
            ..color = tint.withValues(alpha: pulse * .21)
            ..strokeWidth = 5.6
            ..strokeCap = StrokeCap.round);
      canvas.drawLine(from, to,
          Paint()..color = const Color(0xFFFFF0CD).withValues(alpha: pulse * .62)
            ..strokeWidth = 1.1..strokeCap = StrokeCap.round);
      canvas.drawCircle(to, 2.2,
          Paint()..color = tint.withValues(alpha: pulse * .75));
      canvas.drawArc(Rect.fromCircle(center: to, radius: 6.5),
          seconds * .9, math.pi * 1.4, false,
          Paint()..color = tint.withValues(alpha: pulse * .44)
            ..style = PaintingStyle.stroke..strokeWidth = 1.1);
    }
    canvas.drawCircle(
        origin,
        10 + reveal * 7,
        Paint()
          ..color = tint.withValues(alpha: .45 * reveal)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.7);
    canvas.drawCircle(origin, 3.5 + reveal * 2,
        Paint()..color = Colors.white.withValues(alpha: .60 * reveal));
  }

  /// A small reusable ceremonial title card: entry, phase transition, reward.
  static void drawCallout(Canvas canvas, {
    required double width,
    required double y,
    required String name,
    required String subtitle,
    required Color tint,
    required double opacity,
  }) {
    final a = opacity.clamp(0.0, 1.0).toDouble();
    if (a <= 0) return;
    final field = Rect.fromCenter(center: Offset(width / 2, y),
        width: width * .81, height: 61);
    final outer = RRect.fromRectAndRadius(field, const Radius.circular(12));
    canvas.drawRRect(outer,
        Paint()..shader = ui.Gradient.linear(field.topLeft, field.bottomRight,
            [const Color(0xF0191833).withValues(alpha: a * .90),
             const Color(0xEC101D35).withValues(alpha: a * .89)]));
    canvas.drawRRect(outer,
        Paint()..color = tint.withValues(alpha: a * .52)
          ..style = PaintingStyle.stroke..strokeWidth = 1.25);
    for (final side in <double>[-1, 1]) {
      final x = width / 2 + side * field.width * .41;
      final p = Path()..moveTo(x, y - 5)
        ..lineTo(x + side * 5, y)
        ..lineTo(x, y + 5)
        ..lineTo(x - side * 5, y)..close();
      canvas.drawPath(p, Paint()..color = tint.withValues(alpha: a * .85));
    }
    final headline = TextPainter(
        text: TextSpan(text: name,
            style: TextStyle(color: const Color(0xFFFFE9C2)
                .withValues(alpha: a), fontSize: 15,
                fontWeight: FontWeight.w800, letterSpacing: 1.4)),
        maxLines: 1, ellipsis: '…',
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: field.width - 28);
    headline.paint(canvas, Offset((width - headline.width) / 2, y - 19));
    final detail = TextPainter(
        text: TextSpan(text: subtitle,
            style: TextStyle(color: tint.withValues(alpha: a * .88),
                fontSize: 9, fontWeight: FontWeight.w600, letterSpacing: 1.05)),
        maxLines: 1, ellipsis: '…',
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: field.width - 25);
    detail.paint(canvas, Offset((width - detail.width) / 2, y + 3));
  }

  static void drawStatus(Canvas canvas, {
    required double battlefieldWidth,
    required String bossName,
    required int wave,
    required BossCombatPhase phase,
    required double health,
    required double maxHealth,
    required double shield,
    required double maxShield,
  }) {
    final hue = BossEncounterFx.hue(wave);
    final width = battlefieldWidth * .60;
    final left = battlefieldWidth * .20;
    final name = TextPainter(
        text: TextSpan(
            text: bossName,
            style: TextStyle(
                color: hue.withValues(alpha: .9),
                fontSize: 9.5,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w700)),
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: battlefieldWidth * .90);
    name.paint(canvas, Offset((battlefieldWidth - name.width) / 2, 32));

    final bar = RRect.fromRectAndRadius(
        Rect.fromLTWH(left, 54, width, 7), const Radius.circular(4));
    canvas.drawRRect(bar, Paint()..color = const Color(0xE9121A31));
    final healthRatio = (health / math.max(1, maxHealth)).clamp(0.0, 1.0)
        .toDouble();
    if (healthRatio > 0) {
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(left, 54, width * healthRatio, 7),
              const Radius.circular(4)),
          Paint()
            ..shader = ui.Gradient.linear(
              Offset(left, 54), Offset(left + width, 54),
              [hue.withValues(alpha: .94), const Color(0xFFFFE8B0)],
            ));
    }
    // Permanently visible phase ticks teach players the boss's thresholds.
    for (final fraction in <double>[.30, .65]) {
      final x = left + width * fraction;
      canvas.drawLine(Offset(x, 54), Offset(x, 61),
          Paint()..color = const Color(0xBB121A31)..strokeWidth = 1.3);
    }
    if (maxShield > 0) {
      final percent = (shield / maxShield).clamp(0.0, 1.0).toDouble();
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(left, 47, width, 3.3),
              const Radius.circular(3)),
          Paint()..color = const Color(0xCC121A31));
      if (percent > 0) {
        canvas.drawRRect(
            RRect.fromRectAndRadius(
                Rect.fromLTWH(left, 47, width * percent, 3.3),
                const Radius.circular(3)),
            Paint()..color = hue.withValues(alpha: .85));
      }
    }
    final label = TextPainter(
        text: TextSpan(
            text: '${BossEncounterRules.phaseName(phase)} · '
                '${BossEncounterRules.signatureForWave(wave, phase)}',
            style: TextStyle(
                color: hue.withValues(alpha: .68),
                fontSize: 7.5,
                letterSpacing: 1.45,
                fontWeight: FontWeight.w600)),
        maxLines: 1, ellipsis: '…',
        textDirection: TextDirection.ltr)
      ..layout(maxWidth: battlefieldWidth * .60);
    label.paint(canvas, Offset((battlefieldWidth - label.width) / 2, 65));
  }
}
