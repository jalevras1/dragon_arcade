/// The Sky Ledger: narrative beats are pure data so they remain testable and
/// accessible even when voice playback or illustrated artwork is unavailable.
class StoryBeat {
  const StoryBeat(this.speaker, this.line, this.art,
      {required this.heading, this.emotion = 'whisper'});

  final String speaker, line, art, heading, emotion;
}

class Run47Story {
  static const _art = 'assets/images/run47/story/';
  static const chapterNames = <String>[
    'THE SHATTERED SPIRES',
    'THE ASHEN OATH',
    'THE VEIL BETWEEN',
    'THE FROST MEMORY',
    'THE LAST ECLIPSE',
  ];

  /// The first scene is presented after the player explicitly taps Campaign.
  static const opening = <StoryBeat>[
    StoryBeat('THE SKY LEDGER',
        'Before there were kingdoms, Lunaryvell was a living moon. Its heart kept the names of every soul that had ever loved, fought, or dreamed.',
        '${_art}prologue.jpg', heading: 'PROLOGUE · THE SIXTH VOW'),
    StoryBeat('ASTRALIS',
        'Seven voices once held that heart. The Seventh surrendered her name to seal away the Hollow Choir. We six inherited the pieces of her promise.',
        '${_art}prologue.jpg', heading: 'THE SIX WITNESSES', emotion: 'resolve'),
    StoryBeat('NYXARIEL',
        'Now the Choir sings through stolen memories. Its creatures are not born evil; they are people, guardians and beasts emptied of their true stories.',
        '${_art}prologue.jpg', heading: 'THE HOLLOW CHOIR', emotion: 'warning'),
  ];

  static const chapters = <List<StoryBeat>>[
    <StoryBeat>[
      StoryBeat('ASTRALIS',
          'The moon bells have fallen silent. Every bell that breaks erases one true name from the sky. We start at the spires.',
          '${_art}shattered_spires.jpg', heading: 'ACT I · THE SHATTERED SPIRES'),
      StoryBeat('TEMPESTRYX',
          'I still hear thunder inside the crystal. Someone imprisoned the citadel guards in their own armor. We strike the curse, not the souls.',
          '${_art}shattered_spires.jpg', heading: 'THE CRYSTAL SENTINELS', emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('IGNIVAR',
          'The Ashen Forge kept the oldest oath: no flame shall burn another dragon in chains. The Choir made the oath a cage.',
          '${_art}ashen_oath.jpg', heading: 'ACT II · THE ASHEN OATH', emotion: 'anger'),
      StoryBeat('AQUARYTH',
          'Their embers remember a home. Beneath the fury, I can still hear the river that once cooled these mountains.',
          '${_art}ashen_oath.jpg', heading: 'THE RIVER UNDER FIRE'),
    ],
    <StoryBeat>[
      StoryBeat('NYXARIEL',
          'Moonveil is a place between the moment and its memory. The Choir hunts there because a lie becomes real if enough people forget.',
          '${_art}veil_between.jpg', heading: 'ACT III · THE VEIL BETWEEN'),
      StoryBeat('SOLARION',
          'Then let the truth be brighter than the lie. The shadows are not our enemies. The hands that stole their names are.',
          '${_art}veil_between.jpg', heading: 'THE MIRROR OF NAMES', emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('AQUARYTH',
          'Snow remembers every footprint. The Frost Matriarch has kept an entire generation frozen so the Choir could never take them.',
          '${_art}frost_memory.jpg', heading: 'ACT IV · THE FROST MEMORY'),
      StoryBeat('TEMPESTRYX',
          'She has mistaken stillness for safety. We must break the prison gently, before its captives forget how to wake.',
          '${_art}frost_memory.jpg', heading: 'THE MERCY OF THAW'),
    ],
    <StoryBeat>[
      StoryBeat('SOLARION',
          'Five fragments, five truths. The final gate reveals the voice that has commanded the Choir: the Seventh herself.',
          '${_art}last_eclipse.jpg', heading: 'ACT V · THE LAST ECLIPSE', emotion: 'warning'),
      StoryBeat('ASTRALIS',
          'She did not betray us. She has been singing alone for a thousand years, holding the darkness beyond the moon. We came to bring her home.',
          '${_art}last_eclipse.jpg', heading: 'THE SEVENTH VOICE', emotion: 'resolve'),
      StoryBeat('NYXARIEL',
          'To defeat the Sovereign, we must destroy the cage without destroying the one inside it. Remember who we are.',
          '${_art}last_eclipse.jpg', heading: 'SIX NAMES. ONE PROMISE.', emotion: 'warning'),
    ],
  ];

  static const bossPreludes = <List<StoryBeat>>[
    <StoryBeat>[
      StoryBeat('THE CRYSTAL WARDEN',
          'NAME IS ERROR. MEMORY IS TREASON. NONE SHALL PASS THE SILENT BELL.',
          '${_art}shattered_spires.jpg', heading: 'GUARDIAN · ECLIPSE GARGOYLE WARDEN', emotion: 'threat'),
      StoryBeat('ASTRALIS',
          'You protected these spires once. We will return your name to you.',
          '${_art}shattered_spires.jpg', heading: 'THE FIRST FRAGMENT', emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('THE ASHEN COLOSSUS',
          'THE OATH HAS NO END. MY CHAINS ARE ITS LAST WITNESSES.',
          '${_art}ashen_oath.jpg', heading: 'GUARDIAN · ASHEN DRAKE COLOSSUS', emotion: 'threat'),
      StoryBeat('IGNIVAR',
          'Fire is meant to warm the living. I will tear that false vow apart.',
          '${_art}ashen_oath.jpg', heading: 'THE SECOND FRAGMENT', emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('THE MOONVEIL SERPENT',
          'I AM EVERY FACE YOU FORGOT. WHICH ONE WILL YOU STRIKE?',
          '${_art}veil_between.jpg', heading: 'GUARDIAN · MOONVEIL SERPENT', emotion: 'threat'),
      StoryBeat('NYXARIEL',
          'I do not need to see your face to know you deserve a future.',
          '${_art}veil_between.jpg', heading: 'THE THIRD FRAGMENT', emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('THE FROST MATRIARCH',
          'I FROZE TIME TO SAVE THEM. YOU WILL NOT MAKE THEM SUFFER AGAIN.',
          '${_art}frost_memory.jpg', heading: 'GUARDIAN · FROST HARPY MATRIARCH', emotion: 'threat'),
      StoryBeat('AQUARYTH',
          'Rest is not the same as life. Let us carry the grief together.',
          '${_art}frost_memory.jpg', heading: 'THE FOURTH FRAGMENT', emotion: 'resolve'),
    ],
    <StoryBeat>[
      StoryBeat('THE ECLIPSE SOVEREIGN',
          'IF I STOP SINGING, THE VOID WILL EAT THE MOON. LET ME BE FORGOTTEN.',
          '${_art}last_eclipse.jpg', heading: 'GUARDIAN · ECLIPSE SOVEREIGN', emotion: 'threat'),
      StoryBeat('THE SIX DRAGONS',
          'No one holds the night alone. We will remember you—together.',
          '${_art}last_eclipse.jpg', heading: 'THE FIFTH FRAGMENT', emotion: 'resolve'),
    ],
  ];

  static const ending = <StoryBeat>[
    StoryBeat('THE SKY LEDGER',
        'The Moonheart was never a jewel. It was a promise that no life would vanish unheard. Six flames joined the Seventh song.',
        '${_art}last_eclipse.jpg', heading: 'EPILOGUE · THE NAME RETURNED'),
    StoryBeat('THE SEVENTH VOICE',
        'My name... was ELYRA. I thought I had to guard the night forever. Thank you for remembering me.',
        '${_art}last_eclipse.jpg', heading: 'ELYRA OF THE FIRST DAWN'),
    StoryBeat('ASTRALIS',
        'The moon will remember us all. And when new darkness comes, the sky will have seven voices to answer it.',
        '${_art}prologue.jpg', heading: 'THE LUNARYVELL OATH', emotion: 'resolve'),
  ];

  static List<StoryBeat> forWave(int wave, {bool completed = false}) {
    if (completed) return ending;
    if (wave < 1 || wave > 25) return const <StoryBeat>[];
    final chapter = (wave - 1) ~/ 5;
    if (wave % 5 == 0) return bossPreludes[chapter];
    if ((wave - 1) % 5 == 0) return chapters[chapter];
    return const <StoryBeat>[];
  }

  static List<StoryBeat> get openingSequence => <StoryBeat>[
        ...opening,
        ...chapters[0],
      ];

  static const waveNames = <String>[
    'THE SILENT BELL', 'SHARDS OF THE FIRST OATH', 'THE WARDEN\'S ECHO',
    'THE CATHEDRAL FRACTURES', 'THE CRYSTAL JUDGMENT',
    'CINDERS OF HOME', 'CHAINS OF THE FALSE VOW', 'RIVERS UNDER ASH',
    'THE LAST FORGE', 'COLOSSUS UNBOUND',
    'THE MIRROR TREES', 'FACES WITHOUT NAMES', 'CRESCENT LIES',
    'THE VEIL REMEMBERS', 'THE SERPENT\'S TRUTH',
    'THE SLEEPING SANCTUARY', 'SNOW OVER SILENCE', 'THE FROZEN CHILDREN',
    'THE LAST THAW', 'THE MATRIARCH\'S MERCY',
    'THE OBSIDIAN GATE', 'SIX FLAMES BELOW', 'THE EMPTY THRONE',
    'THE SEVENTH SONG', 'THE LAST ECLIPSE',
  ];

  static String waveName(int wave) => wave >= 1 && wave <= waveNames.length
      ? waveNames[wave - 1] : 'ENDLESS SKIES';
}
