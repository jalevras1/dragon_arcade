// Run 45 boss identities. Pure Dart: every combat pattern is deterministic
// and can be tested without a renderer or expensive particle simulation.
import 'dart:math' as math;

enum BossCombatPhase { guarded, awakened, unleashed }

/// One warning lane and the eventual matching hostile projectile.
class BossShotVector {
  const BossShotVector(this.sourceDx, this.vx, this.vy);

  final double sourceDx, vx, vy;
}

class BossEncounterRules {
  static const names = <String>[
    'ECLIPSE GARGOYLE WARDEN',
    'ASHEN DRAKE COLOSSUS',
    'MOONVEIL SERPENT',
    'FROST HARPY MATRIARCH',
    'ECLIPSE SOVEREIGN',
  ];

  static int chapterForWave(int wave) =>
      (((math.max(1, wave) - 1) ~/ 5).clamp(0, 4)).toInt();

  static String nameForWave(int wave) => names[chapterForWave(wave)];

  static int magicTypeForWave(int wave) =>
      // Existing Run 43 enemy-magic sprite atlas order: lightning crystal,
      // fire, purple crescent, blue ice/water and golden celestial eclipse.
      const <int>[1, 4, 2, 3, 5][chapterForWave(wave)];

  static double shieldForWave(int wave) {
    const shields = <double>[9, 0, 6, 12, 15];
    final chapter = chapterForWave(wave);
    if (shields[chapter] == 0) return 0;
    return shields[chapter] + math.max(0, wave - 5) * .12;
  }

  static BossCombatPhase phaseForHealth(double hp, double maxHealth) {
    if (maxHealth <= 0) return BossCombatPhase.guarded;
    final fraction = hp / maxHealth;
    if (fraction > .65) return BossCombatPhase.guarded;
    if (fraction > .30) return BossCombatPhase.awakened;
    return BossCombatPhase.unleashed;
  }

  static String phaseName(BossCombatPhase phase) => switch (phase) {
        BossCombatPhase.guarded => 'GUARDED',
        BossCombatPhase.awakened => 'AWAKENED',
        BossCombatPhase.unleashed => 'UNLEASHED',
      };

  /// Signature ritual names tie each chapter's combat choreography to its
  /// lore. The callouts use these titles; damage and warnings stay fair.
  static String signatureForWave(int wave, BossCombatPhase phase) {
    const rituals = <List<String>>[
      ['CRYSTAL LATTICE', 'SHATTERING VOW', 'THE SILENT BELL'],
      ['EMBER PROCESSION', 'IRON WING SWEEP', 'OATH OF ASH'],
      ['MIRROR CRESCENTS', 'FALSE REFLECTION', 'NAMELESS TIDE'],
      ['FROZEN PILLARS', 'WINTER LAMENT', 'LAST THAW'],
      ['ECLIPSE FAN', 'BROKEN CONSTELLATION', 'SEVENTH SONG'],
    ];
    return rituals[chapterForWave(wave)][phase.index];
  }

  static double attackInterval(int wave, BossCombatPhase phase) {
    const intervals = <double>[1.36, 1.15, 1.42, 1.52, 1.15];
    return math.max(.74,
        intervals[chapterForWave(wave)] - phase.index * .14).toDouble();
  }

  static double warningSeconds(int wave, BossCombatPhase phase) {
    const durations = <double>[.61, .47, .57, .63, .51];
    return math.max(.38,
        durations[chapterForWave(wave)] - phase.index * .035).toDouble();
  }

  /// Species-locked travel trajectories stay smooth when the refresh rate
  /// changes. Width is the live battlefield width in logical pixels.
  static double horizontalOffset(
      int wave, double time, double width) {
    // The game advances `time` continuously when phases change, so its
    // horizontal position does not jump as the encounter accelerates.
    final t = time;
    return switch (chapterForWave(wave)) {
      0 => math.sin(t * .72) * width * .15,
      1 => (math.sin(t * 1.37) * .21 +
          math.sin(t * 2.73) * .035) * width,
      2 => math.sin(t * .84 + math.sin(t * .44) * .88) * width * .18,
      3 => (math.sin(t * .48) * .105 +
          math.sin(t * 1.28) * .028) * width,
      _ => (math.sin(t * 1.04) * .17 +
          math.sin(t * 2.13) * .035) * width,
    };
  }

  /// The returned vectors are chosen at the start of a charge, then shown as
  /// warning lanes before they are launched. Once warned, they do not retarget
  /// a moving player. Keeping patterns readable is part of their difficulty.
  static List<BossShotVector> volley({
    required int wave,
    required BossCombatPhase phase,
    required double originX,
    required double originY,
    required double targetX,
    required double targetY,
    required int volleyIndex,
  }) {
    final aim = math.atan2(
        math.max(85.0, targetY - originY), targetX - originX);
    final level = phase.index;
    final shots = <BossShotVector>[];

    void cast(double spread, double velocity, {double sourceDx = 0}) {
      final angle = (aim + spread)
          .clamp(.13, math.pi - .13).toDouble();
      // All lanes travel toward the lower half of the portrait battlefield.
      shots.add(BossShotVector(sourceDx,
          math.cos(angle) * velocity, math.sin(angle) * velocity));
    }

    switch (chapterForWave(wave)) {
      case 0: // Crystal Warden: deliberate, symmetric shards.
        cast(-.25, 163 + level * 8);
        cast(0, 181 + level * 10);
        cast(.25, 163 + level * 8);
        if (level >= 1) {
          cast(-.43, 148 + level * 7);
          cast(.43, 148 + level * 7);
        }
        if (level == 2) cast(0, 218);
        break;
      case 1: // Ashen Drake: alternating sweeping ember wings.
        final sweep = volleyIndex.isEven ? -.10 : .10;
        for (final offset in <double>[-.40, -.20, 0, .20, .40]) {
          cast(offset + sweep, 177 + level * 11,
              sourceDx: offset * 42);
        }
        if (level == 2) {
          cast(-.54 + sweep, 155);
          cast(.54 + sweep, 155);
        }
        break;
      case 2: // Moonveil: alternating crescent gaps, not random tracking.
        final side = volleyIndex.isEven ? -1.0 : 1.0;
        cast(side * .10, 181 + level * 9);
        cast(side * .22, 170 + level * 9);
        cast(side * .35, 160 + level * 9);
        cast(-side * .08, 192 + level * 8);
        if (level >= 1) cast(-side * .25, 166 + level * 8);
        if (level == 2) cast(-side * .42, 156 + level * 8);
        break;
      case 3: // Frost Matriarch: parallel icicle columns with dodge gaps.
        final lean = volleyIndex.isEven ? -.055 : .055;
        for (final lane in <double>[-43, -16, 16, 43]) {
          cast(lean, 154 + level * 8, sourceDx: lane);
        }
        if (level >= 1) {
          cast(-.23, 164 + level * 9, sourceDx: -31);
          cast(.23, 164 + level * 9, sourceDx: 31);
        }
        if (level == 2) cast(0, 192);
        break;
      default: // Eclipse Sovereign: alternating convergence and star fans.
        final inversion = volleyIndex.isEven ? 1.0 : -1.0;
        for (final offset in <double>[-.38, -.19, 0, .19, .38]) {
          cast(offset + inversion * .07, 187 + level * 13);
        }
        if (level >= 1) {
          cast(-.56, 171 + level * 10, sourceDx: -28);
          cast(.56, 171 + level * 10, sourceDx: 28);
        }
        break;
    }
    assert(shots.length <= 7);
    return shots;
  }
}
