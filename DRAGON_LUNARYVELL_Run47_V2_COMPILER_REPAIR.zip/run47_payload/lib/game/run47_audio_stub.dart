/// Safe silent adapter for non-web targets; web uses built-in browser voices.
class Run47Audio {
  Run47Audio._();
  static final Run47Audio instance = Run47Audio._();
  bool muted = false;
  bool get voiceAvailable => false;
  void start() {}
  void stop() {}
  void toggleMute() => muted = !muted;
  void cue(String cue) {}
  void speak(String line, {void Function(int)? onBoundary,
      void Function()? onFinished, String speaker = '',
      String emotion = 'whisper'}) {}
  void stopNarration() {}
}
