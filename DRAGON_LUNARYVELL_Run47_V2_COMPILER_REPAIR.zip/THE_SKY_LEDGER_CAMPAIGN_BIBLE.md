# DRAGON LUNARYVELL — THE SKY LEDGER
## Run 47 · Campaign and audio direction bible

### Core premise

Lunaryvell is not a stone moon but a living archive. Its **Moonheart** remembers
the true name of every soul that has ever lived beneath it. Seven primordial
voices shared the task of keeping that archive safe. During the first eclipse,
the seventh guardian **Elyra** sacrificed her own name and voice to seal the
memory-devouring **Hollow Choir** outside reality. Six surviving dragons
swore to preserve all she had saved. Each received a fragment of her vow.

Centuries later, the Choir learned to wear stolen memories as bodies:
gargoyles, harpies, manticores and spectral moths. Its song erases names,
leaving protective instincts behind as monstrous hostility. Each of the five
chapter guardians believes it is protecting Lunaryvell, but the Choir has
turned its virtue into a prison.

The six dragons are **not interchangeable color skins**; each answers a
different existential part of the oath:

| Guardian | Vow | Character flaw | Earned insight | Weapon sound |
|---|---|---|---|---|
| ASTRALIS · starlight | Remember the forgotten | Clings to old certainty | True memory can change without being lost | Crystalline starlight impact |
| TEMPESTRYX · storm | Defend the unprotected | Anger moves faster than judgment | Protection requires patience | Crackling sky lightning |
| IGNIVAR · fire | Free the bound | Mistakes force for freedom | Gentle warmth can break a chain | Roaring ember ignition |
| NYXARIEL · shadow | See the unseen | Trusts silence more than others | Shadows preserve truth, too | Whispering void-blade |
| SOLARION · sun | Illuminate the truth | Can be blindingly absolute | Compassion makes truth bearable | Radiant solar chime |
| AQUARYTH · tide | Carry the wounded | Confuses keeping safe with holding still | Healing is movement | Soft cresting water glyph |

### Five-act campaign — 25 waves

#### ACT I · THE SHATTERED SPIRES (waves 1–5)

Environmental painting: collapsed cathedral on floating violet crystal isles,
an enormous silent moon bell, ruined sky bridges. Enemy identity: crystal
gargoyles are former guardians trapped in armor, skyriders are hollow echoes
of couriers, storm harpies mourn the lost bells. The Warden protects the
last crystal fragment because the Choir made it believe that every name is a
threat. ASTRALIS recovers the **First Fragment: Witness**.

1. The Silent Bell — discover missing names carved into cathedral steps.
2. Shards of the First Oath — crystal enemies guard the broken bell tower.
3. The Warden's Echo — thunder reveals the guardian's earlier oath.
4. The Cathedral Fractures — racing through the collapsing sky bridges.
5. The Crystal Judgment — boss with faceted binding ring and shard-fan lanes.

#### ACT II · THE ASHEN OATH (waves 6–10)

Environmental painting: iron bridges over an ash-red volcanic forge metropolis,
long chains, inverted firefalls. Fire drake/manticore enemies are corrupted
forge beasts conditioned to attack anything that could free them. IGNIVAR
must confront his own urge to burn first and ask later. The Colossus once
forged the oath to shelter dragons, but its chains now imprison them.
**Second Fragment: Freedom**.

6. Cinders of Home — find the cooled riverbed beneath the forge.
7. Chains of the False Vow — defense lines become cages.
8. Rivers Under Ash — AQUARYTH discovers water still beneath the lava.
9. The Last Forge — rescue imprisoned hatchlings' names.
10. Colossus Unbound — boss with marching ember columns and sweeping wings.

#### ACT III · THE VEIL BETWEEN (waves 11–15)

Environmental painting: lavender moon forest, ruined gates, mirror lake
reflecting another cosmos. Void moths and phantom serpents copy the faces of
souls the world has forgotten. NYXARIEL fears what shadows have concealed,
yet becomes the only one who can identify a lie when the mirror shows two
opposing truths. **Third Fragment: Truth**.

11. The Mirror Trees — first impossible reflection.
12. Faces Without Names — remembered voices turn against the party.
13. Crescent Lies — choose to rescue a copied shadow.
14. The Veil Remembers — the party finds Elyra's erased star map.
15. The Serpent's Truth — boss uses asymmetric crescent gaps, not ambush.

#### ACT IV · THE FROST MEMORY (waves 16–20)

Environmental painting: pale cyan glacial sanctuary, thousands of statues
trapped in ice, a harpy matriarch with a broken crown. The Matriarch froze
her people to keep the Choir from consuming them. AQUARYTH shows that life
cannot be preserved by refusing to let it live. **Fourth Fragment: Mercy**.

16. The Sleeping Sanctuary — hushed ice cathedral opens.
17. Snow Over Silence — frozen voices form a song.
18. The Frozen Children — rescued names grow restless.
19. The Last Thaw — thaw without destroying the sanctuary.
20. The Matriarch's Mercy — boss fires icy columns with readable escape lanes.

#### ACT V · THE LAST ECLIPSE (waves 21–25)

Environmental painting: floating gold-black observatory at a broken star
gate, a white ember of a moon in the sky, fractured rings of the Moonheart.
The Choir's apparent monarch is revealed as Elyra herself. She did not
betray the six; her endless effort to hold the void away left her memories
unprotected, and the Choir now speaks through her. The guardians must break
the prison without ending the song. **Fifth Fragment: Belonging**.

21. The Obsidian Gate — portal to the Choir's reverse sky.
22. Six Flames Below — every dragon's vow forms part of the entrance seal.
23. The Empty Throne — the Sovereign has no name.
24. The Seventh Song — revelation that Elyra still resists within.
25. The Last Eclipse — phased star-fan Sovereign battle; six names answer one.

### Ending

The six bind the recovered fragments into a new collective vow, allowing
Elyra to stop carrying the night alone. She remembers her name and rejoins
Lunaryvell as its seventh voice. The Moonheart is restored as a living promise,
not a shiny collectible. Future seasons may begin when fragments of the
Choir survive as innocent memories needing new homes.

### Visual language

- Five painterly chapter backdrops plus a celestial-six prologue, no text
  baked into illustrations. The runtime overlays accessible, animated captions.
- Sky Ledger dialogue frames: dark sapphire glass, fine pale-gold border,
  small diamond heraldry, muted rune-flare, readable ivory text.
- Bosses: circular heraldic seals, five chapter-specific runes, three clear
  phase thresholds, pre-fired attack lanes, restrained victory glimmers.
- Relic drops: high-contrast painted 2D cutout medallions on transparent
  PNG; slow pulse and thin aura never obscure the flight path.

### Audio and accessibility

- Original 48-second harmonic ambient loop, low enough for dialogue and cues.
- Distinct pickup fanfares; six keyed weapon timbres played once every third
  *volley*, not once per bullet, to avoid multi-shot audio pileups.
- Browser speech synthesis (no additional software, service, credential or
  recorded actors) speaks each optional story beat. Captions type in as the
  speech progresses, using word boundary events when available and a paced
  fallback otherwise. Tapping the speaker controls narration.
- Android browser voices, offline behavior, exact word timing and autoplay
  permissions vary by device; caption-only and mute are first-class routes.

### Release gate

The working Run 46 sources and build are preserved until the new source
passes structural checks, Flutter analysis/tests and a fresh Codespaces web
build. The installer restores original files and `build/web` on failure.
