#!/usr/bin/env python3
"""Check the Run 39 full-field control and unobtrusive HUD repair."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent
game = (root / 'lib/game/dragon_lunaryvell_game.dart').read_text()
shell = (root / 'lib/ui/dragon_shell.dart').read_text()

# Free player flight: only sprite-body visibility restricts finger position.
assert '_targetY = point.dy.clamp(top, math.max(top, size.y - top))' in game
assert '_targetX = point.dx.clamp(left, math.max(left, size.x - left))' in game
assert 'final top = math.min(57.0, size.y / 2);' in game
assert '_targetY = point.dy.clamp(size.y * .38' not in game
assert 'step * (_hasteRemaining > 0 ? 25 : 18)' in game
assert '_playerY = math.max(math.min(57.0, size.y / 2), _playerY - 105)' in game

# Load the premium scene and all gameplay art before the FIRST game frame;
# no fallback gradient, old still sprites or circular enemies may blink in.
for expected in [
    'final battlefieldReady = _preloadBattlefield();',
    'final enemiesReady = _preloadEnemySprites();',
    'final projectilesReady = _preloadRun32Projectiles();',
    'final selectedDragonReady = _loadDragonArtwork(dragon);',
    'await Future.wait<void>([',
    'battlefieldReady, enemiesReady, projectilesReady, selectedDragonReady,',
]:
    assert expected in game, expected
assert 'unawaited(_preloadBattlefield());' not in game

# Compact HUD: the same three trackers stay at the top with translucent
# backgrounds, and dragon selection/test buttons remain touch-operable.
for label in ['SCORE', 'STORY', 'WAVE', 'HULL']:
    assert label in shell, label
assert 'height: 36,' in shell
assert 'Color(0x9917233F), Color(0x8810182B)' in shell
assert "tooltip: 'Select dragon: ${state.dragonName}'" in shell
assert ("tooltip: 'Developer test controls'" in shell or
        "message: 'Developer test controls'" in shell)
assert "'BEGIN FLIGHT'" in shell
assert 'onPressed: widget.onMenu' in shell
assert 'onPressed: _game.togglePause' in shell

print('RUN 39 PREFLIGHT PASS: full-field finger control, faster tracking, '
      'no art flash, compact readable HUD, original buttons preserved')
