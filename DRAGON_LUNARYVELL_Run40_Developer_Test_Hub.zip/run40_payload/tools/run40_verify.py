#!/usr/bin/env python3
"""Offline regression checks for the debug-only Run 40 navigation hub."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent
game = (root / 'lib/game/dragon_lunaryvell_game.dart').read_text()
ui = (root / 'lib/ui/dragon_shell.dart').read_text()

assert "bool.fromEnvironment('DL_DEV_TOOLS', defaultValue: false)" in ui
assert "String.fromEnvironment('DL_TEST_BUILD'" in ui
assert 'if (_enableTestTools)\n            Positioned(' in ui
assert ui.index('if (_enableTestTools)\n            Positioned(') > ui.index(
    "state.campaignComplete\n                            ? 'THE MOONHEART IS RESTORED'")
assert 'message: \'Developer test controls\'' in ui
assert "label: const Text('DEV')" in ui
assert 'Future<void> _developerPanel(' in ui
assert 'game.developerSetPanelOpen(true);' in ui
assert 'game.developerSetPanelOpen(false);' in ui
assert 'await showModalBottomSheet<_DevDestination>' in ui

for section in ['GO TO ANY MENU', 'NEW ART AND ANIMATION',
                'ENEMIES AND POWER-UPS', 'EXACT WAVE AND BOSS TEST',
                'PLAYER AND COMBAT']:
    assert section in ui, section
for destination in ['title', 'arcade', 'campaign', 'dragons',
                    'howToPlay', 'about']:
    assert f'_DevDestination.{destination}' in ui, destination
for button in ['ALL THREE ENEMIES', 'CLEAR SCENERY', 'SPECIAL + TARGETS',
               'SPECIAL READY', 'USE SPECIAL', 'DROP HASTE', 'DROP CRITICAL',
               'DROP SHIELD', 'JUMP TO WAVE', 'TEST BOSS', 'HEAL FULL',
               'TAKE ONE HIT', 'RESTART', 'RETURN TO TEST']:
    assert button in ui, button

for hook in ['developerSetPanelOpen', 'developerSnapshot',
             'developerJumpToWave', 'developerEnemyGallery',
             'developerClearArena', 'developerGrantBoost',
             'developerForceAbilityReady', 'developerTestDamage']:
    assert hook in game, hook
assert 'if (_developerPanelOpen || _paused || _gameOver' in game
assert 'if (!_developerShowcase && _boss == null' in game
assert 'if (!_developerShowcase && _spawnedThisWave >= quota' in game
assert '_developerShowcase = false;' in game
assert 'CampaignChapter.finalWave' in game
assert 'bool activateSpecial()' in game
assert 'void restartGame()' in game

# Nothing makes the developer actions visible in a normal release.
assert 'if (_enableTestTools)' in ui
print('RUN 40 PREFLIGHT PASS: mobile DEV hub, six menu destinations, '
      'wave/boss jumps, isolated enemy gallery, boosts, specials and recovery')
