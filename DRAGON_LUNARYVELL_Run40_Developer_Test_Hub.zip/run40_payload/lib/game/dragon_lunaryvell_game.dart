import 'dart:async' show unawaited;
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flame/game.dart';
import 'package:flame/components.dart' show Vector2;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dragon_profile.dart';
import 'special_ability_rules.dart';
import 'campaign_story.dart';
import 'dragon_flight_cycle.dart';

class DragonHudState {
  const DragonHudState({
    this.score = 0,
    this.wave = 1,
    this.health = 3,
    this.paused = false,
    this.bossActive = false,
    this.dragonName = 'ASTRALIS',
    this.specialRemaining = 0,
    this.specialMax = 11,
    this.hasteRemaining = 0,
    this.critRemaining = 0,
    this.shields = 0,
    this.campaignMode = false,
    this.campaignIntermission = false,
    this.campaignComplete = false,
    this.chapterTitle = '',
  });
  final int score;
  final int wave;
  final int health;
  final bool paused;
  final bool bossActive;
  final String dragonName;
  final double specialRemaining;
  final double specialMax;
  final double hasteRemaining, critRemaining;
  final int shields;
  final bool campaignMode, campaignIntermission, campaignComplete;
  final String chapterTitle;

  DragonHudState copyWith(
          {int? score,
          int? wave,
          int? health,
          bool? paused,
          bool? bossActive,
          String? dragonName,
          double? specialRemaining,
          double? specialMax,
          double? hasteRemaining,
          double? critRemaining,
          int? shields,
          bool? campaignMode,
          bool? campaignIntermission,
          bool? campaignComplete,
          String? chapterTitle}) =>
      DragonHudState(
        score: score ?? this.score,
        wave: wave ?? this.wave,
        health: health ?? this.health,
        paused: paused ?? this.paused,
        bossActive: bossActive ?? this.bossActive,
        dragonName: dragonName ?? this.dragonName,
        specialRemaining: specialRemaining ?? this.specialRemaining,
        specialMax: specialMax ?? this.specialMax,
        hasteRemaining: hasteRemaining ?? this.hasteRemaining,
        critRemaining: critRemaining ?? this.critRemaining,
        shields: shields ?? this.shields,
        campaignMode: campaignMode ?? this.campaignMode,
        campaignIntermission: campaignIntermission ?? this.campaignIntermission,
        campaignComplete: campaignComplete ?? this.campaignComplete,
        chapterTitle: chapterTitle ?? this.chapterTitle,
      );
}

class _Bolt {
  _Bolt(this.x, this.y, {this.speed = 520});
  double x, y;
  final double speed;
}

class _EnemyBolt {
  _EnemyBolt(this.x, this.y, this.vx, this.vy);
  double x, y;
  final double vx, vy;
}

class _Foe {
  _Foe(
      {required this.x,
      required this.y,
      required this.hp,
      required this.radius,
      required this.speed,
      this.boss = false,
      this.typeIndex = 0,
      this.spriteSize = 60});
  double x, y, hp, radius, speed, spriteSize;
  bool boss;
  int typeIndex;
  double fireClock = 0;
  double animationClock = 0;
  int animationFrame = 0;
}

class _SpellLine {
  _SpellLine(this.from, this.to, this.color, this.kind,
      {this.life = .66})
      : initialLife = life;
  final Offset from, to;
  final Color color;
  final String kind;
  final double initialLife;
  double life;
}

class _SeekingFlame {
  _SeekingFlame(this.x, this.y, this.target, this.seed)
      : previous = Offset(x, y);
  double x, y;
  Offset previous;
  _Foe? target;
  final int seed;
  double life = 2.1;
}

class _SolarMark {
  _SolarMark(this.target, this.position, this.delay);
  _Foe? target;
  Offset position;
  double delay;
}

class _SpellZone {
  _SpellZone(this.kind, this.center, this.radius, this.life)
      : initialLife = life;
  final String kind;
  final Offset center;
  final double radius, initialLife;
  double life;
  double pulse = 0;
}

enum _PickupKind { haste, critical, shield }

class _Pickup {
  _Pickup(this.x, this.y, this.kind);
  double x, y;
  final _PickupKind kind;
  double age = 0;
}

class _DefeatGlimmer {
  _DefeatGlimmer(this.center, this.tint);
  final Offset center;
  final Color tint;
  double age = 0;
  static const double duration = .26;
}

class DragonLunaryvellGame extends FlameGame {
  DragonLunaryvellGame({this.dragon = DragonProfile.astralis,
    this.campaignMode = false});
  DragonProfile dragon;
  final bool campaignMode;
  bool _campaignIntermission = false;
  bool _campaignComplete = false;
  final ValueNotifier<DragonHudState> hud =
      ValueNotifier(const DragonHudState());
  final List<_Bolt> _bolts = [];
  final List<_EnemyBolt> _enemyBolts = [];
  final List<_Foe> _foes = [];
  final math.Random _random = math.Random(17);

  double _playerX = 0, _playerY = 0;
  double _targetX = 0, _targetY = 0;
  double _fireClock = 0, _spawnClock = 0, _hudClock = 0;
  double _waveElapsed = 0;
  double _waveBannerRemaining = 1.6;
  double _playerInvulnerable = 0;
  double _bossAttackClock = 0;
  double _specialCooldown = 0;
  double _specialClock = 0;
  double _specialInitialClock = .75;
  double _fxTime = 0;
  Offset _specialOrigin = Offset.zero;
  Offset _dashOrigin = Offset.zero;
  String _activeSpecialId = 'astralis';
  final List<_SpellLine> _spellLines = [];
  final List<_SeekingFlame> _seekingFlames = [];
  final List<_SolarMark> _solarMarks = [];
  _SpellZone? _spellZone;
  final List<_Pickup> _pickups = [];
  final List<_DefeatGlimmer> _defeatGlimmers = [];
  double _hasteRemaining = 0;
  double _critRemaining = 0;
  double _shieldRemaining = 0;
  double _shieldPulse = 0;
  int _shieldCharges = 0;
  int _spawnedThisWave = 0, _defeatedThisWave = 0;
  int _score = 0, _wave = 1, _health = 3;
  bool _touching = false, _paused = false, _gameOver = false;
  // Developer-only testing state: no effect in normal player sessions.
  bool _developerPanelOpen = false;
  bool _developerShowcase = false;
  _Foe? _boss;
  List<ui.Image> _flightFrames = [];
  List<List<ui.Image>> _enemyFrames = [];
  ui.Image? _battlefieldArt;
  double _flightClock = 0;
  int _flightFrame = 0;
  double _wingMotionSeconds = 0;
  double _flightBank = 0;
  final Map<String, ui.Image> _run31DragonStills = {};
  final Map<String, List<ui.Image>> _run32DragonFlights = {};
  List<ui.Image> _run32PlayerBoltFrames = [];
  List<ui.Image> _run32EnemyBoltFrames = [];
  ui.Image? _run31BossImage;
  // Sprite file names use 'tempestryx'; the existing profile ID is
  // 'temperstryx'. Keep that historical ID so saves and selection still work.
  static const Map<String, String> _run32DragonPaths = {
    'temperstryx': 'tempestryx',
    'ignivar': 'ignivar',
    'nyxariel': 'nyxariel',
    'solarion': 'solarion',
    'aquaryth': 'aquaryth',
  };
  static const Map<String, String> _run31DragonPaths = {
    'temperstryx': 'run31/dragons/tempestryx_flight_base.png',
    'ignivar': 'run31/dragons/ignivar_flight_base.png',
    'nyxariel': 'run31/dragons/nyxariel_flight_base.png',
    'solarion': 'run31/dragons/solarion_flight_base.png',
    'aquaryth': 'run31/dragons/aquaryth_flight_base.png',
  };

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    // Start these loads together. Finish them before Flame's first gameplay
    // frame so the previous gradient, shape-only enemies, or older dragon
    // stills never flash underneath Run 38 artwork for a frame.
    final battlefieldReady = _preloadBattlefield();
    final enemiesReady = _preloadEnemySprites();
    final projectilesReady = _preloadRun32Projectiles();
    final selectedDragonReady = _loadDragonArtwork(dragon);
    _flightFrames = await Future.wait(
      List.generate(
        8,
        (i) => images.load(
          'dragons/astralis/flight/astralis_flight_wing_${i.toString().padLeft(2, '0')}.png',
        ),
      ),
    );
    await Future.wait<void>([
      battlefieldReady, enemiesReady, projectilesReady, selectedDragonReady,
    ]);
    // Decode optional Run 31 artwork in the background, not on the critical
    // path for the existing eight-frame ASTRALIS animation.
    unawaited(_preloadRun31Assets());
    // The loadingBuilder remains visible during the parallel decode above.
  }

  Future<void> _preloadBattlefield() async {
    try {
      _battlefieldArt = await images.load(
          'run38/backgrounds/battlefield_moon_citadel.png');
    } catch (error) {
      debugPrint('Optional Run 38 scenery unavailable: $error');
    }
  }

  Future<void> _preloadEnemySprites() async {
    try {
      // Three remastered enemies now have distinct painted up/down/recovery
      // wing poses instead of barely changing 3-frame originals.
      _enemyFrames = [
        await Future.wait(List.generate(8, (i) => images.load(
            'run38/enemies/goblin_sky_raider/goblin_${i.toString().padLeft(2, '0')}.png'))),
        await Future.wait(List.generate(7, (i) => images.load(
            'run38/enemies/harpy/harpy_${i.toString().padLeft(2, '0')}.png'))),
        await Future.wait(List.generate(7, (i) => images.load(
            'run38/enemies/shadow_wyvern/shadow_wyvern_${i.toString().padLeft(2, '0')}.png'))),
      ];
    } catch (error) {
      debugPrint('Run 38 enemies unavailable, trying original art: $error');
      try {
        _enemyFrames = [
          await Future.wait(List.generate(4, (i) => images.load(
              'enemies/goblin_sky_raider/goblin_${i.toString().padLeft(2, '0')}.png'))),
          await Future.wait(List.generate(3, (i) => images.load(
              'enemies/harpy/harpy_${i.toString().padLeft(2, '0')}.png'))),
          await Future.wait(List.generate(3, (i) => images.load(
              'enemies/shadow_wyvern/shadow_wyvern_${i.toString().padLeft(2, '0')}.png'))),
        ];
      } catch (fallbackError) {
        debugPrint('Optional enemy art unavailable: $fallbackError');
      }
    }
  }

  Future<void> _preloadRun32Projectiles() async {
    try {
      _run32PlayerBoltFrames = await Future.wait(List.generate(
        3,
        (i) => images.load(
          'projectiles/player/celestial_bolt_${i.toString().padLeft(2, '0')}.png',
        ),
      ));
    } catch (error) {
      debugPrint('Existing player projectile sprites unavailable: $error');
    }
    try {
      _run32EnemyBoltFrames = await Future.wait(List.generate(
        3,
        (i) => images.load(
          'projectiles/enemy/ember_bolt_${i.toString().padLeft(2, '0')}.png',
        ),
      ));
    } catch (error) {
      debugPrint('Existing enemy projectile sprites unavailable: $error');
    }
  }

  Future<void> _preloadRun31Assets() async {
    // Run 31 artwork is optional at runtime: preserve existing sprites if a
    // new asset is absent, and keep the ASTRALIS flight cycle untouched.
    try {
      _run31BossImage =
          await images.load('run31/bosses/eclipse_gargoyle_warden.png');
    } catch (error) {
      debugPrint('Run 31 boss art unavailable: $error');
    }
    // Run 36 draws unique lightweight 2D ability effects. Preserve the old
    // illustrations on disk as references but do not decode or overlay them.
  }

  @override
  void onRemove() {
    hud.dispose();
    super.onRemove();
  }

  @override
  Color backgroundColor() => const Color(0xFF050817);

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    if (_playerX == 0) {
      _playerX = size.x / 2;
      _playerY = size.y * .78;
      _targetX = _playerX;
      _targetY = _playerY;
    }
  }

  void setTouchTarget(Offset point) {
    if (size.x <= 0 || size.y <= 0) return;
    _touching = true;
    // Full-screen free flight. Only the dragon's visible half-width/height
    // remain on screen; there is no artificial 38%-from-top restriction.
    final left = math.min(43.0, size.x / 2);
    final top = math.min(57.0, size.y / 2);
    _targetX = point.dx.clamp(left, math.max(left, size.x - left)).toDouble();
    _targetY = point.dy.clamp(top, math.max(top, size.y - top)).toDouble();
  }

  void releaseTouch() => _touching = false;

  Future<void> selectDragon(DragonProfile profile) async {
    if (profile.id == dragon.id) return;
    // Selection is a gameplay action: never block it on network/asset decoding.
    // The palette/vector fallback works immediately while artwork arrives.
    dragon = profile;
    _specialClock = 0;
    _flightFrame = 0;
    _wingMotionSeconds = 0;
    _flightBank = 0;
    _publishHud(force: true);
    await _loadDragonArtwork(profile);
  }

  Future<void> _loadDragonArtwork(DragonProfile profile) async {
    // Run 38: all six playable dragons have eight actual painted frames,
    // identically registered and sampled at ASTRALIS's exact 100ms cadence.
    // Run 34 four-pose images remain on disk as an emergency fallback.
    final flightName = _run32DragonPaths[profile.id];
    if (flightName != null && !_run32DragonFlights.containsKey(profile.id)) {
      try {
        _run32DragonFlights[profile.id] = await Future.wait(List.generate(
          8,
          (i) => images.load(
            'run38/dragons/$flightName/flight/${flightName}_flight_${i.toString().padLeft(2, '0')}.png',
          ),
        ));
      } catch (error) {
        debugPrint('Run 38 dragon animation unavailable; using Run 34: $error');
        try {
          _run32DragonFlights[profile.id] = await Future.wait(List.generate(
            4,
            (i) => images.load(
              'run32/dragons/$flightName/flight/${flightName}_flight_${i.toString().padLeft(2, '0')}.png',
            ),
          ));
        } catch (fallbackError) {
          debugPrint('Legacy dragon flight unavailable: $fallbackError');
        }
      }
    }
    if (!_run32DragonFlights.containsKey(profile.id)) {
      final stillPath = _run31DragonPaths[profile.id];
      if (stillPath != null && !_run31DragonStills.containsKey(profile.id)) {
        try {
          _run31DragonStills[profile.id] = await images.load(stillPath);
        } catch (error) {
          debugPrint('Run 31 dragon art unavailable: $error');
        }
      }
    }
  }

  void togglePause() {
    if (_gameOver || _campaignIntermission || _campaignComplete) return;
    _paused = !_paused;
    _publishHud(force: true);
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (_developerPanelOpen || _paused || _gameOver || size.x <= 0 || size.y <= 0) return;
    final step = dt.clamp(0.0, .05).toDouble();
    _wingMotionSeconds += step;
    _waveBannerRemaining = math.max(0.0, _waveBannerRemaining - step).toDouble();
    for (final glimmer in _defeatGlimmers) {
      glimmer.age += step;
    }
    _defeatGlimmers.removeWhere((fx) =>
        fx.age >= _DefeatGlimmer.duration);
    if (_flightFrames.isNotEmpty) {
      _flightClock += step;
      while (_flightClock >= .1) {
        _flightClock -= .1;
        _flightFrame = (_flightFrame + 1) % _flightFrames.length;
      }
    }
    if (_specialCooldown > 0) {
      _specialCooldown = math.max(0.0, _specialCooldown - step).toDouble();
    }
    if (_specialClock > 0) {
      _specialClock = math.max(0.0, _specialClock - step).toDouble();
    }
    _waveElapsed += step;
    if (_playerInvulnerable > 0) {
      _playerInvulnerable =
          math.max(0.0, _playerInvulnerable - step).toDouble();
    }

    if (_touching) {
      // Close finger-following without instantaneous teleportation; keep the
      // haste pickup meaningfully faster while preserving smooth movement.
      final blend = (step * (_hasteRemaining > 0 ? 25 : 18))
          .clamp(0.0, 1.0).toDouble();
      _playerX += (_targetX - _playerX) * blend;
      _playerY += (_targetY - _playerY) * blend;
    }
    final bankGoal = _touching
        ? ((_targetX - _playerX) / math.max(120.0, size.x))
            .clamp(-.075, .075).toDouble()
        : 0.0;
    _flightBank += (bankGoal - _flightBank) *
        (step * 7).clamp(0.0, 1.0).toDouble();

    _updateSpecialsAndPickups(step);

    _fireClock += step;
    if (_fireClock >= .22) {
      _fireClock = 0;
      _bolts.add(_Bolt(_playerX, _playerY - 22));
    }

    final quota = 7 + _wave * 2;
    final bossWave = _wave % 5 == 0;
    if (!_developerShowcase && _boss == null && _spawnedThisWave < quota) {
      _spawnClock += step;
      final interval = math.max(.32, .95 - _wave * .035);
      if (_spawnClock >= interval) {
        _spawnClock = 0;
        _spawnedThisWave++;
        final enemyType = _random.nextInt(3);
        final enemyRadius = [15.0, 17.0, 19.0][enemyType];
        final enemySpeed = [78.0, 68.0, 58.0][enemyType] + _wave * 4;
        // Run 35: about 12% larger for phone readability; hit boxes scale too.
        final enemySize = [64.0, 72.0, 82.0][enemyType];
        _foes.add(_Foe(
          x: 24 + _random.nextDouble() * math.max(1.0, size.x - 48).toDouble(),
          y: -24,
          hp: 1.0 + (_wave ~/ 3),
          radius: enemyRadius,
          speed: enemySpeed,
          typeIndex: enemyType,
          spriteSize: enemySize,
        ));
      }
    }

    for (final bolt in _bolts) {
      bolt.y -= bolt.speed * step;
    }
    _bolts.removeWhere((b) => b.y < -30);

    for (final foe in _foes) {
      if (foe.typeIndex >= 0 && foe.typeIndex < _enemyFrames.length) {
        final frames = _enemyFrames[foe.typeIndex];
        if (frames.isNotEmpty) {
          foe.animationClock += step;
          while (foe.animationClock >= .1) {
            foe.animationClock -= .1;
            foe.animationFrame = (foe.animationFrame + 1) % frames.length;
          }
        }
      }
      foe.y += foe.speed *
          (_spellZone?.kind == 'aquaryth' &&
                  _distance(foe.x, foe.y, _spellZone!.center.dx,
                          _spellZone!.center.dy) < _spellZone!.radius
              ? .44
              : 1.0) * step;
      // Three distinguishable, smoothly varying flight styles, with margins
      // so wider wing art stays inside a portrait display.
      final time = _waveElapsed;
      final phase = foe.y * .009 + foe.typeIndex * 1.7;
      final weave = [
        25.0 * math.sin(time * 2.3 + phase),
        49.0 * math.sin(time * 3.1 + phase),
        38.0 * math.sin(time * 1.65 + phase),
      ][foe.typeIndex.clamp(0, 2).toInt()];
      foe.x = (foe.x + weave * step)
          .clamp(foe.radius + 15, size.x - foe.radius - 15).toDouble();
      foe.fireClock += step;
      if (foe.fireClock >= 1.8 && foe.y > 8 && foe.y < size.y * .72) {
        foe.fireClock = 0;
        final dx = _playerX - foe.x;
        final dy = _playerY - foe.y;
        final length = math.max(1.0, math.sqrt(dx * dx + dy * dy));
        const shotSpeed = 165.0;
        _enemyBolts.add(_EnemyBolt(foe.x, foe.y + foe.radius,
            dx / length * shotSpeed, dy / length * shotSpeed));
      }
    }

    for (final bolt in _bolts.toList()) {
      for (final foe in _foes.toList()) {
        if (_distance(bolt.x, bolt.y, foe.x, foe.y) < foe.radius + 5) {
          foe.hp -= _critRemaining > 0 && _random.nextDouble() < .25
              ? 2
              : 1;
          _bolts.remove(bolt);
          if (foe.hp <= 0) {
            _defeatFoe(foe);
          }
          break;
        }
      }
    }

    for (final foe in _foes.toList()) {
      if (_distance(_playerX, _playerY, foe.x, foe.y) < foe.radius + 13) {
        _foes.remove(foe);
        _damagePlayer();
      } else if (foe.y > size.y + 25) {
        _foes.remove(foe);
        _damagePlayer();
      }
    }

    for (final shot in _enemyBolts) {
      shot.x += shot.vx * step;
      shot.y += shot.vy * step;
    }
    _enemyBolts.removeWhere(
        (shot) => shot.y > size.y + 24 || shot.x < -24 || shot.x > size.x + 24);
    for (final shot in _enemyBolts.toList()) {
      if (_distance(_playerX, _playerY, shot.x, shot.y) < 17) {
        _enemyBolts.remove(shot);
        _damagePlayer();
      }
    }

    if (!_developerShowcase && _spawnedThisWave >= quota &&
        _foes.isEmpty && _boss == null) {
      if (bossWave) {
        _boss = _Foe(
            x: size.x / 2,
            y: -60,
            hp: 20 + _wave * 4,
            radius: 34,
            speed: 48,
            boss: true);
      } else {
        _advanceWave();
      }
    }

    if (_boss case final boss?) {
      boss.y = math.min(size.y * .23, boss.y + boss.speed * step).toDouble();
      boss.x = size.x / 2 + math.sin(_waveElapsed * .9) * size.x * .24;
      for (final bolt in _bolts.toList()) {
        if (_distance(bolt.x, bolt.y, boss.x, boss.y) < boss.radius + 5) {
          boss.hp -= 1;
          _bolts.remove(bolt);
        }
      }
      _bossAttackClock += step;
      // Each five-wave boss escalates both health and attack tempo.
      final bossTier = (_wave ~/ 5).clamp(1, 8);
      if (_bossAttackClock >= math.max(.56, 1.46 - bossTier * .15) &&
          boss.y > 0) {
        _bossAttackClock = 0;
        final dx = _playerX - boss.x;
        final dy = _playerY - boss.y;
        final length = math.max(1.0, math.sqrt(dx * dx + dy * dy));
        final vx = dx / length * 190;
        final vy = dy / length * 190;
        _enemyBolts.add(_EnemyBolt(boss.x, boss.y + boss.radius, vx, vy));
        _enemyBolts.add(_EnemyBolt(boss.x, boss.y + boss.radius, vx - 48, vy));
        _enemyBolts.add(_EnemyBolt(boss.x, boss.y + boss.radius, vx + 48, vy));
        if (bossTier >= 3) {
          _enemyBolts.add(_EnemyBolt(boss.x, boss.y + boss.radius,
              vx - 94, vy));
          _enemyBolts.add(_EnemyBolt(boss.x, boss.y + boss.radius,
              vx + 94, vy));
        }
      }
      if (boss.hp <= 0) {
        _score += 2500;
        _boss = null;
        _advanceWave();
      }
      if (_distance(_playerX, _playerY, boss.x, boss.y) < boss.radius + 12) {
        _damagePlayer();
      }
    }

    _hudClock += step;
    if (_hudClock >= .12) {
      _hudClock = 0;
      _publishHud();
    }
  }

  void _advanceWave() {
    if (campaignMode && _wave >= CampaignChapter.finalWave) {
      _campaignComplete = true;
      _paused = true;
      _publishHud(force: true);
      return;
    }
    final finishedChapter = campaignMode && _wave % 5 == 0;
    _wave++;
    _spawnedThisWave = 0;
    _defeatedThisWave = 0;
    _spawnClock = 0;
    _waveElapsed = 0;
    _waveBannerRemaining = 1.55;
    if (finishedChapter) {
      _campaignIntermission = true;
      _paused = true;
      _publishHud(force: true);
    }
  }

  void continueCampaign() {
    if (!_campaignIntermission || _campaignComplete) return;
    _campaignIntermission = false;
    _paused = false;
    _publishHud(force: true);
  }

  CampaignChapter get currentChapter => CampaignChapter.forWave(_wave);

  void _damagePlayer() {
    if (_playerInvulnerable > 0 || _gameOver) return;
    if (_shieldCharges > 0) {
      _shieldCharges--;
      _playerInvulnerable = .75;
      _shieldPulse = .5;
      _publishHud(force: true);
      return;
    }
    _playerInvulnerable = 1.0;
    _health--;
    _enemyBolts.clear();
    if (_health <= 0) {
      _gameOver = true;
      _health = 0;
    }
    _publishHud(force: true);
  }

  bool activateSpecial() {
    if (_paused || _gameOver || _specialCooldown > 0) return false;
    final rule = SpecialAbilityRules.forDragon(dragon.id);
    _specialCooldown = rule.cooldown;
    _specialInitialClock = .76;
    _specialClock = _specialInitialClock;
    _activeSpecialId = dragon.id;
    _specialOrigin = Offset(_playerX, _playerY);
    final targets = _closestEnemies(_specialOrigin, rule.targetCount);
    switch (dragon.id) {
      case 'astralis':
        // A searching constellation: nearby stars lock onto multiple targets.
        final radius = math.max(235.0, size.x * .85);
        for (final foe in targets) {
          if (_distance(_playerX, _playerY, foe.x, foe.y) > radius) continue;
          _spellLines.add(_SpellLine(_specialOrigin,
              Offset(foe.x, foe.y), const Color(0xFF8ED9FF), 'astralis'));
          _damageTarget(foe, 3.5);
        }
        _enemyBolts.removeWhere((shot) =>
            _distance(_playerX, _playerY, shot.x, shot.y) < radius * .7);
        break;
      case 'temperstryx':
        // Dodge upwards, then bounce bright lightning between nearby foes.
        _dashOrigin = _specialOrigin;
        _playerY = math.max(math.min(57.0, size.y / 2), _playerY - 105).toDouble();
        _targetY = _playerY;
        _playerInvulnerable = math.max(_playerInvulnerable, 1.6).toDouble();
        var from = Offset(_playerX, _playerY);
        _spellLines.add(_SpellLine(_dashOrigin, from,
            const Color(0xFFB394FF), 'temperstryx', life: .8));
        for (final foe in targets) {
          _spellLines.add(_SpellLine(from,
              Offset(foe.x, foe.y), const Color(0xFFDCC5FF),
              'temperstryx', life: .7));
          from = Offset(foe.x, foe.y);
          _damageTarget(foe, 3.3);
        }
        break;
      case 'ignivar':
        // Six living dragonfire wisps seek enemies like enchanted breath.
        for (var i = 0; i < rule.targetCount; i++) {
          _seekingFlames.add(_SeekingFlame(
            _playerX + (i - 2.5) * 7,
            _playerY - 30,
            targets.isEmpty ? null : targets[i % targets.length],
            i,
          ));
        }
        break;
      case 'nyxariel':
        // Leave a hostile void rift while shifting out of incoming fire.
        final near = targets.isNotEmpty ? targets.first : null;
        final direction = near == null || near.x < _playerX ? 1.0 : -1.0;
        _playerX = (_playerX + direction * 75)
            .clamp(30.0, size.x - 30.0).toDouble();
        _targetX = _playerX;
        _playerInvulnerable = math.max(_playerInvulnerable, 2.1).toDouble();
        _spellZone = _SpellZone('nyxariel',
            near == null ? Offset(_specialOrigin.dx, _playerY - 125) :
                Offset(near.x, near.y),
            115, rule.effectSeconds);
        _spellLines.add(_SpellLine(_specialOrigin,
            Offset(_playerX, _playerY), const Color(0xFFD185FF), 'nyxariel'));
        break;
      case 'solarion':
        // Actual delayed sunstrikes track marked enemies before impact.
        for (var i = 0; i < targets.length; i++) {
          final foe = targets[i];
          _solarMarks.add(_SolarMark(
              foe, Offset(foe.x, foe.y), .36 + i * .11));
        }
        if (targets.isEmpty) {
          _solarMarks.add(_SolarMark(null,
              Offset(_playerX, math.max(90, _playerY - 170).toDouble()), .4));
        }
        break;
      case 'aquaryth':
        // A persistent moving current controls an enemy cluster.
        final anchor = targets.isEmpty ? Offset(_playerX, _playerY - 155) :
            Offset(targets.first.x, targets.first.y);
        _spellZone = _SpellZone('aquaryth', anchor, 128,
            rule.effectSeconds);
        break;
      default:
        break;
    }
    _publishHud(force: true);
    return true;
  }

  List<_Foe> _closestEnemies(Offset center, int limit) {
    final result = <_Foe>[..._foes];
    if (_boss != null) result.add(_boss!);
    result.sort((a, b) {
      final da = _distance(center.dx, center.dy, a.x, a.y);
      final db = _distance(center.dx, center.dy, b.x, b.y);
      return da.compareTo(db);
    });
    return result.take(limit).toList();
  }

  void _damageTarget(_Foe foe, double amount) {
    if (identical(foe, _boss)) {
      foe.hp -= amount;
    } else if (_foes.contains(foe)) {
      foe.hp -= amount;
      if (foe.hp <= 0) _defeatFoe(foe);
    }
  }

  void _defeatFoe(_Foe foe) {
    if (!_foes.remove(foe)) return;
    _defeatedThisWave++;
    _score += 100;
    if (_defeatGlimmers.length < 12) {
      _defeatGlimmers.add(_DefeatGlimmer(Offset(foe.x, foe.y),
          const [Color(0xFFC2A5DB), Color(0xFFAAE2E9),
            Color(0xFFBE91DC)][foe.typeIndex.clamp(0, 2).toInt()]));
    }
    if (_pickups.length < 3 &&
        (_defeatedThisWave % 6 == 0 || _random.nextDouble() < .13)) {
      _pickups.add(_Pickup(foe.x, foe.y,
          _PickupKind.values[_random.nextInt(_PickupKind.values.length)]));
    }
  }

  void _collectPickup(_PickupKind kind) {
    switch (kind) {
      case _PickupKind.haste:
        _hasteRemaining = 7;
        break;
      case _PickupKind.critical:
        _critRemaining = 8;
        break;
      case _PickupKind.shield:
        _shieldCharges = math.min(2, _shieldCharges + 1);
        _shieldRemaining = 14;
        _shieldPulse = .55;
        break;
    }
    _publishHud(force: true);
  }

  void _updateSpecialsAndPickups(double step) {
    _fxTime += step;
    _hasteRemaining = math.max(0.0, _hasteRemaining - step).toDouble();
    _critRemaining = math.max(0.0, _critRemaining - step).toDouble();
    _shieldRemaining = math.max(0.0, _shieldRemaining - step).toDouble();
    _shieldPulse = math.max(0.0, _shieldPulse - step).toDouble();
    if (_shieldRemaining <= 0) _shieldCharges = 0;

    for (final trace in _spellLines) {
      trace.life -= step;
    }
    _spellLines.removeWhere((trace) => trace.life <= 0);

    for (final flame in _seekingFlames.toList()) {
      flame.life -= step;
      if (flame.life <= 0) {
        _seekingFlames.remove(flame);
        continue;
      }
      if (flame.target == null ||
          (!identical(flame.target, _boss) &&
              !_foes.contains(flame.target))) {
        final nearest = _closestEnemies(Offset(flame.x, flame.y), 1);
        flame.target = nearest.isEmpty ? null : nearest.first;
      }
      flame.previous = Offset(flame.x, flame.y);
      final foe = flame.target;
      if (foe == null) {
        flame.y -= 330 * step;
      } else {
        final distance = _distance(flame.x, flame.y, foe.x, foe.y);
        final move = math.min(distance, (365 + flame.seed * 10) * step);
        if (distance > 0) {
          flame.x += (foe.x - flame.x) / distance * move;
          flame.y += (foe.y - flame.y) / distance * move;
        }
        if (distance <= move + foe.radius + 10) {
          final center = Offset(foe.x, foe.y);
          _damageTarget(foe, 4.3);
          for (final other in _foes.toList()) {
            if (_distance(other.x, other.y, center.dx, center.dy) < 32) {
              _damageTarget(other, 1.2);
            }
          }
          _spellLines.add(_SpellLine(center.translate(-12, 0),
              center.translate(12, 0), const Color(0xFFFFA34E),
              'ignivar', life: .3));
          _seekingFlames.remove(flame);
        }
      }
      if (flame.y < -20) _seekingFlames.remove(flame);
    }

    for (final mark in _solarMarks.toList()) {
      final target = mark.target;
      if (target != null &&
          (identical(target, _boss) || _foes.contains(target))) {
        mark.position = Offset(target.x, target.y);
      }
      mark.delay -= step;
      if (mark.delay > 0) continue;
      final center = mark.position;
      for (final foe in _closestEnemies(center, 30).toList()) {
        if (_distance(foe.x, foe.y, center.dx, center.dy) < 62) {
          _damageTarget(foe, identical(foe, target) ? 6.5 : 2.2);
        }
      }
      _enemyBolts.removeWhere((shot) =>
          _distance(shot.x, shot.y, center.dx, center.dy) < 52);
      _spellLines.add(_SpellLine(Offset(center.dx, -10), center,
          const Color(0xFFFFCE68), 'solarion', life: .5));
      _solarMarks.remove(mark);
    }

    if (_spellZone case final zone?) {
      zone.life -= step;
      zone.pulse += step;
      // Pull lightly; enemies remain controllable/readable and are never
      // teleported directly onto the player.
      for (final foe in _foes) {
        if (_distance(foe.x, foe.y, zone.center.dx, zone.center.dy) <
            zone.radius * 1.2) {
          foe.x += (zone.center.dx - foe.x) * .58 * step;
          foe.y += (zone.center.dy - foe.y) * .37 * step;
        }
      }
      if (zone.pulse >= .3) {
        zone.pulse -= .3;
        for (final foe in _closestEnemies(zone.center, 30).toList()) {
          if (_distance(foe.x, foe.y, zone.center.dx, zone.center.dy) <
              zone.radius) {
            _damageTarget(foe, zone.kind == 'aquaryth' ? .8 : 1.2);
          }
        }
        _enemyBolts.removeWhere((shot) =>
            _distance(shot.x, shot.y, zone.center.dx, zone.center.dy) <
            zone.radius * .58);
      }
      if (zone.life <= 0) _spellZone = null;
    }

    for (final pickup in _pickups.toList()) {
      pickup.age += step;
      pickup.y += 45 * step;
      pickup.x += math.sin(_fxTime * 2.5 + pickup.y * .03) * 10 * step;
      if (_distance(_playerX, _playerY, pickup.x, pickup.y) < 29) {
        _collectPickup(pickup.kind);
        _pickups.remove(pickup);
      } else if (pickup.age > 10 || pickup.y > size.y + 25) {
        _pickups.remove(pickup);
      }
    }
  }

  double get specialCooldownRemaining => _specialCooldown;

  void restartGame() {
    _developerShowcase = false;
    _bolts.clear();
    _enemyBolts.clear();
    _foes.clear();
    _defeatGlimmers.clear();
    _waveBannerRemaining = 1.6;
    _boss = null;
    _spellLines.clear();
    _seekingFlames.clear();
    _solarMarks.clear();
    _pickups.clear();
    _spellZone = null;
    _hasteRemaining = 0;
    _critRemaining = 0;
    _shieldRemaining = 0;
    _shieldCharges = 0;
    _shieldPulse = 0;
    _campaignIntermission = false;
    _campaignComplete = false;
    _score = 0;
    _wave = 1;
    _health = 3;
    _spawnedThisWave = 0;
    _defeatedThisWave = 0;
    _fireClock = 0;
    _spawnClock = 0;
    _hudClock = 0;
    _waveElapsed = 0;
    _playerInvulnerable = 0;
    _bossAttackClock = 0;
    _specialCooldown = 0;
    _specialClock = 0;
    _wingMotionSeconds = 0;
    _flightClock = 0;
    _flightFrame = 0;
    _flightBank = 0;
    _paused = false;
    _gameOver = false;
    _touching = false;
    if (size.x > 0 && size.y > 0) {
      _playerX = size.x / 2;
      _playerY = size.y * .78;
      _targetX = _playerX;
      _targetY = _playerY;
    }
    _publishHud(force: true);
  }

  // Run 35 tester hooks. The UI exposes these only when explicitly compiled
  // with --dart-define=DL_DEV_TOOLS=true; normal player UI never shows them.
  void developerSetPanelOpen(bool open) {
    _developerPanelOpen = open;
    if (open) _touching = false;
  }

  String get developerSnapshot =>
      'Dragon ${dragon.name}  •  Wave $_wave  •  Hull $_health\n'
      'Score $_score  •  Enemies ${_foes.length}  •  '
      'Boss ${_boss == null ? "NO" : "YES"}  •  '
      'Power ${_specialCooldown <= 0 ? "READY" : "COOLDOWN"}';

  void developerJumpToWave(int requestedWave, {bool boss = false}) {
    if (size.x <= 0 || size.y <= 0) return;
    // A fully reproducible level test. This is not a save-game operation.
    restartGame();
    _wave = requestedWave.clamp(1, CampaignChapter.finalWave).toInt();
    if (boss) {
      _wave = (((_wave - 1) ~/ 5) + 1) * 5;
      _spawnedThisWave = 7 + _wave * 2;
      _boss = _Foe(
        x: size.x / 2,
        y: size.y * .22,
        hp: 20 + _wave * 4,
        radius: 34,
        speed: 48,
        boss: true,
      );
    }
    _paused = false;
    _waveBannerRemaining = 1.6;
    _publishHud(force: true);
  }

  void developerClearArena() {
    _developerShowcase = true;
    _foes.clear();
    _enemyBolts.clear();
    _bolts.clear();
    _boss = null;
    _paused = false;
    _campaignIntermission = false;
    _campaignComplete = false;
    _gameOver = false;
    _health = 3;
    _publishHud(force: true);
  }

  void developerEnemyGallery() {
    if (size.x <= 0 || size.y <= 0) return;
    developerClearArena();
    for (var type = 0; type < 3; type++) {
      _foes.add(_Foe(
        x: size.x * (type + 1) / 4,
        y: size.y * (.23 + type * .035),
        hp: 60,
        radius: [15.0, 17.0, 19.0][type],
        speed: 0,
        typeIndex: type,
        spriteSize: [64.0, 72.0, 82.0][type],
      ));
    }
    _publishHud(force: true);
  }

  void developerForceAbilityReady() {
    _specialCooldown = 0;
    _publishHud(force: true);
  }

  void developerGrantBoost(String kind, {bool drop = false}) {
    final pickup = switch (kind) {
      'haste' => _PickupKind.haste,
      'critical' => _PickupKind.critical,
      'shield' => _PickupKind.shield,
      _ => null,
    };
    if (pickup == null) return;
    if (drop && size.y > 0) {
      _pickups.add(_Pickup(_playerX,
          math.max(65.0, _playerY - 85).toDouble(), pickup));
    } else {
      _collectPickup(pickup);
    }
  }

  void developerTestDamage() {
    _playerInvulnerable = 0;
    _damagePlayer();
  }

  void developerNextWave() {
    _foes.clear();
    _enemyBolts.clear();
    _bolts.clear();
    _boss = null;
    _developerShowcase = false;
    _paused = false;
    _gameOver = false;
    _health = math.max(_health, 1);
    _advanceWave();
    _publishHud(force: true);
  }

  void developerHeal() {
    _health = 3;
    _gameOver = false;
    _playerInvulnerable = 1.5;
    _publishHud(force: true);
  }

  void developerSpawnEnemy(int typeIndex) {
    if (typeIndex < 0 || typeIndex > 2 || size.x <= 0) return;
    _foes.add(_Foe(
      x: size.x / 2,
      y: 100,
      hp: 5,
      radius: [15.0, 17.0, 19.0][typeIndex],
      speed: 20,
      typeIndex: typeIndex,
      spriteSize: [64.0, 72.0, 82.0][typeIndex],
    ));
  }

  double _distance(double ax, double ay, double bx, double by) =>
      math.sqrt(math.pow(ax - bx, 2) + math.pow(ay - by, 2));

  void _publishHud({bool force = false}) {
    final next = DragonHudState(
        score: _score,
        wave: _wave,
        health: _health,
        paused: _paused,
        bossActive: _boss != null,
        dragonName: dragon.name,
        specialRemaining: _specialCooldown,
        specialMax: SpecialAbilityRules.forDragon(dragon.id).cooldown,
        hasteRemaining: _hasteRemaining,
        critRemaining: _critRemaining,
        shields: _shieldCharges,
        campaignMode: campaignMode,
        campaignIntermission: _campaignIntermission,
        campaignComplete: _campaignComplete,
        chapterTitle: currentChapter.title);
    if (force ||
        next.score != hud.value.score ||
        next.wave != hud.value.wave ||
        next.health != hud.value.health ||
        next.paused != hud.value.paused ||
        next.bossActive != hud.value.bossActive ||
        next.dragonName != hud.value.dragonName ||
        (next.specialRemaining - hud.value.specialRemaining).abs() > .09 ||
        next.shields != hud.value.shields ||
        (next.hasteRemaining - hud.value.hasteRemaining).abs() > .09 ||
        (next.critRemaining - hud.value.critRemaining).abs() > .09 ||
        next.campaignMode != hud.value.campaignMode ||
        next.campaignIntermission != hud.value.campaignIntermission ||
        next.campaignComplete != hud.value.campaignComplete) {
      hud.value = next;
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    _drawStars(canvas);
    for (final glimmer in _defeatGlimmers) {
      final fade = (1 - glimmer.age / _DefeatGlimmer.duration)
          .clamp(0.0, 1.0).toDouble();
      for (var i = 0; i < 4; i++) {
        final angle = i * math.pi / 2 + glimmer.center.dx * .012;
        final reach = 6 + glimmer.age * 32;
        final mote = Offset(glimmer.center.dx + math.cos(angle) * reach,
            glimmer.center.dy + math.sin(angle) * reach);
        canvas.drawCircle(mote, 1.7 * fade,
            Paint()..color = glimmer.tint.withOpacity(fade * .48));
      }
    }
    _drawSpecialEffects(canvas, behind: true);
    final player = Paint()..color = dragon.palette;
    final gold = Paint()..color = const Color(0xFFFFD77A);
    final white = Paint()..color = Colors.white;
    final red = Paint()..color = const Color(0xFFFF667E);

    for (final bolt in _bolts) {
      if (_run32PlayerBoltFrames.isNotEmpty) {
        final frame = _run32PlayerBoltFrames[
            _flightFrame % _run32PlayerBoltFrames.length];
        canvas.drawImageRect(
          frame,
          Rect.fromLTWH(0, 0, frame.width.toDouble(), frame.height.toDouble()),
          Rect.fromCenter(center: Offset(bolt.x, bolt.y), width: 16, height: 28),
          Paint()..filterQuality = FilterQuality.medium,
        );
      } else {
        canvas.drawRRect(
            RRect.fromRectAndRadius(
                Rect.fromCenter(
                    center: Offset(bolt.x, bolt.y), width: 4, height: 18),
                const Radius.circular(3)),
            gold);
      }
    }
    for (final shot in _enemyBolts) {
      if (_run32EnemyBoltFrames.isNotEmpty) {
        final frame = _run32EnemyBoltFrames[
            _flightFrame % _run32EnemyBoltFrames.length];
        canvas.drawImageRect(
          frame,
          Rect.fromLTWH(0, 0, frame.width.toDouble(), frame.height.toDouble()),
          Rect.fromCenter(center: Offset(shot.x, shot.y), width: 22, height: 22),
          Paint()..filterQuality = FilterQuality.medium,
        );
      } else {
        canvas.drawCircle(Offset(shot.x, shot.y), 5,
            Paint()..color = const Color(0xFFFF7895));
        canvas.drawCircle(
            Offset(shot.x, shot.y),
            9,
            Paint()
              ..color = const Color(0x55FF7895)
              ..style = PaintingStyle.stroke);
      }
    }
    for (final foe in _foes) {
      if (foe.typeIndex >= 0 && foe.typeIndex < _enemyFrames.length &&
          _enemyFrames[foe.typeIndex].isNotEmpty) {
        final frames = _enemyFrames[foe.typeIndex];
        final frame = frames[foe.animationFrame % frames.length];
        // Subtle motion synchronized with the illustrated wings. Previously
        // the separate rapid 3% squash/stretch visibly fought the frames.
        final phase = 2 * math.pi * (foe.animationFrame +
            foe.animationClock / .1) / frames.length;
        final wingbeat = math.sin(phase);
        canvas.save();
        canvas.translate(foe.x, foe.y + wingbeat * .65);
        canvas.rotate(math.sin(_fxTime * 1.4 + foe.y * .02) * .012);
        canvas.scale(1 + wingbeat * .007, 1 - wingbeat * .009);
        canvas.drawImageRect(
          frame,
          Rect.fromLTWH(0, 0, frame.width.toDouble(), frame.height.toDouble()),
          Rect.fromCenter(
            center: Offset.zero,
            width: foe.spriteSize,
            height: foe.spriteSize,
          ),
          Paint()..filterQuality = FilterQuality.high,
        );
        canvas.restore();
      } else {
        canvas.drawCircle(Offset(foe.x, foe.y), foe.radius, red);
        canvas.drawCircle(
            Offset(foe.x, foe.y),
            foe.radius + 4,
            Paint()
              ..color = red.color.withOpacity(.18)
              ..style = PaintingStyle.stroke);
      }
    }
    if (_boss case final boss?) {
      final chapterHue = const [
        Color(0xFF84C8FA), Color(0xFFFF865A), Color(0xFFC48AF3),
        Color(0xFF70E5E9), Color(0xFFFFDE88),
      ][((_wave - 1) ~/ 5).clamp(0, 4).toInt()];
      canvas.drawCircle(Offset(boss.x, boss.y), boss.radius + 31,
          Paint()..color = chapterHue.withOpacity(.13));
      canvas.drawArc(Rect.fromCircle(center: Offset(boss.x, boss.y),
          radius: boss.radius + 25), _fxTime * 1.1, 4.5, false,
          Paint()..color = chapterHue.withOpacity(.65)
            ..strokeWidth = 3..style = PaintingStyle.stroke);
      if (_run31BossImage case final bossArt?) {
        canvas.drawImageRect(
          bossArt,
          Rect.fromLTWH(0, 0, bossArt.width.toDouble(), bossArt.height.toDouble()),
          Rect.fromCenter(
            center: Offset(boss.x, boss.y),
            width: 126,
            height: 96,
          ),
          Paint()..filterQuality = FilterQuality.medium,
        );
      } else {
        canvas.drawCircle(Offset(boss.x, boss.y), boss.radius + 8,
            Paint()..color = const Color(0xFFFF5577).withOpacity(.18));
        canvas.drawCircle(Offset(boss.x, boss.y), boss.radius, red);
      }
      final bar = Rect.fromLTWH(size.x * .2, 54, size.x * .6, 7);
      canvas.drawRRect(RRect.fromRectAndRadius(bar, const Radius.circular(4)),
          white..color = const Color(0xFF482638));
      final ratio = (boss.hp / (20 + _wave * 4)).clamp(0.0, 1.0).toDouble();
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(bar.left, bar.top, bar.width * ratio, bar.height),
              const Radius.circular(4)),
          red);
    }
    // Spell work is vector-drawn to fit the battlefield; giant pre-rendered
    // ability pictures previously obscured the dragons and are no longer used.
    _drawSpecialEffects(canvas, behind: false);
    // Preserve the existing animated ASTRALIS sprite and vector fallback.
    final path = Path()
      ..moveTo(_playerX, _playerY - 22)
      ..quadraticBezierTo(_playerX + 22, _playerY + 5, _playerX, _playerY + 15)
      ..quadraticBezierTo(_playerX - 22, _playerY + 5, _playerX, _playerY - 22)
      ..close();
    if (_playerInvulnerable <= 0 || (_playerInvulnerable * 12).floor().isEven) {
      if (dragon.id == 'astralis' && _flightFrames.isNotEmpty) {
        final frame = _flightFrames[_flightFrame];
        canvas.drawImageRect(
          frame,
          Rect.fromLTWH(0, 0, frame.width.toDouble(), frame.height.toDouble()),
          Rect.fromCenter(
            center: Offset(_playerX, _playerY),
            width: 86,
            height: 114,
          ),
          Paint()..filterQuality = FilterQuality.high,
        );
      } else if (_run32DragonFlights[dragon.id] case final frames?) {
        // Match ASTRALIS exactly: 8 frames, 0.1 s each, identical on-screen
        // dimensions, no additional rotation or bobbing of just these five.
        // The fallback four-frame sprites use their original six-step cycle.
        final index = frames.length == 8
            ? _flightFrame
            : DragonFlightCycle.fourPoseFrameAt(_wingMotionSeconds);
        final frame = frames[index % frames.length];
        canvas.drawImageRect(
          frame,
          Rect.fromLTWH(0, 0, frame.width.toDouble(), frame.height.toDouble()),
          Rect.fromCenter(
            center: Offset(_playerX, _playerY),
            width: 86,
            height: 114,
          ),
          Paint()..filterQuality = FilterQuality.high,
        );
      } else if (_run31DragonStills[dragon.id] case final dragonArt?) {
        canvas.drawImageRect(
          dragonArt,
          Rect.fromLTWH(
              0, 0, dragonArt.width.toDouble(), dragonArt.height.toDouble()),
          Rect.fromCenter(
            center: Offset(_playerX, _playerY),
            width: 90,
            height: 108,
          ),
          Paint()..filterQuality = FilterQuality.high,
        );
      } else {
        canvas.drawPath(path, player);
      }
    } else {
      canvas.drawPath(path, Paint()..color = const Color(0x88FFFFFF));
    }
    if (_playerInvulnerable > 0) {
      canvas.drawCircle(
          Offset(_playerX, _playerY),
          25,
          Paint()
            ..color = const Color(0x665CCFFF)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2);
    }
    if (_shieldCharges > 0) {
      final shieldColor = const Color(0xFF69E3FF)
          .withOpacity(.55 + _shieldPulse * .6);
      canvas.drawCircle(Offset(_playerX, _playerY), 46,
          Paint()..color = shieldColor.withOpacity(.13));
      canvas.drawCircle(Offset(_playerX, _playerY), 46,
          Paint()..color = shieldColor
            ..style = PaintingStyle.stroke..strokeWidth = 2.4);
      canvas.drawArc(Rect.fromCircle(
          center: Offset(_playerX, _playerY), radius: 51),
          -_fxTime * 2.4, 1.4, false,
          Paint()..color = const Color(0xFFBDF7FF)
            ..style = PaintingStyle.stroke..strokeWidth = 2.0);
    }
    canvas.drawCircle(Offset(_playerX, _playerY - 2), 4, gold);
    if (_waveBannerRemaining > 0 && !_gameOver && !_paused) {
      final fade = (_waveBannerRemaining / .5).clamp(0.0, 1.0).toDouble();
      final headline = campaignMode
          ? 'CHAPTER ${currentChapter.number}  •  WAVE $_wave'
          : 'WAVE $_wave';
      final text = TextPainter(
        text: TextSpan(text: headline,
            style: TextStyle(color: const Color(0xFFFFDE9C)
                .withOpacity(fade * .82), letterSpacing: 2.2,
                fontSize: 14, fontWeight: FontWeight.bold)),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: size.x);
      text.paint(canvas, Offset((size.x - text.width) / 2, size.y * .13));
    }
    if (_paused || _gameOver) {
      final overlay = Paint()..color = const Color(0xBB050817);
      canvas.drawRect(Offset.zero & Size(size.x, size.y), overlay);
      final text = TextPainter(
        text: TextSpan(
            text: _gameOver ? 'FLIGHT ENDED' : 'PAUSED',
            style: const TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
                letterSpacing: 3)),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: size.x);
      text.paint(canvas, Offset((size.x - text.width) / 2, size.y * .46));
      if (_gameOver) {
        final hint = TextPainter(
          text: const TextSpan(
              text: 'Tap FLY AGAIN to restart',
              style: TextStyle(color: Color(0xFF9CC7D8), fontSize: 12)),
          textDirection: TextDirection.ltr,
        )..layout(maxWidth: size.x);
        hint.paint(
            canvas, Offset((size.x - hint.width) / 2, size.y * .46 + 42));
      }
    }
  }

  void _drawSpecialEffects(Canvas canvas, {required bool behind}) {
    if (behind) {
      // Different spell circles occupy enemy space, never the entire screen.
      if (_spellZone case final zone?) {
        final aqua = zone.kind == 'aquaryth';
        final hue = aqua ? const Color(0xFF54EAE7)
            : const Color(0xFFC18BFF);
        final opacity = (zone.life / zone.initialLife)
            .clamp(0.0, 1.0).toDouble();
        canvas.drawCircle(zone.center, zone.radius,
            Paint()..color = hue.withOpacity(.10 * opacity));
        for (var i = 0; i < 3; i++) {
          final radius = zone.radius * (.38 + i * .24);
          canvas.drawArc(Rect.fromCircle(center: zone.center, radius: radius),
              _fxTime * (aqua ? 1.8 : -2.3) + i * 2.2,
              aqua ? 3.2 : 2.4, false,
              Paint()..color = hue.withOpacity((.48 - i * .08) * opacity)
                ..style = PaintingStyle.stroke..strokeWidth = 2.4);
        }
        if (!aqua) {
          canvas.drawCircle(zone.center, 15 + math.sin(_fxTime * 12) * 2,
              Paint()..color = const Color(0xBB4D1A80));
        }
      }
      for (final mark in _solarMarks) {
        final radius = 31 + math.sin(_fxTime * 10) * 2;
        canvas.drawCircle(mark.position, radius,
            Paint()..color = const Color(0x99FFBC4A)
              ..style = PaintingStyle.stroke..strokeWidth = 2.2);
        canvas.drawCircle(mark.position, 7,
            Paint()..color = const Color(0xAAFFF1B5));
      }
      if (_specialClock > 0 && _activeSpecialId == 'astralis') {
        final progress = 1 - _specialClock / _specialInitialClock;
        canvas.drawCircle(_specialOrigin, 25 + progress * size.x * .4,
            Paint()..color = const Color(0xFF9AD9FF)
              .withOpacity((1 - progress) * .75)
              ..style = PaintingStyle.stroke..strokeWidth = 3);
      }
      for (final pickup in _pickups) {
        final center = Offset(pickup.x, pickup.y);
        final color = switch (pickup.kind) {
          _PickupKind.haste => const Color(0xFF72EAF1),
          _PickupKind.critical => const Color(0xFFFFCE5D),
          _PickupKind.shield => const Color(0xFF79AFFF),
        };
        final pulse = 1 + math.sin(_fxTime * 5 + pickup.age) * .12;
        canvas.drawCircle(center, 17 * pulse,
            Paint()..color = color.withOpacity(.18));
        canvas.drawCircle(center, 13 * pulse,
            Paint()..color = color.withOpacity(.8)
              ..style = PaintingStyle.stroke..strokeWidth = 1.9);
        if (pickup.kind == _PickupKind.shield) {
          canvas.drawCircle(center, 7, Paint()..color = color);
        } else {
          final glyph = Path()
            ..moveTo(center.dx - 6, center.dy + 8)
            ..lineTo(center.dx + 1, center.dy - 8)
            ..lineTo(center.dx + 6, center.dy - 1)
            ..lineTo(center.dx - 1, center.dy + 8)
            ..close();
          canvas.drawPath(glyph, Paint()..color = color);
        }
      }
      return;
    }
    for (final line in _spellLines) {
      final fade = (line.life / line.initialLife).clamp(0.0, 1.0).toDouble();
      final base = Paint()..color = line.color.withOpacity(.16 * fade)
          ..strokeWidth = line.kind == 'solarion' ? 20 : 12
          ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
      final bright = Paint()..color = line.color.withOpacity(fade)
          ..strokeWidth = line.kind == 'solarion' ? 4.5 : 2.8
          ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
      final path = Path()..moveTo(line.from.dx, line.from.dy);
      if (line.kind == 'temperstryx') {
        final midpoint = Offset((line.from.dx + line.to.dx) / 2,
            (line.from.dy + line.to.dy) / 2);
        path.lineTo(midpoint.dx + math.sin(_fxTime * 24) * 13,
            midpoint.dy - 8);
      }
      path.lineTo(line.to.dx, line.to.dy);
      canvas.drawPath(path, base);
      canvas.drawPath(path, bright);
      canvas.drawCircle(line.to,
          line.kind == 'solarion' ? 18 * fade : 7 * fade,
          Paint()..color = line.color.withOpacity(.45 * fade));
    }
    // Animated plumes of dragonfire: flowing magic that bends toward foes.
    for (final flame in _seekingFlames) {
      final center = Offset(flame.x, flame.y);
      final tail = flame.previous;
      final glow = Paint()..color = const Color(0x77FF5C26)
        ..strokeWidth = 15..strokeCap = StrokeCap.round;
      canvas.drawLine(tail, center, glow);
      final flicker = 7.0 + math.sin(_fxTime * 23 + flame.seed) * 3;
      canvas.drawCircle(center, flicker + 5,
          Paint()..color = const Color(0x55FF7133));
      canvas.drawCircle(center, flicker,
          Paint()..color = const Color(0xFFFF842E));
      canvas.drawCircle(center.translate(0, -3), flicker * .44,
          Paint()..color = const Color(0xFFFFE7A1));
    }
  }

  void _drawStars(Canvas canvas) {
    final bounds = Offset.zero & Size(size.x, size.y);
    if (_battlefieldArt case final scene?) {
      // Cropped cover preserves artwork proportions on any portrait phone.
      final scale = math.max(size.x / scene.width, size.y / scene.height);
      final sourceWidth = size.x / scale;
      final sourceHeight = size.y / scale;
      final src = Rect.fromCenter(
        center: Offset(scene.width / 2, scene.height / 2),
        width: sourceWidth, height: sourceHeight,
      );
      canvas.drawImageRect(scene, src, bounds,
          Paint()..filterQuality = FilterQuality.medium);
      canvas.drawRect(bounds, Paint()..color = const Color(0x16030920));
      // Sparse moving motes give depth without obscuring the battlefield.
      final mote = Paint()..color = const Color(0x77BADDF7);
      for (var i = 0; i < 25; i++) {
        final x = (i * 97.0 + 21) % math.max(1.0, size.x);
        final y = (i * 163.0 + _waveElapsed * (9 + i % 4 * 3)) %
            math.max(1.0, size.y);
        canvas.drawCircle(Offset(x, y), i % 7 == 0 ? 1.1 : .55, mote);
      }
      return;
    }
    canvas.drawRect(bounds, Paint()..shader = const LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter,
      colors: [Color(0xFF111E40), Color(0xFF161D3C), Color(0xFF071226)],
    ).createShader(bounds));
    // A restrained astral nebula with empty center for gameplay visibility.
    canvas.drawRect(bounds, Paint()..shader = RadialGradient(
      center: const Alignment(-.72, -.38), radius: 1.1,
      colors: [const Color(0xFF5A4686).withOpacity(.34),
        const Color(0xFF254C84).withOpacity(.08), Colors.transparent],
    ).createShader(bounds));
    canvas.drawRect(bounds, Paint()..shader = RadialGradient(
      center: const Alignment(.9, .2), radius: .9,
      colors: [const Color(0xFF236E81).withOpacity(.22), Colors.transparent],
    ).createShader(bounds));
    // Silhouettes of Lunaryvell's distant floating citadel, parallax layers.
    for (var layer = 0; layer < 2; layer++) {
      final depth = layer == 0 ? .20 : .12;
      final floor = size.y * (layer == 0 ? .94 : .99);
      final color = layer == 0 ? const Color(0x88203057)
          : const Color(0xCC101931);
      final path = Path()..moveTo(0, size.y)
        ..lineTo(0, floor - size.y * depth * .8);
      for (var i = 0; i < 8; i++) {
        final x = i * size.x / 7;
        final height = (i % 3 + 1) * size.y * depth / 3;
        path
          ..lineTo(x - 10, floor)
          ..lineTo(x - 7, floor - height)
          ..lineTo(x, floor - height - 14)
          ..lineTo(x + 7, floor - height)
          ..lineTo(x + 10, floor);
      }
      path..lineTo(size.x, size.y)..close();
      canvas.drawPath(path, Paint()..color = color);
    }
    final paint = Paint()..color = const Color(0xFFB6D6FF).withOpacity(.55);
    for (var i = 0; i < 68; i++) {
      final x = (i * 73.0) % math.max(1.0, size.x).toDouble();
      final y = ((i * 131.0) + _waveElapsed * (12 + i % 4 * 5)) %
          math.max(1.0, size.y).toDouble();
      canvas.drawCircle(Offset(x, y), i % 9 == 0 ? 1.5 : .65, paint);
    }
  }
}
