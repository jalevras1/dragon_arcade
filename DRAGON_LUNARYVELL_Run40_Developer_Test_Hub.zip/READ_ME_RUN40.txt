DRAGON LUNARYVELL RUN 40 - MOBILE DEVELOPER TEST HUB

This single ZIP safely accepts EITHER completed Run 38 OR Run 39 as a
starting point. If Run 39 has NOT been installed yet, skip it: Run 40 also
includes the Run 39 full-field movement, transparent HUD and startup fix.
Your 62 premium dragon/enemy frames and both scenes remain unchanged.

STEP 1 - Upload THIS ZIP to your usual branch and tap Commit changes:
https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs

STEP 2 - In the SAME Codespaces terminal paste exactly ONE command:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run40_Developer_Test_Hub.zip && python3 run40_install.py

STEP 3 - After RUN 40 COMPLETE, refresh the SAME port 8765 game preview.

IN THE GAME: Tap the blue/gold DEV button near the upper right.
It remains available during play, pause, chapter gates and game over.
The game freezes safely while its scrollable phone-friendly menu is open.

DEV HUB FUNCTIONS:
- Jump directly to title, arcade, campaign, dragon selection, how-to or about.
- Review current dragon, wave, score, enemy and cooldown status.
- Isolate all three enemy animations in a stable showcase.
- Clear arena to inspect 2D scenery and sprites.
- Demonstrate a dragon's special with enemy targets, or reset its cooldown.
- Spawn each enemy, grant or drop each haste/critical/shield pickup.
- Select ANY wave 1-25 and jump instantly, or preview that chapter's boss.
- Heal, damage, pause, advance wave or restart without terminal commands.
- DEV controls do not appear in a release compiled without DL_DEV_TOOLS=true.

SAFETY: Every modified file is accepted only if its SHA256 matches exact
previous Run 38 or 39; unmatched user edits are not overwritten. Files and
the working web build are backed up. Flutter tests and release build run
automatically, with rollback on failure. The test build is marked RUN40.

If STOP or FAILED appears, send only that line rather than retrying.
