import 'dart:js_interop';

/// No external packages or voice assets: HTML Audio + Web Speech APIs already
/// provided by the browser. Every call is best-effort and never blocks play.
@JS('Audio')
extension type _HtmlAudio._(JSObject _) implements JSObject {
  external factory _HtmlAudio(String url);
  external set loop(bool value);
  external set volume(double value);
  external set currentTime(double value);
  external JSPromise<JSAny?> play();
  external void pause();
}

@JS('speechSynthesis')
external _SpeechSynth? get _speechSynthesis;

@JS('SpeechSynthesisUtterance')
extension type _SpeechUtterance._(JSObject _) implements JSObject {
  external factory _SpeechUtterance(String text);
  external set lang(String value);
  external set rate(double value);
  external set pitch(double value);
  external set volume(double value);
  external set onboundary(JSFunction? function);
  external set onend(JSFunction? function);
  external set onerror(JSFunction? function);
}

extension type _SpeechSynth._(JSObject _) implements JSObject {
  external void speak(_SpeechUtterance value);
  external void cancel();
}

extension type _SpeechEvent._(JSObject _) implements JSObject {
  external int get charIndex;
}

class Run47Audio {
  Run47Audio._();
  static final Run47Audio instance = Run47Audio._();
  bool muted = false;
  _HtmlAudio? _music;
  int _narrationEpoch = 0;
  final List<_HtmlAudio> _activeCues = [];

  bool get voiceAvailable {
    try {
      return _speechSynthesis != null;
    } catch (_) {
      return false;
    }
  }

  void start() {
    if (muted) return;
    try {
      final audio = _music ??= _HtmlAudio(
          'assets/assets/audio/run47/sky_ledger_theme.ogg');
      audio.loop = true;
      audio.volume = .27;
      // A browser may reject autoplay; the speaker button/first drag retries.
      audio.play().toDart.catchError((Object _) => null);
    } catch (_) { /* browser denied audio; keep game usable */ }
  }

  void stop() {
    try { _music?.pause(); } catch (_) {}
    stopNarration();
  }

  void toggleMute() {
    muted = !muted;
    if (muted) {
      stop();
      for (final effect in _activeCues) {
        try { effect.pause(); } catch (_) {}
      }
      _activeCues.clear();
    } else {
      start();
    }
  }

  void cue(String name) {
    if (muted) return;
    try {
      // Maximum four overlapping short cues: a phone-safe audio budget.
      if (_activeCues.length >= 4) {
        _activeCues.removeAt(0).pause();
      }
      final audio = _HtmlAudio('assets/assets/audio/run47/$name.ogg');
      audio.volume = name.startsWith('fire_') ? .13
          : name.startsWith('boss_') ? .46 : .40;
      _activeCues.add(audio);
      audio.play().toDart.catchError((Object _) => null);
    } catch (_) {}
  }

  void stopNarration() {
    _narrationEpoch++;
    try { _speechSynthesis?.cancel(); } catch (_) {}
    try { _music?.volume = .27; } catch (_) {}
  }

  void speak(String line, {void Function(int)? onBoundary,
      void Function()? onFinished, String speaker = '',
      String emotion = 'whisper'}) {
    stopNarration();
    if (muted || !voiceAvailable) {
      return;
    }
    final epoch = _narrationEpoch;
    try {
      final utterance = _SpeechUtterance(line)
        ..lang = 'en-US'
        ..rate = emotion == 'threat' ? .79 : .87
        ..pitch = emotion == 'threat' ? .73
            : speaker == 'NYXARIEL' ? .82
            : speaker == 'AQUARYTH' ? 1.13
            : speaker == 'SOLARION' ? 1.06 : .94
        ..volume = .95;
      try { _music?.volume = .11; } catch (_) {}
      utterance.onboundary = ((JSObject event) {
        if (epoch != _narrationEpoch) return;
        try { onBoundary?.call(_SpeechEvent._(event).charIndex); }
        catch (_) {}
      }).toJS;
      utterance.onend = ((JSObject _) {
        if (epoch == _narrationEpoch) {
          try { _music?.volume = .27; } catch (_) {}
          onFinished?.call();
        }
      }).toJS;
      utterance.onerror = ((JSObject _) {
        if (epoch == _narrationEpoch) {
          try { _music?.volume = .27; } catch (_) {}
          onFinished?.call();
        }
      }).toJS;
      _speechSynthesis!.speak(utterance);
    } catch (_) { onFinished?.call(); }
  }
}
