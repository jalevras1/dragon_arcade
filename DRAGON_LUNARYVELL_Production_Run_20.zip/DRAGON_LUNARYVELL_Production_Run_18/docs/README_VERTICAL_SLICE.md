# Production Run 18 — First playable vertical-slice scaffold

This is a standalone Flutter/Flame starter project, intended to be merged into or used to validate the `dragon_arcade` repository after review.

## Included prototype loop
- Portrait game surface with touch-drag flight control.
- Auto-fire and enemy spawning.
- Enemy hit points, score, player hull and game-over state.
- Finite wave quotas and wave advancement.
- Boss gate on every fifth wave, with boss health bar.
- Pause control and scrolling starfield.\n- Boss aimed three-shot fan attack.\n- One-second player damage cooldown with visible hit flash.\n- In-game restart after game over.
- HUD and one Flutter widget smoke test.

## Art status
The player and enemies are temporary vector placeholders, not approved final art and not sprite assets. They exist only to make the game loop visible and testable. Replace these drawing calls with transparent 2D sprite animations when the approved art assets are ready. No 3D content is used.

## Install / run
1. Back up or commit the existing `dragon_arcade` repository.
2. Review the files before copying; do not overwrite existing project files blindly.
3. This package contains a `pubspec.yaml` and `lib/main.dart` for a clean vertical-slice project. If merging into the existing app, merge the Flame dependency and route to this game screen rather than replacing project configuration.
4. Run `flutter pub get`, `flutter analyze`, `flutter test`, then `flutter run` on Android.

## Known limitations / next fixes
- This is a playable mechanics scaffold, not a production-ready game.
- The game over state currently asks for app restart; add a proper in-game restart/menu flow.
- The boss has no attack/projectile pattern yet.
- Dragon selection and the six unique abilities are not wired into this vertical slice.
- Save/load, shop, upgrades, audio, accessibility and sprite animation integration remain future integration work.
- The HUD is intentionally minimal and uses temporary vector shapes.
- Compile and test with the user's Flutter SDK before considering this code validated. The production workspace has no Flutter/Dart SDK, so no Dart compilation or Flutter tests were run here.

\n## Production Run 19 changes
- Added a boss three-projectile aimed fan attack.
- Added hostile projectile movement, bounds cleanup and player collision.
- Added a one-second damage-invulnerability window to prevent frame-by-frame health loss.
- Added a visible temporary shield flash during invulnerability.
- Added a FLY AGAIN control that resets the active run without restarting the app.
- Removed use of Flutter's newer `Color.withValues` API from the HUD text styling.
- Corrected starfield modulo operands to remain double-valued.

## Validation status
The archive is structurally reviewed and ZIP-tested. Flutter formatting, analyzer, widget tests, web build and Android build have **not** been run because this production workspace does not contain the Flutter SDK or the user's live Codespace. Run the verification script from the integrated project before treating this as device-ready.

\n## Production Run 20: stability repair and dragon combat profiles
- Repaired malformed escaped-newline source and removed an accidental render-only block from the game update loop found during source review of Run19.
- Ensured hostile projectile collection/type exists and player damage cooldown is enforced.
- Added the six approved dragon profile definitions with identity, title, palette tint, play style, ability and 1–5 stat profile.
- Added a callable special-ability gameplay hook with a 12-second cooldown. Lightning/Phantom grant a temporary phase window; other dragons damage nearby enemies and the boss.
- Added roster tests for all six identities, unique abilities and bounded stats.

Important: these checks are source-level only. No Flutter SDK is present in this packaging environment, so Dart formatting, analyzer, Flutter tests and Android build still require execution in the live Codespace.

- Added a visible special-ability control and selected-dragon HUD label.
