# Run 19 integration and verification checklist

1. Commit or back up the current `dragon_arcade` repository.
2. Merge the `pubspec.yaml` Flame dependency rather than blindly replacing the repository manifest.
3. Copy `lib/main.dart` and `lib/game/dragon_lunaryvell_game.dart` into the app, resolving any existing route or app-shell ownership first.
4. Run:
   - `flutter pub get`
   - `dart format lib test`
   - `flutter analyze`
   - `flutter test`
   - `flutter build web`
   - `flutter build apk --debug`
5. Launch on Android and verify:
   - finger drag moves the player and auto-fire continues;
   - enemies spawn, take damage and score increments;
   - hull decreases only once per invulnerability window;
   - boss appears after the regular wave quota is cleared on wave five;
   - boss projectiles can be dodged;
   - boss health decreases and defeat advances the wave;
   - pause/resume works;
   - game over exposes FLY AGAIN and restart resets score, wave and hull.
6. Capture any first analyzer/build/test error exactly and fix that before adding more systems.

Do not mark the game production-ready until the integrated Android build launches and the playtest checklist passes.
