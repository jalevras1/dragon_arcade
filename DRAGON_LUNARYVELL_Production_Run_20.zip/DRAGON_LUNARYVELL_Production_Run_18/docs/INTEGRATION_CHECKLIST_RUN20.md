# Run 20 integration checklist

The Run 20 archive contains a corrected game source and an approved six-dragon profile catalogue.
Package name in pubspec: `dragon_lunaryvell`.

1. Back up or commit the current `dragon_arcade` branch.
2. Copy `lib/game/dragon_profile.dart` into the app.
3. Merge `lib/game/dragon_lunaryvell_game.dart` and `lib/main.dart` carefully with the app shell.
4. Keep the Flame dependency from the supplied pubspec; do not overwrite unrelated dependencies.
5. Run `flutter pub get`, `dart format lib test`, `flutter analyze`, `flutter test`,
   `flutter build web`, and `flutter build apk --debug`.
6. Check that the six roster tests pass and manually test movement, enemy fire,
   invulnerability, boss waves, special ability and restart.
7. Do not claim device readiness until the Android debug build launches on the phone.

Special abilities currently use a common 12-second cooldown and are first-pass combat implementations;
individual VFX, animation and final balancing remain to be built and tested.
