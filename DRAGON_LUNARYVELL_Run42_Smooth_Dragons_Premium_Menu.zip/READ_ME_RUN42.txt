DRAGON LUNARYVELL - RUN 42: FLUID DRAGONS / PREMIUM TITLE MENU

This safe patch requires a completed Run 41. It retains every approved
dragon, enemy, boss, campaign backdrop, special, power-up and DEV control.

FLIGHT ANIMATION REPAIR
- Five dragon species upgraded from 8 to 16 registered transparent frames each:
  TEMPESTRYX, IGNIVAR, NYXARIEL, SOLARION and AQUARYTH.
- All species keep the same 0.8-second full wingbeat as original ASTRALIS.
- Body/head anchor positions are corrected; missing wing mid-strokes filled
  with deterministic 2D transformations of previously approved art.
- No new AI redesigns or independently generated character variants.
- Player sprite selection waits for complete asset loading, reuses in-flight
  loads, preserves wing phase and blends species switches over 180 ms.
- ORIGINAL 8-FRAME ASTRALIS ART AND TIMING ARE UNMODIFIED.

TITLE SCREEN REBRANDING
- All five original actions stay in the same order and locations: Begin
  Flight, Campaign, Dragon Select, How to Play, About.
- New dark moon-metal, amethyst, brushed-gold and silver-blue button frames,
  subtle tap feedback, etched highlights, restrained icon rings and text.
- Entire existing title painting, game HUD and dev hub remain intact.

PHONE INSTALL (ON YOUR EXISTING RUN 41 CODESPACE)
1. Download this ZIP to your phone.
2. Upload to the same branch and tap Commit changes:
   https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs
3. Paste one command in the SAME Codespaces terminal:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run42_Smooth_Dragons_Premium_Menu.zip && python3 run42_install.py

4. Wait for RUN 42 COMPLETE. Refresh the existing port 8765 preview.
5. Compare the title menu buttons, then switch among all six dragons and
   watch full wingbeats. Check no black square, body jump or wing clipping.

The installer rejects changed files not matching the expected Run 41 hashes,
backs up every replaced item, runs old/new Python checks plus Flutter tests,
builds the web app, and restores the previous working build on failure.
It keeps the DEV hub enabled in this test build. No new apps or payments.

Frame preparation uses off-line Pillow/SciPy in the packaging environment,
but NONE of those extra libraries are required for phone installation.
