# DRAGON LUNARYVELL — RUN 49

## The Eclipse War / Premium Boss Encounters

**Baseline:** Run 48 release build and phone preview reported working on 2026-11-20. This package changes only targeted Dart game code, presentation, tests and verifiers. No replacement dragons, 3D art, new paid tools, or power-up bubble changes.

### What changed

1. Replaced abstract Sky Ledger/Moonheart/Hollow Choir story with **THE ECLIPSE WAR**. Five threatened sky citadels; the Eclipse Sovereign intends to sacrifice four to save one. ASTRALIS, TEMPESTRYX, IGNIVAR, NYXARIEL, SOLARION and AQUARYTH fight to save all five. New 3-beat opening, five 2-beat chapter openers, five 2-beat boss pre-fight scenes, 25 distinct wave names, and 3-beat ending. Existing chapter paintings and speech implementation reused.
2. Redesigned story pages with rich navy-to-celestial gradients, a gilded double frame, custom 2D corner ornamentation, a dedicated speaker insignia, better buttons, cleaner branding, and fast readable captions. Existing artwork pan, audio, progress indicator, NEXT and SKIP remain.
3. Removed **the always-visible tiny yellow player pivot dot** and **two circular player overlays** (invulnerability and shield aura). The actual collision invulnerability and shield charges are **not** removed. Shield count remains in the HUD. No changes to the transparent relic bubbles.
4. Bosses have a substantially more visible 80%-width raid health plate beneath the standard score HUD, with chapter color, defensive shield line, phase markers, ritual title and legible name. Added restrained 2D arena sigils and phase lighting; kept readable aim lines and all five original attack grammars.
5. Replaced out-of-context legacy boss attack ritual names. The short victory animation now plays on the battlefield **before** the chapter intermission or ending; damage and hostile bullet movement are held during the celebration. Clearer BOSS ENCOUNTER and ANCHOR SECURED callouts.
6. Added Run 49 story/boss fairness tests and a self-contained ZIP installer that checks your exact Run 48 file hashes, backs up originals, runs all available older verifiers, Dart analysis, all relevant Flutter tests and a web build. On failure it restores Run 48 and saves a diagnostics report.

### Install in the existing Android GitHub Codespace

1. Download **R49F.zip** (the verified Run 49 repair) from the DRAGON LUNARYVELL Library. The first `R49.zip` stopped at an obsolete Run 47 mythological-text check and safely restored Run 48. In the GitHub page for the `dragon-lunaryvell-repairs` branch, **Add file → Upload files**, upload `R49F.zip` to the repository root, and commit it. Do not unzip it on your phone.
2. Return to the existing Codespaces terminal. If you are already at `/workspaces/dragon_arcade` (check `pwd`), type these two short commands, one at a time:

   ```bash
   git pull --ff-only
   python3 R49F.zip
   ```

   If not at the project root, first type: `cd /workspaces/dragon_arcade`.

3. Look for **RUN49_RELEASE_READY**. Refresh your existing **port 8765** preview tab. A **RUN49_DEBUG_PREVIEW_READY** message is a partial debug preview, not a release success. On failure the previous working Run 48 is restored and `RUN49_DIAGNOSTICS.txt` contains details.

### Phone QA — essential before calling the update verified

- Enter Campaign: prologue must say **THE FALLING CITADELS**. Confirm speaker badges, gold filigree, narration, captions, skip and next are readable without truncation on your phone.
- Drag ASTRALIS and switch dragons: **no little solid yellow dot and no static ring follow the dragon**. The power-up glass bubbles still appear independently and the SHIELD HUD value and protection still work.
- In DEV controls, jump to a boss on waves 5, 10, 15, 20 and 25. Confirm the five different attacks and color schemes, visible health and shields below the top HUD, fair visible projectile telegraphs and distinct phase callouts.
- Defeat a boss: verify the **GUARDIAN DEFEATED / CITADEL ANCHOR SECURED** moment appears before the next chapter scene. Verify no damage occurs during the victory beat.
- Check a full chapter on a normal phone for frame drops, dialog clipping or overlap; report any issue with a screenshot.

### Verification status

The first failed installer screenshot showed `tools/run47_verify.py` line 57 still requiring `SEVENTH SONG`, which the new story intentionally removed. The corrected Run 47 verifier now confirms all five real boss signature families. The full Run 43→49 structural chain passed locally against reconstructed archived sources. A ZIP installer dry run was also performed against a disposable Run 48 copy. This workspace does not have the Flutter SDK or an interactive port 8765 preview. **Dart analysis, Flutter tests, release web compilation and on-phone gameplay must still be run by the installer in your Codespace.** This package is a candidate, not a claim that the whole game is production-ready.

