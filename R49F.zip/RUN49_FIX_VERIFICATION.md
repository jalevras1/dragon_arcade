# DRAGON LUNARYVELL — Run 49 Failure Review and Corrected Installer QA

Date: November 20, 2026. Canonical next package: **R49F.zip**. The original **R49.zip** should not be rerun.

## Failure proven by the owner's screenshot

The first Run 49 installer reached `tools/run47_verify.py`, then raised an `AssertionError` on line 57. The exact obsolete assertion coupled a real game contract, `signatureForWave(`, to the literal text `SEVENTH SONG`. Run 49 had deliberately removed that mythology from the boss rule file; retaining the assertion made installation fail even though the battle implementation was still connected.

The screenshot also confirmed `ROLLBACK COMPLETE — previous working Run 48 restored` and `RUN49_DIAGNOSTICS_UPLOADED`. **No Run 49 release build was completed.** Run 48 is the latest confirmed working release.

## Narrow correction

- Keep verifying `BossEncounterRules.signatureForWave(` exists.
- Check five actual post-rewrite ritual signatures: `CRYSTAL LATTICE`, `FURNACE COLLAPSE`, `SIGNAL STORM`, `BLIZZARD WALL`, and `ECLIPSE COLLAPSE`.
- Reject an actual `SEVENTH SONG` signature in the new rules.
- Add a Run 49 regression assertion that the inherited Run 47 verifier is not still demanding that obsolete literal.
- No dragon sprites, game mechanics, relic bubbles, render behavior, gameplay balance or Flutter package dependencies were changed by this repair. The existing premium Run 49 code remains the same; only the verification contract and packaged documentation were corrected.

## Independent checks performed

| Check | Observed outcome |
|---|---|
| Reconstruct Run 48 from the archived Run 43, 44, 45, 46, 47 and 48 payloads | Complete for the 11 protected installer source paths; each pre-install hash matched an accepted baseline |
| Apply Run 49 candidate to the reconstructed source tree | Completed in isolated scratch fixture |
| Run original-to-new verifiers in install order, 43→49 | **7/7 passed**, including 36 alpha enemy-frame validation, boss telemetry contracts, narration/art/audio continuity and glass relic checks |
| Execute the corrected `python3 R49F.zip --skip-build` from a disposable Run 48 repository | Installer exited 0; all seven structural checks passed, backup created |
| Simulate release and debug compiler failures after simulated package/analyzer/test passes | Installer exited 1, reported automatic rollback |
| Compare all protected file hashes plus the prior `build/web/index.html` after the induced failure | **12/12 byte-for-byte identical** to the originals, including the old web preview |
| Simulate a successful release compiler path (with a test stub) | Installer exited 0 and emitted `RUN49_RELEASE_READY` as expected |
| Archive CRC/integrity and all 11 payload SHA-256 values | **Passed** against the corrected ZIP; every archived byte matched its manifest |

The fake Flutter commands above were isolated test stubs used solely to exercise installation and rollback code. **They are not evidence that Dart analysis, widget tests or Flutter web compilation succeeded.** The actual game still needs the real Codespaces SDK and real phone playback.

## Owner's next two commands

Upload `R49F.zip` to the repository root on the existing `dragon-lunaryvell-repairs` GitHub branch. Keep the old `R49.zip` untouched. In the current `/workspaces/dragon_arcade` terminal, run one line at a time:

```bash
git pull --ff-only
python3 R49F.zip
```

If the installer reports `RUN49_RELEASE_READY`, refresh the existing port 8765 tab, then verify Campaign dialogue, boss battle and player marker changes on the phone. If a real compiler or test fails, keep the restored Run 48 and send the diagnostic screenshot; do not reset or clean the repository.

**Release gate remains open.** This correction addresses the proven legacy verifier failure and checks both recovery and successful orchestration. It cannot guarantee compilation in a different environment until the real Flutter SDK performs the build.
