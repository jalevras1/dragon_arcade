#!/usr/bin/env python3
"""Run 49 self-contained, recoverable Codespaces installer.

Run from the existing repository as: python3 R49F.zip
The ZIP is read in-place; no unzip command or external dependencies needed.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import zipfile


ROOT = Path.cwd().resolve()
BRANCH = 'dragon-lunaryvell-repairs'
ARCHIVE = Path(sys.argv[0]).resolve()


def digest(data: bytes) -> str:
    return sha256(data).hexdigest()


def target_for(rel: str) -> Path:
    path = PurePosixPath(rel)
    if path.is_absolute() or not path.parts or '..' in path.parts:
        raise ValueError(f'Unsafe package path: {rel}')
    for count in range(1, len(path.parts) + 1):
        if ROOT.joinpath(*path.parts[:count]).is_symlink():
            raise ValueError(f'Symlink target protected: {rel}')
    return ROOT.joinpath(*path.parts)


def verify(command: list[str], timeout: int, log: Path | None = None) -> None:
    print('Verifying:', ' '.join(command), flush=True)
    result = subprocess.run(command, cwd=ROOT, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    output = result.stdout or ''
    if log:
        log.write_text(output, encoding='utf-8')
    if result.returncode == 0:
        print('\n'.join(output.splitlines()[-9:]), flush=True)
        return
    # Same guarded Codespaces analyzer exception already used in Run 48.
    # A real test AND web compilation must still succeed independently.
    if len(command) > 1 and command[1] == 'analyze' and \
            result.returncode in (241, -15) and \
            'analysis server exited with code -15' in output:
        print('Codespaces interrupted analyzer; Flutter tests and web '
              'compilation remain mandatory.', flush=True)
        return
    print('\n'.join(output.splitlines()[-75:]), flush=True)
    raise RuntimeError(f'Check failed (exit {result.returncode}): '
                       + ' '.join(command))


def web_build(flutter: str, mode: str, log: Path) -> bool:
    command = [flutter, 'build', 'web', '--' + mode, '--no-pub',
               '--no-wasm-dry-run']
    if mode == 'release':
        command.append('--optimization-level=2')
    command += ['--dart-define=DL_DEV_TOOLS=true',
                '--dart-define=DL_TEST_BUILD=RUN49']
    print('Compiling:', ' '.join(command), flush=True)
    with log.open('a', encoding='utf-8') as stream:
        stream.write('\n=== ' + ' '.join(command) + ' ===\n')
        try:
            result = subprocess.run(command, cwd=ROOT, stdout=stream,
                stderr=subprocess.STDOUT, timeout=900)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
            stream.write('Compiler exceeded 15-minute budget.\n')
        stream.write(f'Exit: {code}\n')
    good = code == 0 and (ROOT / 'build/web/index.html').is_file()
    print('Web:', 'SUCCESS' if good else f'FAILED (code {code})', flush=True)
    if not good:
        print('\n'.join(log.read_text(encoding='utf-8',
            errors='replace').splitlines()[-20:]), flush=True)
    return good


def save_diagnostics(error: BaseException, logs: dict[str, Path]) -> None:
    report = ROOT / 'RUN49_DIAGNOSTICS.txt'
    with report.open('w', encoding='utf-8') as stream:
        stream.write('RUN 49 AUTOMATIC ROLLBACK REPORT\n' + repr(error) + '\n')
        for title, path in logs.items():
            if path.is_file():
                stream.write('\n=== ' + title + ' ===\n')
                stream.write(path.read_text(encoding='utf-8', errors='replace'))
    # Exactly one text file may be committed; never push game files on error.
    try:
        subprocess.run(['git', 'add', '--', report.name], cwd=ROOT,
            check=True, timeout=30)
        changed = subprocess.run(['git', 'diff', '--cached', '--quiet',
            '--', report.name], cwd=ROOT, timeout=30)
        if changed.returncode == 1:
            subprocess.run(['git', 'commit', '--only', '-m',
                'Run49 automatic compiler diagnostics', '--', report.name],
                cwd=ROOT, check=True, timeout=90)
        subprocess.run(['git', 'push', 'origin', BRANCH], cwd=ROOT,
            check=True, timeout=180)
        print('RUN49_DIAGNOSTICS_UPLOADED — send the report to ChatGPT.')
    except (OSError, subprocess.SubprocessError) as publish_error:
        print('Report is still saved locally:', publish_error)


def main() -> int:
    options = argparse.ArgumentParser()
    options.add_argument('--skip-build', action='store_true',
                         help='Structural QA only; not a playable release')
    args = options.parse_args()
    if not (ROOT / '.git').is_dir() or not (ROOT / 'pubspec.yaml').is_file():
        print('STOP: Open the existing /workspaces/dragon_arcade Codespace.')
        return 2
    branch = subprocess.check_output(['git', 'branch', '--show-current'],
        cwd=ROOT, text=True).strip()
    if branch != BRANCH:
        print(f'STOP: branch {branch!r}; required {BRANCH!r}.')
        return 2
    flutter = shutil.which('flutter')
    if not flutter:
        for candidate in (Path.home() / 'flutter/bin/flutter',
                          Path('/home/codespace/flutter/bin/flutter')):
            if candidate.is_file():
                flutter = str(candidate)
                break
    if not flutter and not args.skip_build:
        print('STOP: Flutter missing. Your current game was not changed.')
        return 2

    with zipfile.ZipFile(ARCHIVE) as archive:
        manifest = json.loads(archive.read('run49_manifest.json'))
        if manifest.get('run') != 49 or manifest.get('base_run') != 48 or \
                manifest.get('branch') != BRANCH:
            print('STOP: Unexpected package identity.')
            return 2
        pending: list[tuple[str, bytes, Path]] = []
        for entry in manifest['files']:
            rel = entry['path']
            dst = target_for(rel)
            payload = archive.read('run49_payload/' + rel)
            if digest(payload) != entry['new_sha256']:
                print('STOP: Package integrity failed:', rel)
                return 2
            accepted = entry['accepted_old_sha256']
            if dst.is_file():
                current = digest(dst.read_bytes())
                if current == entry['new_sha256']:
                    continue
                if current not in accepted:
                    print('STOP: Customized file protected:', rel)
                    print('Send this message to ChatGPT; nothing was modified.')
                    return 2
            elif None not in accepted:
                print('STOP: Verified Run 48 baseline missing:', rel)
                return 2
            pending.append((rel, payload, dst))

    if not pending:
        print('RUN 49 ALREADY INSTALLED — refresh your existing 8765 tab.')
        return 0

    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    backup = ROOT / '.run49_backups' / stamp
    backup.mkdir(parents=True)
    web = ROOT / 'build/web'
    original_web = backup / 'previous_web'
    generated = []
    original_files = []
    web_moved = False
    web_attempted = False
    logs = {
        'PACKAGES': backup / 'pub_get.log',
        'ANALYZER': backup / 'analyze.log',
        'TESTS': backup / 'tests.log',
        'WEB': backup / 'web_build.log',
    }
    build_mode = ''
    try:
        for rel in ('pubspec.lock', '.dart_tool/package_config.json',
                    '.flutter-plugins-dependencies'):
            target = target_for(rel)
            saved = backup / 'generated_config' / rel
            present = target.is_file()
            generated.append((target, saved, present))
            if present:
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
        for rel, payload, dst in pending:
            present = dst.is_file()
            saved = backup / 'original_files' / rel
            original_files.append((dst, saved, present))
            if present:
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, saved)
        for _, payload, dst in pending:
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(payload)

        for run in range(43, 50):
            verify([sys.executable, f'tools/run{run}_verify.py'], 180)
        if not args.skip_build:
            verify([flutter, 'pub', 'get', '--offline'], 300, logs['PACKAGES'])
            verify([flutter, 'analyze', '--no-fatal-infos',
                '--no-fatal-warnings',
                'lib/game/dragon_lunaryvell_game.dart',
                'lib/game/boss_encounter_fx.dart',
                'lib/game/boss_encounter_rules.dart',
                'lib/game/run47_cinematic_story.dart',
                'lib/ui/dragon_shell.dart',
                'test/widget_test.dart',
                'test/run47_story_relics_test.dart',
                'test/run49_campaign_boss_premium_test.dart'], 480,
                logs['ANALYZER'])
            verify([flutter, 'test',
                'test/widget_test.dart',
                'test/special_ability_rules_test.dart',
                'test/campaign_story_test.dart',
                'test/dragon_flight_cycle_test.dart',
                'test/run44_premium_projectile_fx_test.dart',
                'test/run44_enemy_archetypes_test.dart',
                'test/run45_boss_encounters_test.dart',
                'test/run46_frame_pacing_test.dart',
                'test/run47_story_relics_test.dart',
                'test/run48_relic_bubbles_test.dart',
                'test/run49_campaign_boss_premium_test.dart'], 600,
                logs['TESTS'])
            if web.is_dir():
                shutil.move(str(web), str(original_web))
                web_moved = True
            web_attempted = True
            if web_build(flutter, 'release', logs['WEB']):
                build_mode = 'release'
            else:
                print('Release compilation failed; trying debug preview.')
                if web.is_dir():
                    shutil.rmtree(web)
                if web_build(flutter, 'debug', logs['WEB']):
                    build_mode = 'debug'
                else:
                    raise RuntimeError('Both web compilers failed')

        (backup / 'SUCCESS.txt').write_text(
            f'Run 48 backed up; checks passed; build={build_mode or "skipped"}\n')
        print('\nRUN 49 COMPLETE — Eclipse War campaign, premium story '
              'cards, boss cinematic staging, clean player silhouette.')
        print('Recovery snapshot:', backup.relative_to(ROOT))
        if build_mode == 'release':
            print('RUN49_RELEASE_READY — refresh the SAME 8765 preview tab.')
        elif build_mode == 'debug':
            print('RUN49_DEBUG_PREVIEW_READY — release needs investigation.')
        else:
            print('QA ONLY — --skip-build does not make a playable web build.')
        return 0
    except BaseException as error:
        print('RUN 49 FAILED:', error)
        print('Restoring your previously working Run 48 code and website...')
        for dst, saved, present in reversed(original_files):
            if present and saved.is_file():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(saved, dst)
            elif not present and dst.is_file():
                dst.unlink()
        for dst, saved, present in reversed(generated):
            if present and saved.is_file():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(saved, dst)
            elif not present and dst.is_file():
                dst.unlink()
        if web_attempted and web.is_dir():
            shutil.rmtree(web)
        if web_moved:
            shutil.move(str(original_web), str(web))
        (backup / 'FAILURE.txt').write_text(str(error) + '\n')
        print('ROLLBACK COMPLETE — previous working Run 48 restored.')
        save_diagnostics(error, logs)
        return 1


if __name__ == '__main__':
    sys.exit(main())
