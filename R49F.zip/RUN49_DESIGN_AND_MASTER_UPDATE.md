# DRAGON LUNARYVELL — Run 49 Master Production Update

Date: 2026-11-20. Continue from verified **Run 48**. Do not reset or overwrite unrelated developer/user changes.

## Locked identity and art direction

- Six official playable dragons, only: **ASTRALIS**, **TEMPESTRYX**, **IGNIVAR**, **NYXARIEL**, **SOLARION**, **AQUARYTH**.
- Premium **2D sprite-based celestial fantasy / sci-fi** only. No 3D images, models, lookalike renders, or substitute identities.
- Continue using the free Flutter/Flame/Codespaces workflow and the same GitHub repair branch and port 8765.
- Existing transparent glass power-up bubbles stay unchanged. Reference-only images never become runtime sprites without genuine alpha, isolated frames, dimensions, orientation consistency, atlas validation and real Flame playback.

## Narrative bible — THE ECLIPSE WAR

**Hook:** A sky citadel falls while people are still inside. Four more cities will fall by dawn if the six dragons cannot protect their anchors. The Eclipse Sovereign, who believes the eclipse is unstoppable, chooses to concentrate the five anchors under one citadel, sacrificing the other four. The dragons refuse that arithmetic. Their strategy: rescue the endangered populations, free the manipulated guardians and reunite all five anchors to preserve every city.

**Player promise:** Each chapter changes what needs saving, who threatens it, and what the boss believes. Fast scenes are skippable, mission-specific, voiced with existing optional speech and readable without audio. There is no choir, seventh voice, cosmic ledger, or unexplained chosen-one prophecy.

| Chapter / waves | Place and immediate danger | Guardian/boss | Dragon action | Anchor payoff |
|---|---|---|---|---|
| I · 1–5 · The Falling Spires | Evacuation bridges cut off, gates sealed with families inside | Eclipse Gargoyle Warden | ASTRALIS opens the blockade; TEMPESTRYX defeats sentries | First citadel released |
| II · 6–10 · The Ashen Front | Forge towers chained together and near collapse | Ashen Drake Colossus | IGNIVAR breaks chains; AQUARYTH cools and steadies towers | Second city saved |
| III · 11–15 · The False Night | Fake orders issued in friendly dragons' voices | Moonveil Serpent | NYXARIEL traces source; SOLARION destroys false signals | Third city regains trust |
| IV · 16–20 · The Frozen Refuge | Refugees locked in lethal 'protective' ice | Frost Harpy Matriarch | AQUARYTH safely thaws the sanctuary with TEMPESTRYX guarding | Fourth city survives |
| V · 21–25 · The Last Citadel | Sovereign will abandon four cities to save one | Eclipse Sovereign | All six unite anchors, reject forced sacrifice | All five cities withstand eclipse |

**Narrative timing constraint verified in the game code:** chapter scenes play at waves **1, 6, 11, 16, 21**, while boss preludes are shown before waves **5, 10, 15, 20**. Wave **25** ends with the three-beat epilogue. The source keeps the historical `Run47Story.forWave` API, avoiding a disruptive scene-flow rewrite. Do not treat fifth-wave scenes as post-boss dialogue.

## Boss encounter premium standard

Current Run 49 changes touch the **real-time battle**: visible readable raid plate, 2D ornamented arena edges, phase accents, chapter-specific pre-warned shot patterns preserved, boss attack names brought into line with the new war, and a protected 1.8-second battlefield victory stage. Existing five animated boss image sequences and sound cues stay connected. The new effects are bounded vector primitives, intended to avoid phone frame-time spikes; they are not 3D assets.

**Future high-impact boss milestone after Run 49 Codespaces smoke test:**

1. Validate each boss in Flame at portrait resolution (all five, all three health phases) with hitbox and telegraph overlap inspections; tune dodge corridors and challenge levels from real gameplay.
2. Add authored **transparent 2D animation frames** for boss attack anticipation, sweeping wings/turns, stagger, damage, shield rupture, and defeat, beginning with the weakest verified boss set. Isolate/measure frames first; only then atlas them and integrate to Flame. Existing sprites are the fallback; do not label newly generated concepts runtime-ready.
3. Add chapter-specific battlefield reactions (e.g., crystal bridge fractures, ember tower glow, false-signal glitches, snow shield cracks, eclipse dimming) only after performance testing and bullet readability checks.
4. Build a short, repeatable 5-boss QA checklist with actual recordings of entry, at least two phase transitions, near-miss patterns, defeat, chapter transition, and 60 Hz stability on the target phone.

## Status and remaining release gates

**Run 48** is the last screenshot-confirmed release build in the current conversation. The original `R49.zip` was installed once but **failed safely** on an outdated Run 47 assertion for `SEVENTH SONG`. Its automatic rollback restored the working Run 48 website and game. The corrected **`R49F.zip`** replaces that outdated legacy expectation with real chapter-specific boss-signature checks. All seven Run 43–49 structural verifiers passed against a reconstructed archived source tree. No Flutter/Dart binaries were available in the packaging environment. `R49F.zip` must run in the existing Codespace and report release build/tests success, then the user must verify Campaign and bosses on their phone. Substantial production readiness still requires animation-asset QA, full campaign balance, restart/save flow, mobile usability, audio/accessibility and final regression testing. Never claim full-game release readiness from this patch alone.

