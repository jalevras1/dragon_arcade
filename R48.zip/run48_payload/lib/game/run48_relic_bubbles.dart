import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'run47_relic_rules.dart';

/// Run 48: glass-and-magic pickup containers with a legible icon at center.
///
/// Painting is intentionally bounded: at most five bubbles via Run47Relics,
/// with no blur ImageFilters, saveLayer calls, per-frame text layout or new
/// images. Every type also has an unambiguous short caption on a dark badge.
class Run48RelicBubbles {
  static const double iconSize = 37;
  static const double averageRadius = 23;

  static String badge(RelicKind kind) => switch (kind) {
    RelicKind.haste => 'WIND',
    RelicKind.critical => 'CRIT',
    RelicKind.shield => 'AEGIS',
    RelicKind.trinity => '3-SHOT',
    RelicKind.phoenix => 'WINGS',
    RelicKind.arc => 'CHAIN',
    RelicKind.piercer => 'PIERCE',
    RelicKind.timeVeil => 'TIME',
    RelicKind.healing => 'HEAL',
    RelicKind.magnet => 'MAGNET',
  };

  static Color tint(RelicKind kind) => switch (kind) {
    RelicKind.haste => const Color(0xFF61E6E8),
    RelicKind.critical => const Color(0xFFFFD879),
    RelicKind.shield => const Color(0xFF7DAAFF),
    RelicKind.trinity => const Color(0xFFCA91FF),
    RelicKind.phoenix => const Color(0xFFFF9864),
    RelicKind.arc => const Color(0xFF69E8FF),
    RelicKind.piercer => const Color(0xFFD6E4FF),
    RelicKind.timeVeil => const Color(0xFFAAA3FF),
    RelicKind.healing => const Color(0xFF7DF2AE),
    RelicKind.magnet => const Color(0xFFFFE09B),
  };

  // Text is laid out once per category. These labels remain clear when two
  // relics share a base icon (WIND/TIME or CRIT/WINGS).
  static final Map<RelicKind, TextPainter> _captions = {
    for (final kind in RelicKind.values)
      kind: TextPainter(
        text: TextSpan(text: badge(kind), style: const TextStyle(
          color: Color(0xFFF9FCFF), fontSize: 9.5,
          fontWeight: FontWeight.w900, letterSpacing: .55,
        )),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.center,
      )..layout(),
  };

  static void draw(Canvas canvas, Offset center, RelicKind kind,
      double age, ui.Image? icon) {
    final color = tint(kind);
    final radius = averageRadius + math.sin(age * 3.8 + kind.index) * 1.05;
    final orb = Rect.fromCircle(center: center, radius: radius);

    // The peripheral light refracts the environment; the inner region stays
    // transparent enough to read the *actual illustrated relic* underneath.
    canvas.drawCircle(center, radius + 8,
      Paint()..shader = RadialGradient(colors: [
        color.withValues(alpha: .18),
        color.withValues(alpha: .07),
        Colors.transparent,
      ], stops: const [0, .56, 1]).createShader(
        Rect.fromCircle(center: center, radius: radius + 8)));

    canvas.drawCircle(center, radius,
      Paint()..shader = RadialGradient(
        center: const Alignment(-.48, -.53), radius: 1.25,
        colors: [
          const Color(0xFFECFDFF).withValues(alpha: .28),
          color.withValues(alpha: .14),
          const Color(0xFF061125).withValues(alpha: .20),
          color.withValues(alpha: .12),
        ], stops: const [0, .28, .72, 1],
      ).createShader(orb));

    // Keep artwork sharp and foremost. Reflections are deliberately placed
    // on the edge rather than over the middle of the symbol.
    if (icon != null) {
      canvas.drawImageRect(icon,
        Rect.fromLTWH(0, 0, icon.width.toDouble(), icon.height.toDouble()),
        Rect.fromCenter(center: center, width: iconSize, height: iconSize),
        Paint()..filterQuality = FilterQuality.medium);
    } else {
      final glyph = Path()
        ..moveTo(center.dx - 7, center.dy + 9)
        ..lineTo(center.dx + 1, center.dy - 9)
        ..lineTo(center.dx + 7, center.dy - 1)
        ..lineTo(center.dx - 1, center.dy + 9)
        ..close();
      canvas.drawPath(glyph, Paint()..color = const Color(0xFFF8F4DA));
    }

    // A spectral edge, soft upper glass crescent and two caustic points give
    // the sphere volume without covering the center or flashing brightly.
    canvas.drawCircle(center, radius - .55, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.75
      ..shader = SweepGradient(colors: [
        Colors.white.withValues(alpha: .62),
        color.withValues(alpha: .78),
        const Color(0xFFF5F9FF).withValues(alpha: .18),
        color.withValues(alpha: .60),
        Colors.white.withValues(alpha: .62),
      ], transform: GradientRotation(age * .3)).createShader(orb));
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius - 3.8),
      math.pi * 1.08, .84, false, Paint()
        ..color = const Color(0xCCF5FFFF)
        ..strokeWidth = 2.25
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke);
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius - 4.8),
      .12, .60, false, Paint()
        ..color = color.withValues(alpha: .64)
        ..strokeWidth = 1.75
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke);
    final glint = Offset(center.dx - radius * .59,
        center.dy - radius * .56);
    canvas.drawCircle(glint, 2.1, Paint()
      ..color = const Color(0xFFEFFFFF).withValues(alpha: .86));

    // The compact, high-contrast badge names the drop before collection,
    // even when multiple power-up art assets have related silhouettes.
    final label = _captions[kind]!;
    final width = label.width + 11;
    final top = center.dy + radius + 2;
    final badgeRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(center.dx - width / 2, top, width, 15),
      const Radius.circular(7.5));
    canvas.drawRRect(badgeRect,
      Paint()..color = const Color(0xED081120));
    canvas.drawRRect(badgeRect, Paint()
      ..color = color.withValues(alpha: .76)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke);
    label.paint(canvas, Offset(center.dx - label.width / 2, top + 1.2));
  }
}
