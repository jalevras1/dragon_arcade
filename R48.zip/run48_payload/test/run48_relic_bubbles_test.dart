import 'dart:ui' as ui;

import 'package:flutter_test/flutter_test.dart';
import 'package:dragon_lunaryvell/game/run47_relic_rules.dart';
import 'package:dragon_lunaryvell/game/run48_relic_bubbles.dart';

void main() {
  test('every falling relic has a unique readable badge', () {
    final names = RelicKind.values.map(Run48RelicBubbles.badge).toList();
    expect(names.length, 10);
    expect(names.toSet().length, 10);
    for (final name in names) {
      expect(name.length, lessThanOrEqualTo(6));
      expect(name, isNotEmpty);
    }
    expect(Run48RelicBubbles.badge(RelicKind.trinity), '3-SHOT');
    expect(Run48RelicBubbles.badge(RelicKind.phoenix), 'WINGS');
    expect(Run48RelicBubbles.badge(RelicKind.healing), 'HEAL');
  });

  testWidgets('glass bubbles record for all relics even before icon load',
      (tester) async {
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    for (var i = 0; i < RelicKind.values.length; i++) {
      Run48RelicBubbles.draw(canvas,
        ui.Offset(40.0 + 60 * (i % 5), 45.0 + 80 * (i ~/ 5)),
        RelicKind.values[i], .7 + i / 10, null);
    }
    recorder.endRecording().dispose();
  });
}
