#!/usr/bin/env python3
"""Offline gate for clear Run 48 pickup bubbles and cinematic story polish."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
game = (ROOT / 'lib/game/dragon_lunaryvell_game.dart').read_text()
bubbles = (ROOT / 'lib/game/run48_relic_bubbles.dart').read_text()
shell = (ROOT / 'lib/ui/dragon_shell.dart').read_text()
test = (ROOT / 'test/run48_relic_bubbles_test.dart').read_text()
for item in ('Run48RelicBubbles.draw(canvas, center, pickup.kind,',
             'Run47Relics.sprite(pickup.kind)'):
    assert item in game, f'Pickup integration missing: {item}'
for name in ('WIND', 'CRIT', 'AEGIS', '3-SHOT', 'WINGS',
             'CHAIN', 'PIERCE', 'TIME', 'HEAL', 'MAGNET'):
    assert f"'{name}'" in bubbles, f'Unreadable pickup identity: {name}'
for item in ('canvas.drawImageRect(icon,',
             'label.paint(canvas,', 'SweepGradient(', 'RadialGradient(',
             'static final Map<RelicKind, TextPainter>',
             'static const double iconSize = 37'):
    assert item in bubbles, f'Glass bubble system missing: {item}'
assert 'saveLayer(' not in bubbles and 'ImageFilter.blur' not in bubbles
for item in ('AnimatedSwitcher(', 'TweenAnimationBuilder<double>(',
             'Duration(seconds: 12)', 'LinearProgressIndicator(',
             'AnimatedContainer(', 'SKIP SCENE', 'TAKE FLIGHT',
             'THE SHATTERED MOONHEART'):
    assert item in shell, f'Cinematic story polish missing: {item}'
assert 'every falling relic has a unique readable badge' in test
assert 'glass bubbles record for all relics' in test
print('RUN 48 PREFLIGHT PASS — ten distinct phone-legible relic badges, '
      'transparent glass bubbles, edge-only highlights, cached captions, '
      'sharp central PNG icons, and bounded illustrated story motion.')
