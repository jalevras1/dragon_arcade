DRAGON LUNARYVELL · RUN 48 — GLASS RELICS & CINEMATIC CHRONICLE
=================================================================

WHAT CHANGED
------------
1. Falling power-ups are now luminous semi-transparent magical glass
   spheres with curved white reflections, colored refraction, moving
   spectral edges and tiny glints—not simple outline circles.
2. The original illustrated power-up icons remain crisp and unobscured
   at the center, enlarged to 37 logical units.
3. Every one of the TEN drops has an unmistakable small high-contrast
   identity plate, visible below the bubble in portrait gameplay:
   WIND, CRIT, AEGIS, 3-SHOT, WINGS, CHAIN, PIERCE, TIME, HEAL, MAGNET.
   This matters because some existing relics intentionally share artwork.
4. Each category uses a distinctive glow palette. Bubbles keep the same
   collision area, falling speed, effects, odds and max-five cap.
5. Campaign paintings now make a subtle 12-second, one-shot cinematic
   camera move. Transitions between different artworks softly crossfade.
   Story panels gain a framed header, spoken-caption progress bar and
   discreet beat-position dots. Narration, NEXT and SKIP SCENE remain.
6. No new expensive image loads, image filters or continuous timers.
   The 2D game and sound behavior from Run 47 remain intact.

SAFE INSTALLATION IN YOUR EXISTING ANDROID CODESPACES
----------------------------------------------------
Upload DRAGON_LUNARYVELL_Run48_GLASS_RELICS_CINEMATIC.zip to the
dragon-lunaryvell-repairs branch in GitHub, at the repository root.

Paste this ONE command in the existing Codespaces terminal:

cd /workspaces/dragon_arcade && test "$(git branch --show-current)" = "dragon-lunaryvell-repairs" && git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run48_GLASS_RELICS_CINEMATIC.zip && python3 run48_install.py

It checks hashes against your working Run 47 code before changing anything,
runs Run 43–48 structural checks, Dart analysis, all established tests plus
two new Run 48 tests, and attempts the production Flutter web build.
If anything fails, prior code and the previous build/web are restored.
Failure details are published to RUN48_DIAGNOSTICS.txt on GitHub if possible.

ON SUCCESS: look for RUN48_RELEASE_READY and refresh your existing port
8765 phone preview. RUN48_DEBUG_PREVIEW_READY means the debug web fallback
worked but the release compiler needs further investigation.

PHONE TEST (especially important for readability)
-------------------------------------------------
* In the developer menu, drop several different power-ups. Confirm you can
  read each short name WITHOUT stopping combat and can see the central icon.
* Check that 3-SHOT means multi-fire, WINGS means Phoenix spread, CHAIN means
  lightning, TIME means time veil, HEAL is healing, MAGNET is item magnet.
* Verify that the pale reflections do not pass through the center of icons.
* Look for a real round glass effect rather than a single turquoise circle.
* Enter Campaign. Watch the artwork slowly move, chapter art crossfade,
  line-progress fill, and beat dots. Confirm NEXT, narration and SKIP SCENE.
* Verify dragon controls, fire sounds, boss overshields and power-up effects
  still work and no new stuttering appears during several visible pickups.

PACKAGE QA
----------
The artwork, renderer contract, source hashes and Python rollback harness
were checked during packaging. Flutter is not installed in the packaging
runtime; the Codespaces installer provides the authoritative Dart analyzer,
Flutter-test and compiled-web result.
