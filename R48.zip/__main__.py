#!/usr/bin/env python3
"""DRAGON LUNARYVELL Run 48 phone launcher.

Usage after R48.zip is present in the Codespaces repository root:
    python3 R48.zip

--inspect checks this package without touching any game files.
--status checks the local installation without modifying files.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import zipfile


ARCHIVE = Path(sys.argv[0]).resolve()
ROOT = Path.cwd().resolve()
BRANCH = "dragon-lunaryvell-repairs"
PAYLOAD_PREFIX = "run48_payload/"
STAGING_ROOT_FILES = {"run48_install.py", "run48_manifest.json"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def checked_destination(relative: str) -> Path:
    rel = PurePosixPath(relative)
    if not rel.parts or rel.is_absolute() or ".." in rel.parts or "\\" in relative:
        raise ValueError(f"Unsafe path in package: {relative}")
    destination = ROOT.joinpath(*rel.parts)
    for index in range(1, len(rel.parts) + 1):
        if ROOT.joinpath(*rel.parts[:index]).is_symlink():
            raise ValueError(f"Protected symlink path: {relative}")
    return destination


def get_payload() -> tuple[dict, dict[str, bytes]]:
    """Read the embedded, original Run 48 package into memory and check it."""
    if not ARCHIVE.is_file():
        raise ValueError("R48.zip is not present.")
    with zipfile.ZipFile(ARCHIVE) as archive:
        items = archive.infolist()
        if len({item.filename for item in items}) != len(items):
            raise ValueError("Duplicate filenames in archive.")
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC integrity check failed.")
        filenames = {item.filename for item in items}
        manifest_name = "run48_manifest.json"
        if manifest_name not in filenames or "run48_install.py" not in filenames:
            raise ValueError("Required installer files are missing.")
        manifest = json.loads(archive.read(manifest_name))
        if (manifest.get("run"), manifest.get("base_run"), manifest.get("branch")) != (
            48, 47, BRANCH
        ):
            raise ValueError("Unexpected Run 48 manifest.")

        staging = {"run48_install.py", manifest_name}
        entries = manifest.get("files", [])
        if len(entries) != 5 or len({item["path"] for item in entries}) != 5:
            raise ValueError("Unexpected file list in Run 48 manifest.")
        for entry in entries:
            relative = entry["path"]
            if not isinstance(relative, str):
                raise ValueError("Invalid manifest path.")
            checked_destination(relative)
            staging.add(PAYLOAD_PREFIX + relative)
        if not staging.issubset(filenames):
            raise ValueError("Incomplete Run 48 payload.")

        for info in items:
            name = info.filename
            if info.is_dir():
                continue
            if not (name in staging or name in {"__main__.py", "READ_ME_RUN48.txt", "RUN48_DESIGN_SPEC.md"}):
                raise ValueError(f"Unexpected ZIP member: {name}")
            checked_destination(name)
            # Disallow symlink file entries even if the ZIP is otherwise valid.
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError(f"Unsafe ZIP symlink: {name}")

        payload = {name: archive.read(name) for name in staging}
        for entry in entries:
            name = PAYLOAD_PREFIX + entry["path"]
            if digest(payload[name]) != entry["new_sha256"]:
                raise ValueError(f"Payload checksum mismatch: {entry['path']}")
        return manifest, payload


def verify_codespace() -> None:
    if not (ROOT / ".git").is_dir() or not (ROOT / "pubspec.yaml").is_file():
        raise ValueError("Open the existing dragon_arcade Codespace project root.")
    proc = subprocess.run(
        ["git", "branch", "--show-current"],
        cwd=ROOT, capture_output=True, text=True, check=True, timeout=15
    )
    branch = proc.stdout.strip()
    if branch != BRANCH:
        raise ValueError(f"Wrong branch: {branch}; expected {BRANCH}.")


def compare_baseline(manifest: dict) -> tuple[int, int]:
    pending = 0
    installed = 0
    for entry in manifest["files"]:
        destination = checked_destination(entry["path"])
        if destination.exists() and not destination.is_file():
            raise ValueError(f"Game path is not a file: {entry['path']}")
        found = file_digest(destination) if destination.is_file() else None
        if found == entry["new_sha256"]:
            installed += 1
        elif found in entry["accepted_old_sha256"]:
            pending += 1
        else:
            raise ValueError(
                f"STOP: existing game file differs from verified Run 47: {entry['path']}. "
                "It was NOT overwritten. Send this message to ChatGPT."
            )
    return installed, pending


def prepare_staging(payload: dict[str, bytes]) -> None:
    # Staging files are not runtime code. Preserve any existing custom staging
    # files instead of silently overwriting them.
    for name, contents in payload.items():
        target = checked_destination(name)
        if target.exists() and (
            not target.is_file() or file_digest(target) != digest(contents)
        ):
            raise ValueError(
                f"STOP: staging file already exists with different content: {name}. "
                "Nothing was overwritten."
            )

    for name, contents in payload.items():
        target = checked_destination(name)
        if target.is_file():
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(f".{target.name}.run48_{os.getpid()}.tmp")
        try:
            with temporary.open("xb") as stream:
                stream.write(contents)
            temporary.replace(target)
        finally:
            temporary.unlink(missing_ok=True)


def main() -> int:
    if sys.argv[1:] not in ([], ["--inspect"], ["--status"]):
        print("Usage: python3 R48.zip [--inspect|--status]")
        return 2
    try:
        manifest, payload = get_payload()
        print("RUN48_ARCHIVE_VERIFIED: original payload hashes match.")
        if sys.argv[1:] == ["--inspect"]:
            print("No project files changed.")
            return 0
        verify_codespace()
        installed, pending = compare_baseline(manifest)
        if pending == 0:
            print("RUN48_ALREADY_INSTALLED: all five Run 48 target files match.")
            return 0
        print(f"Run 48 preflight: {installed} installed, {pending} pending; source files protected.")
        if sys.argv[1:] == ["--status"]:
            print("No project files changed.")
            return 0
        prepare_staging(payload)
        print("RUN48_STAGING_VERIFIED: launching original backup/test/build installer.")
        result = subprocess.run(
            [sys.executable, "run48_install.py"],
            cwd=ROOT, timeout=2000
        )
        return result.returncode
    except (ValueError, OSError, subprocess.SubprocessError, KeyError, TypeError, zipfile.BadZipFile) as error:
        print("RUN48_STOPPED_SAFELY:", error)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
