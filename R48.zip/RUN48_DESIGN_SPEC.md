# DRAGON LUNARYVELL — Run 48 Premium Visual Language

## A collectible must be recognizable before it is collected

The readability hierarchy for every falling bubble is **symbol first,
short name second, elemental tint third, decorative glass last**.
Central PNG art is never masked by reflections. The display uses a transparent
body and peripheral caustic lines with the name in an opaque navy plaque.
This preserves recognition over the highly detailed sky ruins.

| Drop | Badge | Tint family | Identity |
|---|---|---|---|
| Haste | WIND | aqua | movement/rapid rhythm |
| Critical | CRIT | gold | critical strikes |
| Shield | AEGIS | cobalt | protective overshield |
| Trinity | 3-SHOT | orchid | simultaneous triple fire |
| Phoenix | WINGS | ember | recurring phoenix wing spread |
| Arc | CHAIN | electric ice | chaining attack |
| Piercer | PIERCE | silver-blue | penetrating projectile |
| Time Veil | TIME | lilac | slow-time defense |
| Healing | HEAL | spring green | restores health |
| Magnet | MAGNET | solar amber | gathers drops |

Two pairs of drop types share old artwork (WIND/TIME and CRIT/WINGS), so
silhouette alone is not sufficient. The labels are not decoration: they make
those mechanically different relics unambiguous.

## Campaign presentation

The Sky Ledger is a narrated illustrated chronicle, not a box of text in
front of a static image. Every painting gets a brief slow camera push.
Changing paintings has a short crossfade; chapter-specific text stays clear
on a dark enamel-and-gold panel. A spoken-caption progress filament and
small beat markers make reading and pacing deliberate. Each animation ends
without an endlessly running timer so gameplay and automated tests remain
stable on mobile.

## Next premium passes, ranked

1. **Boss presence:** larger entrance silhouettes, named attacks with visual
   telegraphs, carefully timed hit-stop and shield-crack effects.
2. **Power-up collection feedback:** one brief identifying rune burst and
   a localized audio chime matching the relic, no full-screen flare.
3. **Dragon-specific projectile impact:** different elemental hit textures,
   disintegration signatures and bounded audio voices for each dragon.
4. **Campaign consequences:** brief after-boss conversations and character
   reactions that reinforce the six-dragon mythology and Elyra reveal.
5. **Soundtrack transitions:** restrained transition from roaming waves to
   pre-boss tension to ascension, with smooth level-matched crossfades.

These are future production suggestions. Run 48 contains the glass-bubble
system and illustrated-scene polish only, keeping the change set bounded.
