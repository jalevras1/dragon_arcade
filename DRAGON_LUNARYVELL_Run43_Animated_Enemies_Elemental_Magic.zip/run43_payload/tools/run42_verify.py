#!/usr/bin/env python3
"""Run 42: five fluid dragon flights plus original-layout title controls."""

from hashlib import sha256
from pathlib import Path
from PIL import Image, ImageChops, ImageStat


ROOT = Path(__file__).resolve().parent.parent
NEW = ROOT / 'assets/images/run42/dragons'
OLD = ROOT / 'assets/images/run38/dragons'
GAME = (ROOT / 'lib/game/dragon_lunaryvell_game.dart').read_text()
UI = (ROOT / 'lib/ui/dragon_shell.dart').read_text()
PUBSPEC = (ROOT / 'pubspec.yaml').read_text()
NAMES = ('tempestryx', 'ignivar', 'nyxariel', 'solarion', 'aquaryth')


def max_alpha_change(photos):
    alpha = [item.getchannel('A') for item in photos]
    return max(ImageStat.Stat(ImageChops.difference(
        alpha[i], alpha[(i + 1) % len(alpha)])).mean[0]
        for i in range(len(alpha)))


for name in NAMES:
    paths = [NEW / name / 'flight' / f'{name}_flight_{i:02d}.png'
             for i in range(16)]
    assert all(path.is_file() for path in paths), name
    assert len(list((NEW / name / 'flight').glob('*.png'))) == 16, name
    photos = []
    unique = set()
    for path in paths:
        with Image.open(path) as img:
            assert img.mode == 'RGBA' and img.size == (320, 320), path
            bbox = img.getchannel('A').getbbox()
            assert bbox is not None, path
            assert bbox[0] > 5 and bbox[1] > 5, (path, bbox)
            assert bbox[2] < 315 and bbox[3] < 315, (path, bbox)
            photos.append(img.copy())
        unique.add(sha256(path.read_bytes()).hexdigest())
    assert len(unique) == 16, (name, 'duplicate/missing pose')

    old = [Image.open(OLD / name / 'flight' /
               f'{name}_flight_{i:02d}.png').convert('RGBA').resize(
                    (320, 320), Image.Resampling.LANCZOS)
           for i in range(8)]
    old_jump = max_alpha_change(old)
    new_jump = max_alpha_change(photos)
    assert new_jump <= old_jump * .86, (name, old_jump, new_jump)
    assert f'- assets/images/run42/dragons/{name}/flight/' in PUBSPEC
    assert f'run42/dragons/$name/flight/' in GAME, name
    print(f'{name}: 8 -> 16 frames, peak shape change '
          f'{old_jump:.1f} -> {new_jump:.1f} ({100*(1-new_jump/old_jump):.0f}% less)')

for token in [
    'Future<void> _preloadRun42DragonCycles()',
    'Future<void> _loadRun42Dragon(String id, String name)',
    'final frames = await Future.wait(List.generate(16',
    'if (frames.length == 16)',
    '(_wingMotionSeconds * 20).floor() % frames.length',
    'final request = ++_dragonSelectionEpoch;',
    'if (request != _dragonSelectionEpoch) return;',
    '_dragonCrossfadeSeconds = .18',
    '_drawPlayableDragon(canvas, previous, path, opacity: departing)',
    '_drawPlayableDragon(canvas, dragon, path, opacity: 1 - departing)',
    'Color.fromARGB((opacity * 255).round()',
]:
    assert token in GAME, token
assert ('await _loadDragonArtwork(profile);' in GAME or
        '_loadDragonArtwork(profile), _loadRun43PlayerMagic(profile.id)' in GAME)
assert 'if (selected.id == \'astralis\' && _flightFrames.isNotEmpty)' in GAME
assert '_flightFrame = 0;' in GAME  # Initial/restart state unchanged.

for token in [
    'class _CelestialMenuButton extends StatefulWidget',
    'class _CelestialButtonFrame extends CustomPainter',
    'class _CelestialMenuLink extends StatelessWidget',
    'AnimatedScale(',
    'ClipRRect(',
    'InkWell(',
    'onTap: widget.onPressed',
    '_MenuTone.royal', '_MenuTone.moon', '_MenuTone.azure',
    'color: const Color(0xFFF0E8D7)',
    "label: 'BEGIN FLIGHT'",
    "label: 'CAMPAIGN  ·  STORY MODE'",
    "label: 'DRAGON: ${selected.name}'",
    "label: 'HOW TO PLAY'",
    "label: 'ABOUT THE GAME'",
    'onPressed: onPlay',
    'onPressed: onCampaign',
    'onPressed: onChoose',
]:
    assert token in UI, token

print('RUN 42 PREFLIGHT PASS: 80 smooth transparent dragon frames, '
      'preserved Astralis reference, coherent species switching, '
      'original-position premium branded title actions')
