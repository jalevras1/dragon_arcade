#!/usr/bin/env python3
"""Run 43 offline audit: six enemy families and differentiated fantasy magic."""

from pathlib import Path
from hashlib import sha256
from PIL import Image, ImageChops, ImageStat


ROOT = Path(__file__).resolve().parent.parent
IMAGES = ROOT / 'assets/images/run43'
GAME = (ROOT / 'lib/game/dragon_lunaryvell_game.dart').read_text()
UI = (ROOT / 'lib/ui/dragon_shell.dart').read_text()
PUBSPEC = (ROOT / 'pubspec.yaml').read_text()
NAMES = ('crystal_gargoyle', 'ember_manticore', 'void_moth')
DRAGONS = ('astralis', 'temperstryx', 'ignivar',
           'nyxariel', 'solarion', 'aquaryth')

for name in NAMES:
    folder = IMAGES / 'enemies' / name
    files = [folder / f'{name}_{i:02d}.png' for i in range(12)]
    assert all(file.is_file() for file in files), (name, 'missing pose')
    assert len(list(folder.glob('*.png'))) == 12, name
    assert f'assets/images/run43/enemies/{name}/' in PUBSPEC
    alphas = []
    hashes = set()
    center_x = []
    for path in files:
        with Image.open(path) as photo:
            assert photo.mode == 'RGBA' and photo.size == (320, 320), path
            alpha = photo.getchannel('A').copy()
            bbox = alpha.getbbox()
            assert bbox is not None and bbox[0] > 6 and bbox[1] > 6
            assert bbox[2] < 314 and bbox[3] < 314
            center_x.append((bbox[0] + bbox[2]) / 2)
            alphas.append(alpha)
        hashes.add(sha256(path.read_bytes()).hexdigest())
    assert len(hashes) == 12, (name, 'duplicate frames')
    assert max(center_x) - min(center_x) < 8, (name, 'lateral twitch')
    differences = [ImageStat.Stat(ImageChops.difference(
        alphas[i], alphas[(i + 1) % 12])).mean[0] for i in range(12)]
    assert .08 < min(differences) and max(differences) < 14, (
        name, 'jump or static pose', differences)
    print(f'{name}: 12 continuous full-size wing poses, '
          f'peak alpha change {max(differences):.2f}')

for family in ('player', 'enemy'):
    for name in DRAGONS:
        folder = IMAGES / 'projectiles' / family / name
        assert f'assets/images/run43/projectiles/{family}/{name}/' in PUBSPEC
        files = [folder / f'{name}_{index:02d}.png' for index in range(4)]
        assert all(path.is_file() for path in files)
        assert len(list(folder.glob('*.png'))) == 4
        fingerprints = set()
        for path in files:
            with Image.open(path) as img:
                assert img.mode == 'RGBA'
                assert img.size == ((64, 96) if family == 'player'
                                    else (64, 64)), path
                assert img.getchannel('A').getbbox() is not None
            fingerprints.add(sha256(path.read_bytes()).hexdigest())
        assert len(fingerprints) >= 3, (family, name, 'not animated')

for token in [
    'unawaited(_preloadRun43EnemiesAndMagic())',
    'Future<void> _loadRun43PlayerMagic(String id)',
    'Future<void> _preloadRun43EnemiesAndMagic()',
    'final available = _wave >= 8 ? 6 : _wave >= 4 ? 5 : 3;',
    'final frameSeconds = frames.length == 12 ? .8 / 12 : .1;',
    '_enemyFrames[i + 3] = frames;',
    '_enemyMagicIds', '_run43PlayerMagic[bolt.dragonId]',
    '_run43EnemyMagic[id]', '_enemyRadii', '_enemySpriteSizes',
    'for (var type = 0; type < 6; type++)',
    '(_fxTime * 15).floor() % frames.length',
    '(_fxTime * 14).floor() % frames.length',
    '_loadDragonArtwork(profile), _loadRun43PlayerMagic(profile.id)',
]:
    assert token in GAME, token
for token in ['ALL SIX ENEMIES', 'CRYSTAL GARGOYLE',
              'EMBER MANTICORE', 'VOID MOTH WRAITH',
              'developerSpawnEnemy(3)', 'developerSpawnEnemy(4)',
              'developerSpawnEnemy(5)']:
    assert token in UI, token

print('RUN 43 PREFLIGHT PASS: 36 animated premium enemy frames, 48 magical '
      'bolts, six gallery enemies, wave-safe introduction and no changes to '
      'existing dragons, bosses, chapter scenes or navigation')
