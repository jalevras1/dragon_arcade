DRAGON LUNARYVELL — RUN 43: ANIMATED ENEMIES + ELEMENTAL BREATHS

Requires a successfully installed Run 42 on branch dragon-lunaryvell-repairs.
Never replaces any of the six dragon flight loops or the chapter bosses.

WHAT'S IN IT
- 3 NEW PREMIUM ENEMIES: Mooncrystal Gargoyle, Ember Manticore,
  Void Moth Wraith. 12 distinct flight frames each, 0.8-second wingbeat.
  Existing 3 enemies preserved; new ones emerge in later waves.
- SIX ELEMENTAL AUTO-FIRE SPELLS: celestial stars, violet lightning,
  dragonfire, phantom crescent, solar flare, tidal helix.
- SIX ENEMY MAGIC PROJECTILE STYLES (no missiles or sci-fi weapons).
- DEV HUB now has ALL SIX ENEMIES and individual spawn controls.
- Optional new sprite families load AFTER initial screen to keep launch fast.
- 84 individually-addressed transparent game sprites plus original sources.
- Rollback, offline validation, Flutter tests and web build.

PHONE — ONE EXISTING CODESPACES TERMINAL
1) Download this ZIP to your phone.
2) Upload the ZIP and commit to your CURRENT branch here:
   https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs
3) Paste this ONE command in the SAME Codespaces terminal:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run43_Animated_Enemies_Elemental_Magic.zip && python3 run43_install.py

4) Wait for RUN 43 COMPLETE. Refresh your existing port 8765 browser tab.
5) DEV > ALL SIX ENEMIES: check two rows of living wing animation;
   then switch between all six dragons to compare their magical auto-fire.
   Jump to Wave 4 for gargoyle/manticore, Wave 8 for void moth.

If any regression test or web build fails, installer restores your previous
working Run 42 code and web build automatically. Do not delete your backup.
Original creative sprites are archived separately in run43_art_sources/.
The sources are not game-load assets; the 84 optimized PNGs are.
Please keep the archive as a backup for future frame-production improvements.

Read RUN43_PRIORITY_AUDIT.md for the complete visual-asset priority review.
