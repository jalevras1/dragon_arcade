# DRAGON LUNARYVELL — Run 43 asset priority audit

This audit compares the installed Run 42 source to the requested premium
portrait dragon-shooter experience. It is intentionally a priority assessment,
not a claim that an untested phone browser build is production-ready.

## Confirmed existing

- Six playable dragons, including the original eight-frame ASTRALIS cycle;
  five other dragons have sixteen registered frames and a shared 0.8 s beat.
- Five animated campaign bosses and five themed chapter battlefields;
  transitions already crossfade for 1.4 seconds.
- Branded title screen with five original-position menu options, splash/icon,
  loading screen, campaign/story, pause and player-selection screens.
- Finger-follow flight, auto-fire, three dropable boosts, six functional
  named special powers, five-wave bosses, and six-destination DEV hub.

## Priority gap addressed by Run 43

1. **Too little regular-enemy variety:** only goblin sky raider, storm harpy,
   and shadow wyvern were used in ordinary waves. Add mooncrystal gargoyle,
   ember manticore and void moth wraith, with 12 continuously animated poses
   each and 84–90px artwork. Preserve originals and stage new entries after
   wave 4 or 8 so early gameplay is still manageable.
2. **Generic auto-fire effect:** all six dragon types used the same generic
   player bolt. Add four frames for each of six distinct elemental breath
   attacks: celestial starlight, storm lightning, infernal flame, shadow
   crescent, solar flare, and tidal helix. Shots keep their original element
   if a player switches dragons while they are in flight.
3. **Identical enemy cast effect:** all common enemies shared one ember shot.
   Add six color/coherent magical projectile families, four frames each, with
   original boss effects retained as a safe fallback.
4. **Imprecise testing:** expand DEV enemy gallery to two rows of three,
   add one-tap individual spawn buttons for all new species, and include an
   in-game art-readiness count in the DEV status panel.
5. **Slow phone launching:** only the selected dragon's elemental spell
   decodes before first play; new enemy cycles and other projectile elements
   decode after launch. Complete cycles are published atomically.

## Art assets created in this update

- 3 original transparent enemy character cutouts (source illustrations).
- 36 optimized, registered, individually addressable 320×320 transparent
  enemy wing poses (3 species × 12; full cycle 0.8 seconds).
- 24 64×96 transparent player elemental-breath frames (6 × 4).
- 24 64×64 transparent enemy magical attack frames (6 × 4).
- 1 visual contact sheet and machine-checked frame-motion report.

## Next priority after a successful Run 43 phone preview

1. Make the six **special powers** feel as strong visually as they are
   mechanically. They already seek, chain, pulse, slow and create areas;
   next work should improve on-hit impact, streaks and layered spark effects.
2. Premium pickup icon animation / acquisition feedback for haste, crit and
   shield; keep them subtle and distinct from the large special button.
3. Enemy hit reaction, stagger/defeat bursts, and distinct chapter combat
   audio with a single mute control. No audio files are currently detected in
   the game asset tree; they are not fabricated in Run 43.
4. Benchmark startup and frame pacing on actual Android Chrome; animation
   checks here verify content but cannot substitute for on-device profiling.

## Safety and verification

Run 43 is a guarded delta on top of Run 42. SHA-256 manifest checks refuse
unexpected older versions or conflicting edits. Every replaced file is backed
up first; the existing web build is restored on Flutter failure. Regression
checks for Runs 35, 36 and 38–43 precede Flutter tests and web compilation.
The optional new image families do not remove the approved dragons, existing
three enemies, campaign bosses, background crossfades, menu layout, or HUD.

The local asset and code checks pass. The final Flutter compilation and
live-device visual test occur in the user's existing Codespace installer.
