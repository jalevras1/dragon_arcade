#!/usr/bin/env python3
"""Run 43: continuous enemy wingbeats and original elemental breath sprites.

Run this only in the packaging workspace (Pillow, NumPy, SciPy installed).
The user's Codespace installer only copies finished transparent PNGs.
"""

from pathlib import Path
import json
import math
import random

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageStat
from scipy.ndimage import map_coordinates


ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'run35_dragon_arcade/assets/images/run43'
ENEMIES = (
    ('crystal_gargoyle', 'exec-9e4381bc-f61d-48e9-ad56-88fdff51b175.png'),
    ('ember_manticore', 'exec-896dd37b-fe8b-421e-93c6-7f8355df2532.png'),
    ('void_moth', 'exec-830f4c30-c10e-4f0a-b6c6-926c1712b166.png'),
)
SOURCES = ROOT / 'generated_images'
FRAME_SIZE = 320
ENEMY_FRAMES = 12
PREVIEW = Image.new('RGB', (ENEMY_FRAMES * 112, 3 * 136), '#13243F')
PALETTES = {
    'astralis': ((69, 179, 255), (208, 244, 255)),
    'temperstryx': ((142, 105, 255), (242, 208, 255)),
    'ignivar': ((255, 92, 48), (255, 221, 104)),
    'nyxariel': ((168, 70, 231), (228, 153, 255)),
    'solarion': ((255, 178, 54), (255, 249, 173)),
    'aquaryth': ((52, 207, 215), (192, 255, 246)),
}


def register(source: Path) -> np.ndarray:
    image = Image.open(source).convert('RGBA')
    alpha = np.asarray(image.getchannel('A'))
    yy, xx = np.where(alpha > 36)
    if len(xx) < 1000:
        raise RuntimeError(f'Empty source art {source}')
    cropped = image.crop((int(xx.min()), int(yy.min()),
                          int(xx.max()) + 1, int(yy.max()) + 1))
    scale = min(264 / cropped.width, 274 / cropped.height)
    cropped = cropped.resize((round(cropped.width * scale),
                              round(cropped.height * scale)), Image.Resampling.LANCZOS)
    canvas = Image.new('RGBA', (FRAME_SIZE, FRAME_SIZE))
    canvas.alpha_composite(cropped, ((FRAME_SIZE - cropped.width) // 2,
                                     (FRAME_SIZE - cropped.height) // 2))
    return np.asarray(canvas).copy()


def pose(source: np.ndarray, frame: int) -> Image.Image:
    """Continuously bend outer wings around stationary central body."""
    yy, xx = np.mgrid[:FRAME_SIZE, :FRAME_SIZE].astype(np.float32)
    phase = frame * math.tau / ENEMY_FRAMES
    stroke = math.sin(phase)
    recovery = math.cos(phase)
    distance = xx - FRAME_SIZE / 2
    wing = np.clip((abs(distance) - 43) / 101, 0, 1) ** 1.5
    upper = np.clip((248 - yy) / 170, 0, 1)
    weight = wing * upper
    # The small quadrature recovery component makes each of twelve poses
    # truly distinct; a pure sine curve repeats six shapes twice per beat.
    dx = np.sign(distance) * weight * (stroke * 11 + recovery * 3.6)
    dy = weight * (stroke * 22 + recovery * 5.2) + stroke * .75
    coords = np.stack([yy - dy, xx - dx], axis=0)
    work = source.astype(np.float32)
    work[:, :, :3] *= work[:, :, 3:4] / 255
    out = np.empty_like(work)
    for channel in range(4):
        out[:, :, channel] = map_coordinates(
            work[:, :, channel], coords, order=1, mode='constant', cval=0,
            prefilter=False)
    out[:, :, :3] *= 255 / np.maximum(1, out[:, :, 3:4])
    return Image.fromarray(np.clip(out, 0, 255).astype('uint8'), 'RGBA')


def produce_enemies() -> list[dict]:
    report = []
    preview_draw = ImageDraw.Draw(PREVIEW)
    for row, (name, filename) in enumerate(ENEMIES):
        source = register(SOURCES / filename)
        output = DEST / 'enemies' / name
        output.mkdir(parents=True, exist_ok=True)
        pictures = []
        for index in range(ENEMY_FRAMES):
            frame = pose(source, index)
            frame.save(output / f'{name}_{index:02d}.png', optimize=True)
            pictures.append(frame)
            tile = frame.resize((110, 110), Image.Resampling.LANCZOS)
            bg = Image.new('RGBA', tile.size, '#182d48')
            bg.alpha_composite(tile)
            PREVIEW.paste(bg.convert('RGB'), (112 * index + 1, 136 * row + 20))
            preview_draw.text((112 * index + 3, 136 * row + 2),
                              f'{name[:9]} {index:02d}', fill='#E9D99D')
            bbox = frame.getchannel('A').getbbox()
            if not (bbox and bbox[0] > 7 and bbox[1] > 7 and
                    bbox[2] < 313 and bbox[3] < 313):
                raise RuntimeError(f'{name}: clipped frame {index} {bbox}')
        changes = [ImageStat.Stat(ImageChops.difference(
            pictures[i].getchannel('A'),
            pictures[(i + 1) % ENEMY_FRAMES].getchannel('A'))).mean[0]
            for i in range(ENEMY_FRAMES)]
        if not .08 < min(changes) < max(changes) < 15:
            raise RuntimeError(f'{name}: discontinuous motion {changes}')
        report.append({'enemy': name, 'frames': ENEMY_FRAMES,
                       'size': [FRAME_SIZE, FRAME_SIZE],
                       'cycle_ms': 800, 'min_motion': round(min(changes), 2),
                       'max_motion': round(max(changes), 2)})
        print(f'{name}: 12 continuous wing poses; alpha change '
              f'{min(changes):.2f}–{max(changes):.2f}')
    PREVIEW.save(ROOT / 'RUN43_ENEMY_ANIMATION_QA.png', optimize=True)
    return report


def color(color: tuple[int, int, int], a: int) -> tuple[int, int, int, int]:
    return (*color, int(max(0, min(255, a))))


def glyph(name: str, index: int, enemy: bool = False) -> Image.Image:
    """Paint a unique fantasy magic glyph, not a bullet or missile icon."""
    w, h = (64, 64) if enemy else (64, 96)
    scale = 3
    w, h = w * scale, h * scale
    base, highlight = PALETTES[name]
    phase = index * math.tau / 4
    rng = random.Random(name + str(index))
    glow = Image.new('RGBA', (w, h))
    gd = ImageDraw.Draw(glow)
    cx, cy = w // 2, h // 2
    core_y = cy + round(math.sin(phase) * 5)
    if name == 'temperstryx':
        points = [(cx - 7, h - 21), (cx + 17, cy + 30), (cx - 7, cy + 23),
                  (cx + 13, cy - 31), (cx - 11, cy - 20), (cx + 7, 15)]
        gd.line(points, fill=color(base, 220), width=19, joint='curve')
        gd.line(points, fill=color(highlight, 250), width=7, joint='curve')
        gd.line([(cx + 14, cy), (cx + 42, cy + 15), (cx + 22, cy + 28)],
                fill=color(base, 200), width=6)
    elif name == 'ignivar':
        gd.polygon([(cx, 10), (cx + 14, cy - 10), (cx + 8, cy + 10),
                    (cx + 26, cy + 22), (cx + 4, h - 10),
                    (cx - 26, cy + 31), (cx - 10, cy + 1)], fill=color(base, 220))
        gd.polygon([(cx, cy - 32), (cx + 10, cy + 8), (cx, h - 17),
                    (cx - 9, cy + 14)], fill=color(highlight, 250))
    elif name == 'nyxariel':
        gd.ellipse((cx - 30, core_y - 33, cx + 30, core_y + 33),
                   fill=color(base, 175))
        gd.ellipse((cx - 9, core_y - 35, cx + 34, core_y + 24),
                   fill=(0, 0, 0, 0))  # pierced crescent
        gd.arc((cx - 30, core_y - 32, cx + 31, core_y + 30),
               30 + index * 5, 290 + index * 5, fill=color(highlight, 240), width=10)
    elif name == 'solarion':
        gd.ellipse((cx - 21, core_y - 21, cx + 21, core_y + 21),
                   fill=color(base, 220))
        for step in range(8):
            angle = step * math.tau / 8 + phase / 7
            p1 = (cx + math.cos(angle) * 23, core_y + math.sin(angle) * 23)
            p2 = (cx + math.cos(angle) * 39, core_y + math.sin(angle) * 39)
            gd.line([p1, p2], fill=color(base, 208), width=7)
        gd.ellipse((cx - 10, core_y - 10, cx + 10, core_y + 10),
                   fill=color(highlight, 250))
    elif name == 'aquaryth':
        for side in (-1, 1):
            points = [(cx + side * (8 + 14 * math.sin(y * .045 + phase)), y)
                      for y in range(7, h - 5, 7)]
            gd.line(points, fill=color(base, 230), width=13, joint='curve')
            gd.line(points, fill=color(highlight, 250), width=4, joint='curve')
    else:  # astralis star-spark of pure celestial light
        outer = [(cx + math.cos(a * math.pi / 4) * (39 if a % 2 == 0 else 17),
                  core_y + math.sin(a * math.pi / 4) * (39 if a % 2 == 0 else 17))
                 for a in range(8)]
        gd.polygon(outer, fill=color(base, 205))
        gd.ellipse((cx - 12, core_y - 12, cx + 12, core_y + 12),
                   fill=color(highlight, 255))
    for _ in range(7):
        x = cx + rng.randint(-51, 51)
        y = cy + rng.randint(-55, 55)
        gd.ellipse((x - 2, y - 2, x + 2, y + 2), fill=color(highlight, 160))
    blurred = glow.filter(ImageFilter.GaussianBlur(9))
    blurred.putalpha(blurred.getchannel('A').point(lambda a: round(a * .70)))
    blurred.alpha_composite(glow)
    return blurred.resize((w // scale, h // scale), Image.Resampling.LANCZOS)


def produce_projectiles() -> None:
    for name in PALETTES:
        for family in ('player', 'enemy'):
            folder = DEST / 'projectiles' / family / name
            folder.mkdir(parents=True, exist_ok=True)
            for frame in range(4):
                # Player dragons have distinct element-specific breath forms;
                # enemy caster families retain coherent, readable 64px sigils.
                spell = glyph(name, frame, enemy=(family == 'enemy'))
                spell.save(folder / f'{name}_{frame:02d}.png', optimize=True)
    print('48 transparent elemental magic frames produced, four per spell')


if __name__ == '__main__':
    metrics = produce_enemies()
    produce_projectiles()
    (ROOT / 'RUN43_ASSET_METRICS.json').write_text(json.dumps({
        'new_enemies': metrics, 'projectile_families': len(PALETTES) * 2,
        'projectile_frames': 48, 'no_missiles': True,
    }, indent=2))
    print('RUN 43 ASSET PREPARATION COMPLETE')
