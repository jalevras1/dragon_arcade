# Run 46 — Startup and phone performance contract

## Measurable changes

1. **Shorter blocking startup:** `DragonLunaryvellGame.onLoad()` no longer
   awaits four future chapter backgrounds. The first battlefield, selected
   dragon, three wave-one enemy families and essential projectile sprites
   remain on the startup path, preventing missing-art flashes.
2. **Parallel enemy decoding:** goblin, harpy and wyvern frame groups load
   together instead of sequentially; fallback group still activates only
   when complete.
3. **Smooth late scenery:** future chapter scenes load in a bounded sequential
   queue and, if the user jumps there early, start the existing 1.4-second
   eased crossfade as they become available.
4. **Reduced per-frame arithmetic:** collision distance avoids `math.pow`
   while retaining the exact Euclidean distance and hit behavior.
5. **Developer metrics:** `FramePacingMeter` uses constant-time counters;
   frames longer than 34 ms count as slow, app-suspension gaps >500ms are
   discarded, and FPS updates approximately every 750ms.
6. **Lint maintenance:** old `.withOpacity(...)` expressions are migrated to
   `.withValues(alpha: ...)`, two unnecessary imports and an unused optional
   parameter are removed, plus safe const/comment cleanup. Older Flutter
   `material.dart` import deprecation notices remain informational; no new
   replacement UI package is installed.

## Invariants

- Existing asset paths, boss phases, damage values, projectile speeds,
  dragon flight timing, all six enemy patterns and chapter wave gates retained.
- No background sprite is removed or decompressed by the installer.
- No screenshot or new paid tool is required.
- No mask blur, `saveLayer`, timers or expensive allocations in FPS sampling.
- Projectiles retain their Run 44 glow/trails and 28-impact cap.
- If a Dart test, analyzer, or release web build fails in Codespaces, the
  installer restores the backed-up Run 45 sources and previous web output.

## Phone test checklist

- [ ] Loading screen shorter than prior Run 45 under comparable conditions
- [ ] No startup blank frame, missing enemy, flat dragon, or flicker
- [ ] Three wave-one enemy flight cycles remain synchronized and smooth
- [ ] Dev Hub displays FPS, slow frames, peak ms and art readiness
- [ ] Background fades at Waves 6, 11, 16, 21, including immediate Dev jump
- [ ] Bosses Waves 5/10/15/20/25 retain phase patterns and overshields
- [ ] Six dragon auto-fire and special abilities unchanged
- [ ] Analysis no longer reports the old `.withOpacity` notices
# Recovery installer addendum — 19 November 2026

Another attempt stopped before the web build because Flutter's analysis
server exited with code -15 and flooded the terminal with its LSP startup
JSON. This is a terminated process, not a Dart source error. The installer
now accepts exactly that analysis-server termination with Flutter exit
status 241 or -15, but preserves failures for real analyzer diagnostics.
It then requires the same full Flutter test suite to pass before proceeding.

The first two Run 46 installations passed static checks, Dart analysis, and
all 19 tests, but Flutter 3.50.0 / Dart 3.14.0 exited during dart2js web
compilation without reporting a source error. Disabling the non-fatal wasm
dry run did not resolve it. The recorded OOM kill counter was zero, while
available Codespaces RAM was under 1 GiB and no swap existed. Memory
pressure remains a hypothesis, not a confirmed root cause.

The updated installer preserves the identical gameplay payload and tests.
It attempts a supported `--release --optimization-level=2 --no-wasm-dry-run`
web build, then an isolated `--debug` web build if release fails. A debug
success is a playable development preview, *not* release verification. If
both fail, the installer restores the exact previous Run 45 files and
web output, collects memory and compiler logs without including process
command arguments, and tries to commit only a diagnostics report to the
repair branch. It neither kills processes nor changes swap settings.
When the debug fallback works, it also uploads the release failure report
for follow-up instead of requiring another manual diagnostic command.

Offline QA covers all three build outcomes: release success; debug-only
success; and two failures with full Run 45 rollback and report handoff.

