#!/usr/bin/env python3
"""Guarded Run 46 installer with web compiler recovery and safe rollback."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path, PurePosixPath
import argparse
import json
import shutil
import subprocess
import sys
import time


ROOT = Path.cwd().resolve()
EXPECTED_BRANCH = 'dragon-lunaryvell-repairs'


def digest(path: Path) -> str:
    h = sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def checked(relative: str) -> Path:
    entry = PurePosixPath(relative)
    if entry.is_absolute() or '..' in entry.parts or not entry.parts:
        raise ValueError('Unsafe update path: ' + relative)
    for n in range(1, len(entry.parts) + 1):
        if ROOT.joinpath(*entry.parts[:n]).is_symlink():
            raise ValueError('Refusing symlink update path: ' + relative)
    return ROOT.joinpath(*entry.parts)


def run(command: list[str], timeout: int) -> None:
    print('Verifying:', ' '.join(command), flush=True)
    if len(command) > 1 and command[1] == 'analyze':
        # Flutter 3.50 analysis server was repeatedly terminated with -15
        # in this small Codespace. Earlier Run 46 analysis had reported
        # zero errors. Accept ONLY that exact transient shutdown, never
        # regular analysis failures. All 19 Flutter tests still must pass.
        result = subprocess.run(command, cwd=ROOT, text=True,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=timeout)
        output = result.stdout or ''
        if result.returncode == 0:
            print('\n'.join(output.splitlines()[-18:]), flush=True)
            return
        if result.returncode in (241, -15) and 'analysis server exited with code -15' in output:
            print('RECOVERABLE: Flutter analysis server was terminated (SIGTERM). '
                  'A previous Run 46 analysis found no errors. Continuing with '
                  'the full Flutter test suite; any test/build failure still '
                  'triggers automatic Run 45 rollback.', flush=True)
            return
        print('\n'.join(output.splitlines()[-70:]), flush=True)
        raise subprocess.CalledProcessError(result.returncode, command)
    subprocess.run(command, cwd=ROOT, check=True, timeout=timeout)


def capture_machine_snapshot(log: Path) -> None:
    """Capture resource facts without logging environment variables or command arguments."""
    with log.open('a', encoding='utf-8') as sink:
        sink.write('\n=== Codespaces resource snapshot ===\n')
        for command in (['free', '-h'],
                        ['ps', '-eo', 'pid,rss,comm', '--sort=-rss']):
            try:
                result = subprocess.run(command, cwd=ROOT, text=True,
                                        capture_output=True, timeout=15)
                sink.write(' '.join(command) + '\n')
                sink.write('\n'.join(result.stdout.splitlines()[:25]) + '\n')
            except (OSError, subprocess.SubprocessError) as exc:
                sink.write('Snapshot unavailable: ' + repr(exc) + '\n')
        sink.flush()


def build_attempt(command: list[str], log: Path, timeout: int = 900) -> bool:
    """Log compiler stderr and stdout without letting partial builds count as success."""
    print('Trying:', ' '.join(command), flush=True)
    capture_machine_snapshot(log)
    started = time.monotonic()
    with log.open('a', encoding='utf-8') as sink:
        sink.write('\n=== Flutter web build attempt ===\n')
        sink.write(' '.join(command) + '\n')
        sink.flush()
        try:
            result = subprocess.run(command, cwd=ROOT, stdout=sink,
                                    stderr=subprocess.STDOUT, timeout=timeout)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
            sink.write('Build exceeded the 15-minute safety limit.\n')
        sink.write(f'BUILD RETURN CODE: {code}; elapsed {time.monotonic() - started:.1f}s\n')
    capture_machine_snapshot(log)
    ok = code == 0 and (ROOT / 'build/web/index.html').is_file()
    print('Web attempt:', 'SUCCESS' if ok else f'FAILED (code {code})', flush=True)
    if not ok:
        tail = log.read_text(encoding='utf-8', errors='replace').splitlines()[-24:]
        print('Latest build log lines:\n' + '\n'.join(tail), flush=True)
    return ok


def upload_failure_report(log: Path) -> bool:
    """Commit only our diagnostics; never stage or commit game files."""
    report = ROOT / 'RUN46_RECOVERY_REPORT.txt'
    if report.exists() and not report.is_file():
        print('Existing report path is not a regular file; not overwriting.')
        return False
    report.write_bytes(log.read_bytes())
    try:
        subprocess.run(['git', 'add', '--', report.name], cwd=ROOT,
                       check=True, timeout=30)
        staged = subprocess.run(['git', 'diff', '--cached', '--quiet', '--', report.name],
                                cwd=ROOT, timeout=30)
        if staged.returncode == 1:
            subprocess.run(['git', 'commit', '--only', '-m',
                            'Run46 automatic web compiler recovery report', '--', report.name],
                           cwd=ROOT, check=True, timeout=90)
        subprocess.run(['git', 'push', 'origin', EXPECTED_BRANCH], cwd=ROOT,
                       check=True, timeout=180)
        return True
    except (OSError, subprocess.SubprocessError) as error:
        print('Report saved locally; GitHub upload unavailable:', error)
        return False


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--skip-build', action='store_true',
                        help='Installer QA only; no Flutter web preview made')
    args = parser.parse_args()
    if not (ROOT / '.git').is_dir() or not (ROOT / 'pubspec.yaml').is_file():
        print('STOP: Run this inside your existing dragon_arcade Codespaces terminal.')
        return 2
    branch = subprocess.check_output(
        ['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip()
    if branch != EXPECTED_BRANCH:
        print('STOP: Wrong branch:', branch)
        return 2
    manifest_path = ROOT / 'run46_manifest.json'
    if not manifest_path.is_file():
        print('STOP: Extract the Run 46 ZIP before running this installer.')
        return 2
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('run') != 46 or manifest.get('branch') != EXPECTED_BRANCH:
        print('STOP: Unrecognized Run 46 manifest.')
        return 2
    flutter = shutil.which('flutter')
    if not args.skip_build and not flutter:
        candidate = Path.home() / 'flutter/bin/flutter'
        flutter = str(candidate) if candidate.is_file() else None
    if not args.skip_build and not flutter:
        print('STOP: Flutter unavailable. No files changed.')
        return 2

    pending: list[tuple[str, Path, Path]] = []
    for entry in manifest['files']:
        rel = entry['path']
        target = checked(rel)
        source = checked('run46_payload/' + rel)
        if not source.is_file() or digest(source) != entry['new_sha256']:
            print('STOP: Run 46 package integrity failed:', rel)
            return 2
        old_hashes = entry.get('accepted_old_sha256', [entry.get('old_sha256')])
        if target.is_file():
            old_hash = digest(target)
            if old_hash == entry['new_sha256']:
                continue
            if old_hash not in old_hashes:
                print('STOP: Existing custom work protected:', rel)
                print('No files changed; send this message to ChatGPT.')
                return 2
        elif None not in old_hashes:
            print('STOP: Expected Run 45 baseline file absent:', rel)
            return 2
        pending.append((rel, source, target))

    if not pending:
        print('RUN 46 FILES ALREADY INSTALLED. Refresh the existing 8765 tab.')
        return 0

    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    backup = ROOT / '.run46_backups' / stamp
    previous_web = backup / 'previous_web'
    build = ROOT / 'build/web'
    backup.mkdir(parents=True)
    originals: list[tuple[str, Path, bool]] = []
    moved_web = False
    attempted_web_build = False
    build_kind = ''
    recovery_log = backup / 'web_compiler_recovery.log'
    try:
        for rel, _, target in pending:
            exists = target.is_file()
            originals.append((rel, target, exists))
            if exists:
                saved = backup / 'original_files' / rel
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
        for _, source, target in pending:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)

        # Run 45 replaced the older boss behavior. Run 43-46 contracts
        # check the live retained player, enemy, boss and loading systems.
        for phase in (43, 44, 45, 46):
            run([sys.executable, f'tools/run{phase}_verify.py'], 150)

        if not args.skip_build:
            run([flutter, 'analyze', '--no-fatal-infos',
                 '--no-fatal-warnings',
                 'lib/game/dragon_lunaryvell_game.dart',
                 'lib/game/frame_pacing_meter.dart',
                 'lib/game/boss_encounter_rules.dart',
                 'lib/game/boss_encounter_fx.dart',
                 'lib/game/premium_projectile_fx.dart',
                 'lib/game/enemy_archetypes.dart',
                 'lib/ui/dragon_shell.dart',
                 'test/run44_premium_projectile_fx_test.dart',
                 'test/run44_enemy_archetypes_test.dart',
                 'test/run45_boss_encounters_test.dart',
                 'test/run46_frame_pacing_test.dart'], 420)
            run([flutter, 'test', 'test/widget_test.dart',
                 'test/special_ability_rules_test.dart',
                 'test/campaign_story_test.dart',
                 'test/dragon_flight_cycle_test.dart',
                 'test/run44_premium_projectile_fx_test.dart',
                 'test/run44_enemy_archetypes_test.dart',
                 'test/run45_boss_encounters_test.dart',
                 'test/run46_frame_pacing_test.dart'], 420)
            if build.is_dir():
                shutil.move(str(build), str(previous_web))
                moved_web = True
            attempted_web_build = True
            # A default O4 release build repeatedly failed on the user's
            # 8 GiB no-swap Codespace. O2 is a supported Dart JS release mode
            # which performs less compiler work. The wasm dry run is not
            # needed for the JS web preview.
            if build_attempt([flutter, 'build', 'web', '--release', '--no-pub',
                              '--no-wasm-dry-run', '--optimization-level=2',
                              '--dart-define=DL_DEV_TOOLS=true',
                              '--dart-define=DL_TEST_BUILD=RUN46'], recovery_log):
                build_kind = 'release'
            else:
                print('Release compilation failed; trying a phone-testable '
                      'DEBUG preview without the release optimizer.', flush=True)
                if build.is_dir():
                    shutil.rmtree(build)
                if build_attempt([flutter, 'build', 'web', '--debug', '--no-pub',
                                  '--no-wasm-dry-run',
                                  '--dart-define=DL_DEV_TOOLS=true',
                                  '--dart-define=DL_TEST_BUILD=RUN46_DEBUG'],
                                 recovery_log):
                    build_kind = 'debug'
                else:
                    raise RuntimeError('Both release and debug web builds failed. '
                                       'Saved full diagnostics for automatic upload.')

        (backup / 'SUCCESS.txt').write_text('Run 46 original files saved; ' +
            ('structural checks passed; build skipped\n' if args.skip_build else
             f'all tests passed and web {build_kind} built\n'))
        print('\nRUN 46 COMPLETE — Faster launch and phone diagnostics ready.')
        print('Previous working files saved under', backup.relative_to(ROOT))
        if args.skip_build:
            print('NOTE: --skip-build did not create a playable web preview.')
        else:
            print('Refresh the SAME 8765 tab. No second terminal is needed.')
            if build_kind == 'debug':
                print('RUN46_DEBUG_PREVIEW_READY — tests passed; debug web preview '
                      'works, but release compilation still needs follow-up.')
                if recovery_log.is_file() and upload_failure_report(recovery_log):
                    print('RUN46_RELEASE_DIAGNOSTICS_UPLOADED')
            else:
                print('RUN46_RELEASE_READY — tests passed; optimized release web built.')
        return 0
    except BaseException as error:
        print('\nRUN 46 FAILED:', error)
        print('Restoring previous Run 45 code and web build...', flush=True)
        for rel, target, previously_existed in reversed(originals):
            if previously_existed:
                saved = backup / 'original_files' / rel
                if saved.is_file():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(saved, target)
            elif target.is_file():
                target.unlink()
        if attempted_web_build and build.is_dir():
            shutil.rmtree(build)
        if moved_web:
            shutil.move(str(previous_web), str(build))
        print('ROLLBACK COMPLETE — prior working Run 45 version restored.')
        if recovery_log.is_file():
            if upload_failure_report(recovery_log):
                print('RUN46_ROLLED_BACK_REPORT_UPLOADED')
            else:
                print('RUN46_ROLLED_BACK_LOCAL_REPORT_ONLY — send the report to ChatGPT.')
        return 1


if __name__ == '__main__':
    sys.exit(main())
