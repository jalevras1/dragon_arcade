DRAGON LUNARYVELL · RUN 47 V4 — CAMPAIGN ACTION REPAIR / SKY LEDGER
================================================================

V4 repairs the exact failure recorded in RUN47_V3_DIAGNOSTICS.txt:
the old campaign widget test expects the TAKE FLIGHT button on the initial
story screen. The premium opening now offers a functional TAKE FLIGHT
action (subtitled SKIP SCENE) while NEXT continues through all narrated
artwork. V3's gold THE SHATTERED MOONHEART title remains on that screen.
All Dart compiler/audio repairs, paintings, bosses, relics, soundtrack,
effects and dragon weapon audio remain intact. V3 passed Dart analysis
with only four nonblocking infos and passed 22 other Flutter tests.
V4 still needs the Flutter compiler and tests in your Codespace.

What you are installing
-----------------------
1. Five-act narrative campaign (25 named waves), three-beat prologue,
   chapter dialogue, pre-boss dialogue and complete epilogue.
2. Six premium 2D story paintings, custom gold/sapphire dialogue frames,
   typewriter captions, speaker replay / voice toggle / SKIP SCENE.
3. Browser-provided English voice narration: no separate app, account,
   software or paid recording. Voice and timing depend on Android browser.
4. Five distinct boss ceremonial aura patterns, shield sigil fragments,
   improved telegraphed lane charge and phase/entry/victory title cards.
5. Ten power-up types, including triple spread fire, periodic phoenix wing
   spread, chain lightning, piercing bolts, time veil, healing and magnet.
6. Eight new transparent painted PNG relic sprites, original 48-second
   looping soundtrack, 19 individual OGG sounds (six tailored fire cues).
7. Multi-fire triggers ONE restrained dragon sound per third volley, not one
   sound per projectile. Boss and pickup sound effects are volume-limited.

Safe installation from your EXISTING GitHub Codespaces on Android
---------------------------------------------------------------
Upload DRAGON_LUNARYVELL_Run47_V4_CAMPAIGN_ACTION_REPAIR.zip to the GitHub branch
dragon-lunaryvell-repairs first. Keep the ZIP in the repository root.
Then paste this ONE command in the existing Codespaces terminal:

cd /workspaces/dragon_arcade && test "$(git branch --show-current)" = "dragon-lunaryvell-repairs" && git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run47_V4_CAMPAIGN_ACTION_REPAIR.zip && python3 run47_install.py

V2/V3/V4 fix the confirmed 11 Dart extension-type errors. The package previously
declared Dart 3.0 while its browser speech/audio code needs Dart 3.3. It now
updates the Dart SDK lower bound and refreshes cached dependencies offline.
The remaining old-material-import notices are informational, not build errors.

It checks package hashes; refuses unknown custom baseline edits; runs Run
43-47 checks and full Flutter tests; attempts the same memory-friendlier
O2 release web build that worked for Run 46; tries debug only if release
fails; restores all previous Run 46 files and build/web if unsuccessful.

Your existing web preview server (port 8765) stays in place. When the
installer reports RUN47_RELEASE_READY, refresh that same forwarded tab.
You do not need a second terminal.

Suggested phone playtest
------------------------
* Tap Campaign: look for the six-dragon prologue and premium gold dialogue.
* Use speaker icon for narration on/off; replay button if Chrome was silent
  on scene open; NEXT advances. TAKE FLIGHT/SKIP SCENE on the first prologue
  page starts combat immediately; later scenes retain SKIP SCENE.
* Look at the new five chapter illustrations and pre-boss conversations.
* Tap the in-game volume icon; DRAG your dragon once if Chrome blocked music
  autoplay. Listen for low-volume loop + dragon-specific auto-fire timbre.
* DEV hub > ENEMIES AND POWER-UPS: GIVE/DROP TRINITY, PHOENIX, CHAIN,
  PIERCE, TIME VEIL, HEAL and MAGNET. Spread should shoot 3 arrows; Phoenix
  adds two wide wings every fourth volley, at most five bolts per firing.
* Check on-screen chips, sparkly illustrated relics and pickup chimes.
* DEV hub > EXACT WAVE AND BOSS TEST: wave 5/10/15/20/25; watch unique
  orbiting runes, shield break sigils, charged attack trails and phase cues.
* Continue after chapter waves into boss prelude and next act. Check no
  dialogue covers projectiles while active combat runs.
* Confirm the game remains responsive when 3 or 5-shot effects overlap.

What is and isn't verified yet
------------------------------
All artwork/audio files and Python preflight contracts passed in the
packaging environment. This environment has no Flutter SDK or Android
Chrome, so only your existing Codespace installer can certify the Dart
analysis, Flutter tests, JS compilation and actual phone voice playback.

If anything fails, leave the Codespace running only long enough to capture
the first useful error. The installer restores Run 46 automatically.
V4 also publishes RUN47_V4_DIAGNOSTICS.txt to GitHub automatically if anything
fails, without committing changed game source code.
You can simply tell ChatGPT it failed; the report should already be on GitHub.
