#!/usr/bin/env python3
"""Transactional Run 47 upgrade from verified Run 46; never discards working web."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path, PurePosixPath
import argparse
import json
import shutil
import subprocess
import sys

ROOT = Path.cwd().resolve()
BRANCH = 'dragon-lunaryvell-repairs'


def digest(path: Path) -> str:
    h = sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def safe_path(value: str) -> Path:
    rel = PurePosixPath(value)
    if rel.is_absolute() or not rel.parts or '..' in rel.parts:
        raise ValueError(f'Unsafe package path: {value}')
    for n in range(1, len(rel.parts) + 1):
        if ROOT.joinpath(*rel.parts[:n]).is_symlink():
            raise ValueError(f'Symlinks are protected: {value}')
    return ROOT.joinpath(*rel.parts)


def verify(command: list[str], timeout: int,
           log_path: Path | None = None) -> None:
    print('Verifying:', ' '.join(command), flush=True)
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=timeout)
    output = result.stdout or ''
    if log_path is not None:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text(output, encoding='utf-8')
    if result.returncode == 0:
        print('\n'.join(output.splitlines()[-10:]), flush=True)
        return
    if (len(command) > 1 and command[1] == 'analyze'
            and result.returncode in (241, -15)
            and 'analysis server exited with code -15' in output):
        print('Flutter analysis server was interrupted by Codespaces (SIGTERM). '
              'All Flutter tests and the web compiler MUST still pass.', flush=True)
        return
    print('\n'.join(output.splitlines()[-75:]), flush=True)
    raise RuntimeError(f'Check failed, return code {result.returncode}: '
                       + ' '.join(command))


def web_build(command: list[str], log: Path) -> bool:
    print('Trying phone web build:', ' '.join(command), flush=True)
    with log.open('a', encoding='utf-8') as stream:
        stream.write('\n=== ' + ' '.join(command) + ' ===\n')
        try:
            result = subprocess.run(command, cwd=ROOT,
                                    stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=900)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
            stream.write('\nCompiler exceeded 15-minute time budget.\n')
        stream.write(f'Exit code: {code}\n')
    good = code == 0 and (ROOT / 'build/web/index.html').is_file()
    print('Web:', 'SUCCESS' if good else f'FAILED (code {code})', flush=True)
    if not good:
        print('\n'.join(log.read_text(encoding='utf-8',
              errors='replace').splitlines()[-22:]), flush=True)
    return good


def upload_failure_report(report: Path) -> None:
    """Send only diagnostic text to the known branch; never game source."""
    if not report.is_file():
        return
    try:
        subprocess.run(['git', 'add', '--', report.name], cwd=ROOT,
                       check=True, timeout=30)
        staged = subprocess.run(['git', 'diff', '--cached', '--quiet',
                                 '--', report.name], cwd=ROOT, timeout=30)
        if staged.returncode == 1:
            subprocess.run(['git', 'commit', '--only',
                            '-m', 'Run47 V4 automatic compiler diagnostics',
                            '--', report.name], cwd=ROOT,
                           check=True, timeout=90)
        subprocess.run(['git', 'push', 'origin', BRANCH], cwd=ROOT,
                       check=True, timeout=180)
        print('RUN47_V4_DIAGNOSTICS_UPLOADED — ChatGPT can read the report.')
    except (OSError, subprocess.SubprocessError) as error:
        print('Report retained locally; GitHub upload unavailable:', error)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--skip-build', action='store_true',
                        help='Developer only: structural installation QA')
    options = parser.parse_args()
    if not (ROOT / '.git').is_dir() or not (ROOT / 'pubspec.yaml').is_file():
        print('STOP: Open your existing dragon_arcade GitHub Codespace first.')
        return 2
    current = subprocess.check_output(
        ['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip()
    if current != BRANCH:
        print('STOP: Wrong branch:', current, '— wanted', BRANCH)
        return 2
    manifest_file = ROOT / 'run47_manifest.json'
    if not manifest_file.is_file():
        print('STOP: Unzip the Run 47 package in the project folder first.')
        return 2
    manifest = json.loads(manifest_file.read_text())
    if manifest.get('run') != 47 or manifest.get('base_run') != 46 \
            or manifest.get('branch') != BRANCH:
        print('STOP: Unexpected Run 47 package metadata.')
        return 2

    flutter = shutil.which('flutter')
    if not options.skip_build and flutter is None:
        candidate = Path.home() / 'flutter/bin/flutter'
        if candidate.is_file():
            flutter = str(candidate)
    if not options.skip_build and flutter is None:
        print('STOP: Flutter is not available. No existing code was changed.')
        return 2

    pending = []
    for entry in manifest['files']:
        rel = entry['path']
        src = safe_path('run47_payload/' + rel)
        dst = safe_path(rel)
        if not src.is_file() or digest(src) != entry['new_sha256']:
            print('STOP: Package content damaged or missing:', rel)
            return 2
        accepted = entry['accepted_old_sha256']
        if dst.is_file():
            current_sha = digest(dst)
            if current_sha == entry['new_sha256']:
                continue
            if current_sha not in accepted:
                print('STOP: Existing custom file protected:', rel)
                print('No existing game files were changed. Send this to ChatGPT.')
                return 2
        elif None not in accepted:
            print('STOP: Run 46 baseline not found:', rel)
            return 2
        pending.append((rel, src, dst))

    if not pending:
        print('RUN 47 ALREADY INSTALLED. Refresh your existing 8765 preview.')
        return 0

    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    backup = ROOT / '.run47_backups' / stamp
    previous_web = backup / 'previous_web'
    build = ROOT / 'build/web'
    log = backup / 'web_build.log'
    analysis_log = backup / 'analysis.log'
    package_log = backup / 'pub_get.log'
    test_log = backup / 'tests.log'
    backup.mkdir(parents=True)
    originals: list[tuple[str, Path, bool]] = []
    generated: list[tuple[Path, Path, bool]] = []
    web_moved = False
    web_attempted = False
    build_mode = ''

    try:
        for relative in ('pubspec.lock', '.dart_tool/package_config.json',
                         '.flutter-plugins-dependencies'):
            target = safe_path(relative)
            saved = backup / 'generated_config' / relative
            exists = target.is_file()
            generated.append((target, saved, exists))
            if exists:
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
        for rel, _, dst in pending:
            existed = dst.is_file()
            originals.append((rel, dst, existed))
            if existed:
                saved = backup / 'original_files' / rel
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, saved)
        for _, src, dst in pending:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)

        for run in (43, 44, 45, 46, 47):
            verify([sys.executable, f'tools/run{run}_verify.py'], 180)

        if not options.skip_build:
            # The baseline defaults to Dart 3.0. Web Speech interop uses Dart
            # 3.3 extension types. Regenerate package_config after upgrading
            # the SDK lower bound; offline mode uses existing cached packages.
            verify([flutter, 'pub', 'get', '--offline'], 300, package_log)
            verify([flutter, 'analyze', '--no-fatal-infos',
                '--no-fatal-warnings',
                'lib/game/dragon_lunaryvell_game.dart',
                'lib/game/boss_encounter_fx.dart',
                'lib/game/boss_encounter_rules.dart',
                'lib/game/run47_cinematic_story.dart',
                'lib/game/run47_relic_rules.dart',
                'lib/game/run47_audio.dart',
                'lib/game/run47_audio_stub.dart',
                'lib/game/run47_audio_web.dart',
                'lib/ui/dragon_shell.dart',
                'test/run47_story_relics_test.dart'], 420, analysis_log)
            verify([flutter, 'test',
                'test/widget_test.dart',
                'test/special_ability_rules_test.dart',
                'test/campaign_story_test.dart',
                'test/dragon_flight_cycle_test.dart',
                'test/run44_premium_projectile_fx_test.dart',
                'test/run44_enemy_archetypes_test.dart',
                'test/run45_boss_encounters_test.dart',
                'test/run46_frame_pacing_test.dart',
                'test/run47_story_relics_test.dart'], 480, test_log)
            if build.is_dir():
                shutil.move(str(build), str(previous_web))
                web_moved = True
            web_attempted = True
            if web_build([flutter, 'build', 'web', '--release', '--no-pub',
                          '--no-wasm-dry-run', '--optimization-level=2',
                          '--dart-define=DL_DEV_TOOLS=true',
                          '--dart-define=DL_TEST_BUILD=RUN47'], log):
                build_mode = 'release'
            else:
                print('O2 release failed. Trying a debug preview for '
                      'diagnostics (working Run 46 remains safely backed up).')
                if build.is_dir():
                    shutil.rmtree(build)
                if web_build([flutter, 'build', 'web', '--debug', '--no-pub',
                              '--no-wasm-dry-run',
                              '--dart-define=DL_DEV_TOOLS=true',
                              '--dart-define=DL_TEST_BUILD=RUN47_DEBUG'], log):
                    build_mode = 'debug'
                else:
                    raise RuntimeError('Both web compilers failed; see log')

        (backup / 'SUCCESS.txt').write_text(
            f'Run 46 files backed up; structural tests PASS; web={build_mode or "skipped"}\n')
        print('\nRUN 47 COMPLETE — Illustrated story, voiced captions, '
              'boss ceremony, relics, soundtrack and six dragon weapon cues.')
        print('Run 46 recovery snapshot:', backup.relative_to(ROOT))
        if build_mode == 'release':
            print('RUN47_RELEASE_READY — refresh the SAME 8765 preview tab.')
        elif build_mode == 'debug':
            print('RUN47_DEBUG_PREVIEW_READY — optimized release needs follow-up.')
        else:
            print('QA ONLY: --skip-build does not produce a playable web build.')
        return 0
    except BaseException as error:
        print('\nRUN 47 FAILED:', error)
        print('Restoring the previous working Run 46 game and website...')
        for rel, dst, existed in reversed(originals):
            if existed:
                saved = backup / 'original_files' / rel
                if saved.is_file():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(saved, dst)
            elif dst.is_file():
                dst.unlink()
        for target, saved, existed in reversed(generated):
            if existed and saved.is_file():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(saved, target)
            elif not existed and target.is_file():
                target.unlink()
        if web_attempted and build.is_dir():
            shutil.rmtree(build)
        if web_moved:
            shutil.move(str(previous_web), str(build))
        (backup / 'FAILURE.txt').write_text(str(error) + '\n')
        report = ROOT / 'RUN47_V4_DIAGNOSTICS.txt'
        with report.open('w', encoding='utf-8') as stream:
            stream.write('RUN 47 V4 RECOVERY REPORT\n' + repr(error) + '\n')
            for heading, file in (('DEPENDENCIES', package_log),
                                  ('ANALYZER', analysis_log),
                                  ('TESTS', test_log),
                                  ('WEB BUILD', log)):
                if file.is_file():
                    stream.write('\n=== ' + heading + ' ===\n')
                    stream.write(file.read_text(encoding='utf-8', errors='replace'))
        print('ROLLBACK COMPLETE — prior working Run 46 restored.')
        upload_failure_report(report)
        return 1


if __name__ == '__main__':
    sys.exit(main())
