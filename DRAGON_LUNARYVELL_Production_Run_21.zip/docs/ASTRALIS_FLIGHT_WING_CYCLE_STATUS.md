# ASTRALIS Flight/Wing Cycle — Status

- Asset ID: `astralis.flight.wing_cycle.v1`
- Delivered: 8 isolated RGBA PNG frames, each 384×512, plus a 4×2 1536×1024 atlas.
- Cycle timing: 100 ms per frame (10 fps), looping; tune after device playback.
- Image-level checks: true alpha channel present; each frame contains transparent and visible pixels; identical cell dimensions; no cell-boundary clipping observed.
- Current status: **alpha-extracted candidate; not Flame-validated and not runtime-ready**.
- Pending: copy into `dragon_arcade`, register Flutter assets, play in Flame, inspect pivot and frame cadence on Android, and confirm no edge halos.
