# DRAGON LUNARYVELL — Production Run 21

## Deliverable
An eight-frame ASTRALIS flight/wing-cycle sprite candidate, extracted into eight isolated PNG frames and a 4×2 atlas. This is the first clean gameplay-animation asset in this run.

## What is included
- `assets/astralis/flight/frames/`: eight fixed-size 384×512 RGBA PNG frames.
- `assets/astralis/flight/atlas/astralis_flight_wing_4x2.png`: cleaned 1536×1024 atlas.
- `flutter_assets/assets/images/dragons/astralis/astralis_flight_wing_4x2.png`: same atlas placed at the expected Flutter/Flame asset path inside the package.
- `metadata/astralis_flight_wing_atlas.json`: frame rectangles, row-major order, frame timing, provisional anchor and per-frame metrics.
- `metadata/validation_report.json`: image-level alpha and frame-dimension checks.
- `previews/astralis_flight_wing_contact.png`: checkerboard preview only; not a runtime asset.
- `source/astralis_flight_wing_source.png`: unmodified generated source sheet.

## Validation status
The source has an RGBA alpha channel. Each 384×512 cell was isolated, alpha values below 8 were cleared to remove faint background haze, tiny isolated speckles were removed, and the eight PNGs were verified to have identical dimensions, transparent pixels and visible sprite pixels. The atlas is row-major, two rows by four columns.

**Not yet runtime-ready.** This package has not been loaded into the live `dragon_arcade` repository, played through Flame, compiled for Android, or tested on the phone. The center anchor is provisional and must be visually checked in motion. Do not treat the generated composite reference sheets as runtime sprites.

## Suggested Flame integration
Copy the atlas from `flutter_assets/assets/images/dragons/astralis/` into the app's `assets/images/dragons/astralis/` folder, then register `assets/images/` in `pubspec.yaml` if it is not already registered. Flame's default image prefix is `assets/images/`, so load it with the relative path below.

```dart
final image = await game.images.load(
  'dragons/astralis/astralis_flight_wing_4x2.png',
);
final animation = SpriteAnimation.fromFrameData(
  image,
  SpriteAnimationData.sequenced(
    amount: 8,
    textureSize: Vector2(384, 512),
    stepTime: 0.10,
    loop: true,
  ),
);
final dragonSprite = SpriteAnimationComponent(
  animation: animation,
  size: Vector2(180, 240),
  anchor: Anchor.center,
);
```

Use the existing ASTRALIS game profile. Do not replace the six approved dragon identities or use a different dragon name. Next art priorities remain directional/banking flight poses, player attack/damage/recovery/dash, then enemy movement/attacks, projectiles, shields and hit effects.
