DRAGON LUNARYVELL — RUN 35

Use the existing Flutter + Flame project in the existing GitHub Codespace.
Do not replace the whole repository or switch branches.

1. Upload this ZIP to the top level of /workspaces/dragon_arcade.
2. In the ONE terminal, paste this ONE line:

unzip -oq DRAGON_LUNARYVELL_Run35_Branding_Enemy_Menu_Fix.zip && python3 run35_install.py

3. Wait for RUN 35 COMPLETE, then refresh the already-running port 8765
   browser test page. The private web build includes the TEST TOOLS button.
   If no web server is running, use your existing server
   workflow from Run 34; this installer does not disturb port 8765.

Safety: The installer verifies branch and hashes before editing; it only
copies the package's named files, saves older versions in .run35_backups,
runs local asset checks and Flutter widget test and web release build, then
automatically restores the prior project on any failure. It never touches
the 20 corrected Run 34 dragon frames.

Optional: python3 run35_install.py --skip-build only does asset checks and
does NOT produce a runnable new web bundle. Use only for troubleshooting.

After success: test all six dragon choices (before play and in flight),
the three more visible enemy types, title screen, loading, pause, special,
boss, restart and return-to-title. The yellow bug-test button appears ONLY
in builds made with --dart-define=DL_DEV_TOOLS=true.

Android APK testing requires an Android SDK configured in Codespaces;
APK release signing is currently configured to use a debug key for tests.
Do not treat this as a production-signed release key.
