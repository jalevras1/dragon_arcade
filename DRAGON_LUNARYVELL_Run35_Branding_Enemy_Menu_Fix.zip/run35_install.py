#!/usr/bin/env python3
"""Guarded Run 35 install for DRAGON LUNARYVELL.

Use inside /workspaces/dragon_arcade:
  unzip -oq DRAGON_LUNARYVELL_Run35_Branding_Enemy_Menu_Fix.zip && python3 run35_install.py

Copies only manifest-listed files; never touches five Run 34 dragon folders.
Automatic per-file backups and rollback on checks/test/build failure.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import shutil
import subprocess
import sys

MANIFEST_FILE = "run35_manifest.json"
BRANCH = "dragon-lunaryvell-repairs"
ROOT = Path.cwd().resolve()


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as fd:
        for chunk in iter(lambda: fd.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def command(args: list[str], timeout: int = 1000) -> None:
    print("  RUN:", " ".join(args), flush=True)
    subprocess.run(args, cwd=ROOT, check=True, timeout=timeout)


def flutter_binary() -> str | None:
    chosen = shutil.which("flutter")
    if chosen:
        return chosen
    standard = Path.home() / "flutter/bin/flutter"
    return str(standard) if standard.is_file() else None


def validate_relative(raw: str) -> Path:
    p = PurePosixPath(raw)
    if p.is_absolute() or ".." in p.parts or not p.parts:
        raise RuntimeError("Unsafe path in Run 35 manifest")
    local = ROOT.joinpath(*p.parts)
    if any(ROOT.joinpath(*p.parts[:i]).is_symlink()
           for i in range(1, len(p.parts) + 1)):
        raise RuntimeError("Symlink target blocked: " + raw)
    return local


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-build", action="store_true",
                        help="Install without Flutter tests/web build (not recommended)")
    args = parser.parse_args()
    if not (ROOT / ".git").exists() or not (ROOT / "pubspec.yaml").exists():
        print("STOP: open the dragon_arcade project root before this command.")
        return 2
    branch = subprocess.check_output(
        ["git", "branch", "--show-current"], cwd=ROOT, text=True).strip()
    if branch != BRANCH:
        print(f"STOP: current branch is {branch}; expected {BRANCH}.")
        return 2
    mf = ROOT / MANIFEST_FILE
    if not mf.is_file():
        print("STOP: Run 35 ZIP has not been extracted here.")
        return 2
    data = json.loads(mf.read_text())
    if data.get("run") != 35 or data.get("expected_branch") != BRANCH:
        print("STOP: incorrect Run 35 manifest.")
        return 2

    flutter = None if args.skip_build else flutter_binary()
    if not args.skip_build and not flutter:
        print("STOP: Flutter not on PATH or in ~/flutter/bin; nothing changed.")
        return 2

    pending = []
    for entry in data["files"]:
        rel = entry["path"]
        dst = validate_relative(rel)
        src = ROOT / "run35_payload" / rel
        if not src.is_file() or digest(src) != entry["new_sha256"]:
            print("STOP: ZIP payload incomplete or damaged:", rel)
            return 2
        old = entry.get("old_sha256")
        if dst.exists():
            current = digest(dst)
            if current == entry["new_sha256"]:
                continue  # Already installed; safe to repeat.
            if current != old:
                print("STOP: existing file differs from expected baseline:", rel)
                print("Your changes are safe. Ask for a matching update package.")
                return 2
        elif old is not None:
            print("STOP: baseline project file missing:", rel)
            return 2
        pending.append((rel, src, dst))

    if not pending:
        print("RUN 35 ALREADY INSTALLED. Refresh the game in your browser.")
        return 0

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup = ROOT / ".run35_backups" / stamp
    backup.mkdir(parents=True, exist_ok=False)
    modified: list[tuple[str, Path, bool]] = []
    build = ROOT / "build/web"
    existed_build = build.is_dir()
    print(f"RUN 35: installing {len(pending)} verified files.")
    try:
        # Backup everything BEFORE the first replacement.
        for rel, src, dst in pending:
            existed = dst.is_file()
            modified.append((rel, dst, existed))
            if existed:
                target = backup / "original_files" / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, target)
        if existed_build and not args.skip_build:
            shutil.copytree(build, backup / "old_web_build")
        for rel, src, dst in pending:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        command([sys.executable, "tools/run35_verify.py"], timeout=100)
        if not args.skip_build:
            command([flutter, "test", "test/widget_test.dart"], timeout=600)
            # This is a private TEST preview; production builds omit the flag.
            command([flutter, "build", "web", "--release",
                     "--dart-define=DL_DEV_TOOLS=true"], timeout=1200)
            if not (build / "index.html").is_file():
                raise RuntimeError("Flutter reported success but web output is missing")
        (backup / "SUCCESS.txt").write_text(
            "Run 35 installed and " +
            ("asset-audited only" if args.skip_build else "Flutter tested and web built") +
            "\n")
        print("\nRUN 35 COMPLETE.")
        if args.skip_build:
            print("Note: Flutter build was skipped; run flutter build web --release.")
        else:
            print("Refresh your existing port 8765 game browser tab.")
        print("Saved prior files in .run35_backups/" + stamp)
        return 0
    except BaseException as exc:
        print("\nCHECK/BUILD FAILED:", exc)
        print("Restoring previous project files…")
        for rel, dst, existed in reversed(modified):
            if existed:
                original = backup / "original_files" / rel
                if original.is_file():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(original, dst)
            elif dst.is_file():
                dst.unlink()
        if not args.skip_build:
            old_web = backup / "old_web_build"
            if old_web.is_dir():
                if build.is_dir():
                    shutil.rmtree(build)
                shutil.copytree(old_web, build)
            elif not existed_build and build.is_dir():
                shutil.rmtree(build)
        print("ROLLBACK COMPLETE. The old game files were restored.")
        print("Share the final error line for a targeted fix.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
