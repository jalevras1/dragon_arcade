# DRAGON LUNARYVELL — Master Project Record v7

Consolidated 2026-11-19. This supplements the preserved v6 record; it does not
erase prior plans, claims of work, or files. Source of truth for the *currently
checked-in game* is `jalevras1/dragon_arcade`, repair branch
`dragon-lunaryvell-repairs`, observed baseline commit
`9f94339b43c4b666b66c1efafc39249c3e5f07fe`.

## Locked decisions / user preferences
- **Name:** DRAGON LUNARYVELL. DRAGON ASTRAVELL is an old alternative, not
  an authorized rename.
- **Platform:** Flutter + Flame; Android and web; portrait, strictly original
  **2D** sprite-based fantasy dragon arcade shooter. No 3D characters or
  3D-rendered substitutes.
- **Workflow:** do not require new tools, subscriptions, or paid apps; owner
  works from an Android phone in GitHub Codespaces; one terminal/screen,
  short commands, clear checkpoints; protect existing code and backups.
- **Priorities:** functioning and readable combat first; visual polish follows
  verified gameplay. Do not repeatedly create unnecessary image variations.
- **Dragon identities are fixed:** ASTRALIS (Celestial Nova), TEMPESTRYX
  (Lightning Dash), IGNIVAR (Dragonfire Barrage), NYXARIEL (Void Shift),
  SOLARION (Solar Collapse), AQUARYTH (Tidal Vortex).

## Verified baseline inventory and cross-references
| Area | Files / status at Run 35 source checkout |
|---|---|
| `lib/game` | Existing Flame game, six profiles; Run 35 fixes selection independently of art load, adds testing hooks and slightly larger enemies |
| `lib/main.dart`, `lib/ui` | New cohesive title/menu, choose dragon, instructions, about, loading, error screen, responsive HUD and return-to-title UI |
| `assets/images/dragons/astralis/flight` | Eight existing 2D frames plus one atlas, preserved |
| `assets/images/run32/dragons` | 20 Run 34 cleaned player animation frames, preserved **untouched** by Run 35 |
| `assets/images/run31/dragons` | Five still-art fallbacks, preserved |
| `assets/images/run31/abilities` | Six ability illustrations, preserved |
| `assets/images/run31/bosses` | Eclipse Gargoyle Warden boss illustration, preserved |
| `assets/images/projectiles` | Six existing player/enemy projectile frames, preserved |
| `assets/images/enemies` | Ten frame paths replaced by complete, center-aligned, original sky-raider, storm-harpy and shadow-wyvern illustrations |
| `assets/images/branding` | New transparent game emblem and 1024 px app icon, used by Flutter screens |
| `web` | Browser title, manifest/PWA, favicon, maskable/regular app icons, instant HTML bootstrap splash |
| `android/app/src/main/res` | Launcher icon densities, native dark splash branding and theme |
| `art_sources/run35` | Four generated source art masters: emblem, sky-raider, harpy, wyvern, saved *outside runtime assets* |
| `tools` | Source-to-asset build script, sprite/integration verification |
| `test` | Existing roster test preserved; menu and six-dragon selection widget tests updated |
| Root ZIPs/reports | Existing Run 21, Run 32, Run 34, enemy integration and asset-preparation ZIPs; historic logs and reports remain intact |

### Historic packages and non-integrated work
- **Runs 02–20:** Architecture, controls, AI, campaign, bosses, economy,
  progression, save-data services, tests and staging tools are described in v6.
  Many are **separate archives**, not necessarily merged into this live app.
- **Run 21:** Original 8-frame ASTRALIS animation. Live checked-in
  `astralis_flight_wing_00..07.png` files are present and used.
- **Run 22:** Directional ASTRALIS pose candidates, **not** substituted for
  the functioning 8-frame flight; left-edge margins still need repair.
- **Run 23–24:** Optimized Astral Citadel vertical background and staging
  script exist as a **separate unintegrated candidate**. Do not overwrite
  the current game or claim it is in use.
- **Runs 25–30:** Historic production briefs cover sprite QA, frame pacing,
  combat rules, wave tiers and Android stability; exact live integration of
  every independent artifact remains unverified.
- **Run 31:** Five dragon stills, six VFX and one boss integrated.
- **Run 32:** New projectile sprites and 5 animated-dragon flight sets.
  The initial crop pipeline had multi-pose/ghost frames; do **not** reuse
  those old extraction outputs.
- **Run 33:** Attempted crop repair; cropped the wrong coordinates.
- **Run 34:** Twenty cleaned 512×512 dragon frames were installed and user
  reported success; user reported playable browser build.
- **Run 35:** This package introduces new artwork/UI and technical repairs.
  Local Python audit passed; **not yet confirmed Flutter-compiled or
  installed in the user's live Codespace at record creation**.

### Persistent asset archive references
- Run 31: Library ID `libfile_f5ec09f2553c8191ac9673a3ed202863`
- Run 32: Library ID `libfile_1a882fef5640819188fa640da6826649`
- Run 34: Library ID `libfile_e9c9dfb294e08191a0f1346c88efee29`
- Existing master v6: `libfile_ad079a5200d48191b32e5d2101732b8d`
- **Recovered original five 2×2 dragon atlas masters:** saved as a separate
  clearly labeled reference-only ZIP, Library ID
  `libfile_76aa37b9bdd08191ad912724bb270dd0`.
- Numerous earlier named concept/atlas PNGs are saved in Library. They
  are **references**, not verified single-frame runtime assets.

### Previously unsaved source-art cross-check
- Audited the 21 image-generation PNGs available in the earlier local
  scratch source folder: four are the new Run 35 originals stored in this
  update's `art_sources/run35` and 17 predate Run 35.
- Compared byte-for-byte hashes of those 17 historic images against the
  archived Run 31/32/34 ZIP entries: **12 already have identical archived
  copies**; **five did not**. The five missing masters are the four-pose
  **SOLARION, IGNIVAR, AQUARYTH, TEMPESTRYX and NYXARIEL atlases**.
- All five were saved together with original filenames and SHA256 hashes
  in the separate recovered-master ZIP above. The extracted Run 34 images
  remain the runtime-ready versions; original composite atlases are
  **reference-only** and must not replace them.

## Run 35 user-visible design and behavior
- Brand symbol: astral dragon and crescent, sapphire/violet/gold, real-alpha
  PNG; same emblem for logo, title, loading and platform icons.
- Menu: Begin Flight, Choose Dragon (all six names), How to Play, About.
- During game: touch-move, auto-fire, special ability, restart, pause,
  dragon selection, home/return-to-menu. Initial chosen dragon art preloads.
- Dragon selection changes profile/HUD **immediately**, image-loading errors
  fall back to game vector art and never silently cancel selection.
- Three enemy types are visually upgraded; 10 PNG frame paths repaired.
  Drawn sprite widths: 56/64/72 px -> **64/72/82 px**, collision radii
  13/15/17 -> **15/17/19 px**, preserving relative hit fairness.
- Optional developer controls (manual wave advance, heal, spawn any enemy)
  are available only with `--dart-define=DL_DEV_TOOLS=true` builds.
- Flutter/Flame supports Android APK testing, but the user's Codespace
  Android SDK and stable signing key **must be checked before promising
  repeat-install updates**. Installing Flutter itself on the Android phone
  is not necessary.

## Quality gates and safety
- Local audit: 10 enemy frames + 20 Run 34 dragon frames + logo = 31
  validated real-alpha, padded sprites; 11 Android/web icon/splash files.
- Generated enemy **poses are gentle image-based variation of each complete
  2D creature master**; separately illustrated wing articulation remains
  future polish, not something falsely claimed complete.
- Installer checks expected target hashes against the actual GitHub baseline,
  backs up only touched files, preserves all Run 34 dragon files, tests and
  compiles in the owner's Codespace, rolls back on failure.
- Do not claim Flutter analyzer/widget tests/web/APK or live phone test passed
  until their actual output has been observed.
- Project-wide inventory is limited to accessible repo, referenced Library
  artifacts and earlier chat facts; unknown private phone/other Codespace
  folders cannot be asserted complete or silently synced.

## Next milestones after Run 35 phone verification
1. Verify title, loading, all six character switches, enemy silhouettes,
   collision fairness, boss wave, pause, restart and frame pacing on Android.
2. Confirm Android toolchain; build a signed **test** APK and keep the same
   application ID/signing identity for later update installations.
3. Produce meaningful isolated, correctly pivoted 2D enemy wing/action
   animations rather than static-stretch interim frames.
4. Integrate the Run 23/24 Astral Citadel background safely as a stage layer,
   then combat impact/defeat FX and audio.
5. Reconcile prior Run 02–20 campaign/saving/economy systems with this one
   playable game *without* duplicate wave schedulers or incompatible saves.
