#!/usr/bin/env python3
"""Read-only sprite and integration audit for DRAGON LUNARYVELL Run 35."""
from __future__ import annotations
from pathlib import Path
from PIL import Image
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
IMAGE_ROOT = ROOT / "assets/images"


def check(condition: bool, reason: str) -> None:
    if not condition:
        raise AssertionError(reason)


def audit_sprite(relative: str, min_margin: int) -> dict:
    path = IMAGE_ROOT / relative
    check(path.is_file(), f"missing sprite {relative}")
    with Image.open(path) as im:
        check(im.mode == "RGBA", f"{relative}: not RGBA")
        alpha = im.getchannel("A")
        lo, hi = alpha.getextrema()
        check(lo == 0 and hi >= 240,
              f"{relative}: transparent and mostly opaque pixels required")
        bbox = alpha.point(lambda p: 255 if p > 60 else 0).getbbox()
        check(bbox is not None, f"{relative}: no foreground")
        margins = (bbox[0], bbox[1], im.width - bbox[2],
                   im.height - bbox[3])
        check(min(margins) >= min_margin,
              f"{relative}: clipped near edges; margin {margins}")
        return {"file": relative, "size": im.size, "margins": margins}


def main() -> None:
    records = []
    for group, base, count in [
        ("goblin_sky_raider", "goblin", 4),
        ("harpy", "harpy", 3),
        ("shadow_wyvern", "shadow_wyvern", 3),
    ]:
        for i in range(count):
            records.append(audit_sprite(
                f"enemies/{group}/{base}_{i:02}.png", 18))
    for dragon in ["tempestryx", "ignivar", "nyxariel",
                   "solarion", "aquaryth"]:
        for i in range(4):
            records.append(audit_sprite(
                f"run32/dragons/{dragon}/flight/{dragon}_flight_{i:02}.png",
                11))
    records.append(audit_sprite("branding/lunaryvell_emblem.png", 24))
    check(len(records) == 31, "wrong validated sprite count")

    game = (ROOT / "lib/game/dragon_lunaryvell_game.dart").read_text()
    shell = (ROOT / "lib/ui/dragon_shell.dart").read_text()
    yaml = (ROOT / "pubspec.yaml").read_text()
    check("dragon = profile;" in game, "switch method no longer updates profile")
    check("unawaited(_loadDragonArtwork(dragon))" in game,
          "initial title-screen selection has no art preload")
    check("assets/images/branding/" in yaml,
          "Flutter cannot see title artwork")
    for x in ["GameWidget<DragonLunaryvellGame>",
              "loadingBuilder:", "errorBuilder:", "BEGIN FLIGHT",
              "CHOOSE YOUR DRAGON", "DL_DEV_TOOLS"]:
        check(x in shell, f"UI feature missing: {x}")
    for x in ["web/manifest.json", "web/index.html"]:
        check("DRAGON LUNARYVELL" in (ROOT / x).read_text(),
              f"{x}: brand not installed")
    for x in ["drawable/launch_background.xml",
              "drawable-v21/launch_background.xml",
              "values/styles.xml", "values/brand_colors.xml"]:
        ET.parse(ROOT / "android/app/src/main/res" / x)
    icons = [
        "web/favicon.png", "web/icons/Icon-192.png",
        "web/icons/Icon-512.png", "web/icons/Icon-maskable-192.png",
        "web/icons/Icon-maskable-512.png",
        "android/app/src/main/res/drawable-nodpi/lunaryvell_splash.png",
    ]
    icons += [f"android/app/src/main/res/mipmap-{dpi}/ic_launcher.png"
              for dpi in ["mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"]]
    for item in icons:
        with Image.open(ROOT / item) as image:
            image.verify()
    print(json.dumps({
        "validated_transparent_sprite_frames": len(records),
        "validated_icon_and_splash_files": len(icons),
        "mobile_app_screens": ["title", "loading", "game",
                               "dragon_select", "how_to_play", "about",
                               "error"],
        "result": "PASS",
    }, indent=2))


if __name__ == "__main__":
    main()
