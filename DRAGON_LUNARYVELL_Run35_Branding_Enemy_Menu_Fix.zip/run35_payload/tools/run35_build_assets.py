#!/usr/bin/env python3
"""Rebuild the Run 35 derived assets from source art with safe, explicit bounds.

No atlas-cell inference: each source contains one validated creature/emblem.
Run from the repository root. Requires Pillow (only for building assets).
"""

from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
SOURCES = ROOT / "art_sources" / "run35"
ENEMIES = ROOT / "assets" / "images" / "enemies"
EMBLEM = ROOT / "assets" / "images" / "branding"


def isolate(name: str, size: int, content_fraction: float) -> Image.Image:
    im = Image.open(SOURCES / name).convert("RGBA")
    alpha = im.getchannel("A")
    bbox = alpha.point(lambda x: 255 if x >= 55 else 0).getbbox()
    if bbox is None:
        raise RuntimeError(f"{name} is transparent/empty")
    l, t, r, b = bbox
    w, h = r - l, b - t
    if w < 80 or h < 80:
        raise RuntimeError(f"{name}: invalid silhouette bounds {bbox}")
    im = im.crop(bbox)
    target = int(size * content_fraction)
    factor = min(target / w, target / h)
    new_size = (max(1, round(w * factor)), max(1, round(h * factor)))
    im = im.resize(new_size, Image.Resampling.LANCZOS)
    out = Image.new("RGBA", (size, size))
    out.alpha_composite(im, ((size - new_size[0]) // 2,
                             (size - new_size[1]) // 2))
    return out


def save_enemy(folder: str, stem: str, frames: int, source_name: str) -> None:
    base = isolate(source_name, 288, .78)
    dest = ENEMIES / folder
    dest.mkdir(parents=True, exist_ok=True)
    # Small, centered stretch states keep each complete frame inside the canvas.
    # No re-cropping of source atlases, no additional creatures or split poses.
    variations = [(1.0, 1.0), (1.025, .985), (1.0, .975), (.975, .99)]
    for idx in range(frames):
        sx, sy = variations[idx]
        resized = base.resize((round(288 * sx), round(288 * sy)),
                              Image.Resampling.BICUBIC)
        frame = Image.new("RGBA", (288, 288))
        frame.alpha_composite(resized, ((288 - resized.width) // 2,
                                       (288 - resized.height) // 2))
        path = dest / f"{stem}_{idx:02}.png"
        frame.save(path, optimize=True)
        assert_sprite(path)


def assert_sprite(path: Path) -> None:
    im = Image.open(path).convert("RGBA")
    if im.width != im.height or im.width < 144:
        raise RuntimeError(f"{path}: unexpected size")
    mask = im.getchannel("A").point(lambda x: 255 if x > 60 else 0)
    bbox = mask.getbbox()
    if not bbox:
        raise RuntimeError(f"{path}: empty frame")
    if min(bbox[0], bbox[1], im.width - bbox[2], im.height - bbox[3]) < 18:
        raise RuntimeError(f"{path}: near-edge clipping {bbox}")
    if mask.getextrema()[1] != 255:
        raise RuntimeError(f"{path}: missing alpha foreground")


def make_icon(master: Image.Image) -> None:
    import numpy as np

    n = 1024
    y, x = np.mgrid[:n, :n]
    radius = np.sqrt(((x - 512) / 680) ** 2 + ((y - 450) / 680) ** 2)
    t = np.clip(radius, 0, 1)
    # Dark navy-violet, deliberately opaque: PWA and Android launcher safe.
    near = np.array([40, 56, 113], dtype=np.float32)
    far = np.array([5, 8, 23], dtype=np.float32)
    arr = (near[None, None, :] * (1 - t[..., None]) +
           far[None, None, :] * t[..., None]).astype("uint8")
    bg = Image.fromarray(arr, "RGB").convert("RGBA")
    draw = ImageDraw.Draw(bg)
    draw.ellipse((91, 91, 933, 933), outline=(229, 192, 115, 160), width=7)
    symbol = master.resize((790, 790), Image.Resampling.LANCZOS)
    bg.alpha_composite(symbol, (117, 112))
    bg = bg.convert("RGB")
    # A smaller symbol inside the center-safe region for maskable icons.
    maskable = Image.fromarray(arr, "RGB").convert("RGBA")
    small = master.resize((670, 670), Image.Resampling.LANCZOS)
    maskable.alpha_composite(small, (177, 177))
    maskable = maskable.convert("RGB")

    web = ROOT / "web"
    for name, pix, source in [
        ("icons/Icon-192.png", 192, bg),
        ("icons/Icon-512.png", 512, bg),
        ("icons/Icon-maskable-192.png", 192, maskable),
        ("icons/Icon-maskable-512.png", 512, maskable),
        ("favicon.png", 48, bg),
    ]:
        dest = web / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        source.resize((pix, pix), Image.Resampling.LANCZOS).save(dest,
            optimize=True)
    launcher = ROOT / "android/app/src/main/res"
    for dpi, pix in [("mdpi", 48), ("hdpi", 72), ("xhdpi", 96),
                     ("xxhdpi", 144), ("xxxhdpi", 192)]:
        path = launcher / f"mipmap-{dpi}/ic_launcher.png"
        bg.resize((pix, pix), Image.Resampling.LANCZOS).save(
            path, optimize=True)
    splash = launcher / "drawable-nodpi/lunaryvell_splash.png"
    splash.parent.mkdir(parents=True, exist_ok=True)
    master.resize((192, 192), Image.Resampling.LANCZOS).save(
        splash, optimize=True)
    bg.save(EMBLEM / "lunaryvell_app_icon_1024.png", optimize=True)


def main() -> None:
    EMBLEM.mkdir(parents=True, exist_ok=True)
    symbol = isolate("celestial_emblem_master.png", 512, .87)
    symbol.save(EMBLEM / "lunaryvell_emblem.png", optimize=True)
    save_enemy("goblin_sky_raider", "goblin", 4,
               "armored_sky_raider_master.png")
    save_enemy("harpy", "harpy", 3, "storm_harpy_master.png")
    save_enemy("shadow_wyvern", "shadow_wyvern", 3,
               "shadow_wyvern_master.png")
    make_icon(symbol)
    print("Run 35: 10 new aligned enemy frames, emblem and app icons built.")


if __name__ == "__main__":
    main()
