import 'package:flutter/material.dart';
import 'ui/dragon_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DragonLunaryvellApp());
}

class DragonLunaryvellApp extends StatelessWidget {
  const DragonLunaryvellApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'DRAGON LUNARYVELL',
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: const Color(0xFF050817),
          colorScheme: const ColorScheme.dark(
            primary: Color(0xFF65D9FF),
            secondary: Color(0xFFFFD77A),
          ),
        ),
        home: const DragonShell(),
      );
}
