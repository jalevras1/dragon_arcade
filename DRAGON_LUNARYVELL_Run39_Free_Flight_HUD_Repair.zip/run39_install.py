#!/usr/bin/env python3
"""Guarded Run 39 update: touch control, HUD, startup, with full rollback."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path, PurePosixPath
import argparse
import json
import shutil
import subprocess
import sys

ROOT = Path.cwd().resolve()
EXPECTED_BRANCH = 'dragon-lunaryvell-repairs'


def digest(path: Path) -> str:
    h = sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def checked(relative: str) -> Path:
    entry = PurePosixPath(relative)
    if entry.is_absolute() or '..' in entry.parts or not entry.parts:
        raise ValueError('Unsafe update path: ' + relative)
    for i in range(1, len(entry.parts) + 1):
        if ROOT.joinpath(*entry.parts[:i]).is_symlink():
            raise ValueError('Refusing symlink update path: ' + relative)
    return ROOT.joinpath(*entry.parts)


def run(command: list[str], seconds: int) -> None:
    print('Verifying:', ' '.join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True, timeout=seconds)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--skip-build', action='store_true',
                        help='Installer QA only, does not make a web preview')
    option = parser.parse_args()
    if not (ROOT / '.git').is_dir() or not (ROOT / 'pubspec.yaml').is_file():
        print('STOP: Use the existing dragon_arcade Codespaces terminal.')
        return 2
    current_branch = subprocess.check_output(
        ['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip()
    if current_branch != EXPECTED_BRANCH:
        print('STOP: Wrong git branch:', current_branch)
        return 2
    manifest_path = ROOT / 'run39_manifest.json'
    if not manifest_path.is_file():
        print('STOP: Extract Run 39 ZIP before running installer.')
        return 2
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('run') != 39 or manifest.get('branch') != EXPECTED_BRANCH:
        print('STOP: Unrecognized Run 39 manifest.')
        return 2
    flutter = shutil.which('flutter')
    if not option.skip_build and not flutter:
        candidate = Path.home() / 'flutter/bin/flutter'
        flutter = str(candidate) if candidate.is_file() else None
    if not option.skip_build and not flutter:
        print('STOP: Flutter not available. No files changed.')
        return 2

    pending: list[tuple[str, Path, Path]] = []
    for entry in manifest['files']:
        rel = entry['path']
        target = checked(rel)
        source = checked('run39_payload/' + rel)
        if not source.is_file() or digest(source) != entry['new_sha256']:
            print('STOP: ZIP payload failed integrity check:', rel)
            return 2
        if target.is_file():
            old_hash = digest(target)
            if old_hash == entry['new_sha256']:
                continue
            if old_hash != entry.get('old_sha256'):
                print('STOP: Local custom changes protected:', rel)
                print('No files were changed; contact ChatGPT with this line.')
                return 2
        elif entry.get('old_sha256') is not None:
            print('STOP: Existing file missing:', rel)
            return 2
        pending.append((rel, source, target))

    if not pending:
        print('RUN 39 ALREADY INSTALLED. Refresh your existing 8765 tab.')
        return 0

    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    backup = ROOT / '.run39_backups' / stamp
    previous_web = backup / 'previous_web'
    build = ROOT / 'build/web'
    backup.mkdir(parents=True)
    original: list[tuple[str, Path, bool]] = []
    web_moved = False
    try:
        for rel, _, target in pending:
            was_present = target.is_file()
            original.append((rel, target, was_present))
            if was_present:
                saved = backup / 'original_files' / rel
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
        for _, source, target in pending:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        run([sys.executable, 'tools/run35_verify.py'], 120)
        run([sys.executable, 'tools/run36_verify.py'], 120)
        run([sys.executable, 'tools/run38_verify.py'], 120)
        run([sys.executable, 'tools/run39_verify.py'], 120)
        if not option.skip_build:
            run([flutter, 'test', 'test/widget_test.dart',
                 'test/special_ability_rules_test.dart',
                 'test/campaign_story_test.dart',
                 'test/dragon_flight_cycle_test.dart'], 420)
            if build.is_dir():
                shutil.move(str(build), str(previous_web))
                web_moved = True
            run([flutter, 'build', 'web', '--release', '--no-pub',
                 '--dart-define=DL_DEV_TOOLS=true'], 900)
            if not (build / 'index.html').is_file():
                raise RuntimeError('Web build did not produce index.html')
        (backup / 'SUCCESS.txt').write_text('Run 39 files backed up and ' +
            ('offline checks passed\n' if option.skip_build else
             'web release built\n'))
        print('\nRUN 39 COMPLETE — full-area flight, compact HUD, no art flash.')
        print('Prior working files saved in', backup.relative_to(ROOT))
        if option.skip_build:
            print('NOTE: --skip-build did not make a playable web preview.')
        else:
            print('Refresh the SAME 8765 preview tab. No new server required.')
        return 0
    except BaseException as error:
        print('\nRUN 39 FAILED:', error)
        print('Restoring Run 38 code and previous web build...', flush=True)
        for rel, target, was_present in reversed(original):
            if was_present:
                saved = backup / 'original_files' / rel
                if saved.is_file():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(saved, target)
            elif target.is_file():
                target.unlink()
        if web_moved:
            if build.is_dir():
                shutil.rmtree(build)
            shutil.move(str(previous_web), str(build))
        print('ROLLBACK COMPLETE — prior working version restored.')
        return 1


if __name__ == '__main__':
    sys.exit(main())
