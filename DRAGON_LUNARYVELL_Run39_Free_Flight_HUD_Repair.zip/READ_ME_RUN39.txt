DRAGON LUNARYVELL - RUN 39: FULL FLIGHT, TINY HUD, NO ART FLASH

Requires successful Run 38. No more image downloads, apps or terminals.

STEP 1 - Upload this one ZIP directly to your existing repair branch:
https://github.com/jalevras1/dragon_arcade/upload/dragon-lunaryvell-repairs
Tap Commit changes. Do not extract the ZIP on your phone.

STEP 2 - In your ONE existing Codespaces terminal paste this single command:

git fetch origin dragon-lunaryvell-repairs && git merge --ff-only FETCH_HEAD && unzip -oq DRAGON_LUNARYVELL_Run39_Free_Flight_HUD_Repair.zip && python3 run39_install.py

STEP 3 - Wait for RUN 39 COMPLETE; refresh the same port 8765 preview.

REPAIRS:
- Remove the old vertical restriction that blocked dragons above 38% of
  the screen. Dragon centers follow the user's finger anywhere within the
  actual playfield, keeping their wings and tail visible at all edges.
- Faster, smoothly interpolated finger following; Haste still adds speed.
- TEMPESTRYX's dash now respects the expanded full-screen flight area.
- Three score/wave/hull HUD panels are thinner, translucent, one-line.
- Top-right dragon selection and developer tools are also less obstructive.
- Game artwork and enemy sprites decode before first playable frame, so
  the old gradient/placeholder art does not flicker on first render.
- Preserve every Run 38 sprite, screen image, power, story, wave and boss.

SAFETY: Verify exact prior Run 38 file hashes, back up changed files and
the previous build/web, check all Run 35/36/38/39 artwork and gameplay
guards, run Flutter tests, rebuild web, restore on failure.

If STOP or FAILED prints, share that line and do not repeatedly retry.
