# DRAGON LUNARYVELL — Run 32 gameplay animation pack

**Purpose:** Make the five remaining playable dragons flap their wings, while
preserving the working game and ASTRALIS's original eight-frame animation.

This update contains **20 transparent PNG frames** (four distinct wing poses
per dragon), a guarded code integration, and a safe installer. It also connects
the **six projectile sprite frames already present in the repository**:
three celestial player bolts and three ember enemy bolts. No extra projectile
images were generated or duplicated.

Dragons covered: TEMPESTRYX, IGNIVAR, NYXARIEL, SOLARION, AQUARYTH. The
TEMPESTRYX profile's historical internal ID is `temperstryx`; this ID is left
unchanged, while its asset filenames use `tempestryx`.

## Install from one Codespaces terminal on your phone

1. Keep the current working branch `dragon-lunaryvell-repairs` and your backup.
2. Upload the single `DRAGON_LUNARYVELL_Run32_Gameplay_Animations.zip` file
   into the Flutter project root (the folder containing `pubspec.yaml`).
3. Open **one terminal** in that same folder and enter these two lines:

   ```bash
   unzip -q DRAGON_LUNARYVELL_Run32_Gameplay_Animations.zip
   python3 DRAGON_LUNARYVELL_Run32_Gameplay_Animations/install_run32.py
   ```

   The installer verifies every PNG and the *exact* known working versions of
   `pubspec.yaml` and `lib/game/dragon_lunaryvell_game.dart`, copies new assets
   into their own `assets/images/run32/` directory, backs up original source,
   and runs `flutter pub get`, `flutter test --no-pub`, and
   `flutter build web --release`. If a check fails, the original source files
   are restored automatically. Existing Run 31 images are never overwritten.

4. If the terminal says **RUN 32 COMPLETE**, open your game and select each of
   the five dragons. Wings should cycle through upstroke, midstroke, full
   extension, and downstroke. Both player and enemy projectiles should show
   the previously made artwork. ASTRALIS, abilities, and boss art remain as
   before.
5. Once checked on the phone, commit and push the two changed source files
   and the new `assets/images/run32/` folder. Do not commit before confirming
   the build and game play are good.

### Safe checks and reversal

From the same project-root terminal:

```bash
python3 DRAGON_LUNARYVELL_Run32_Gameplay_Animations/install_run32.py --dry-run
```

Dry run validates without changing anything. To undo Run 32 source changes
after a successful install (provided the source files have not been modified
further):

```bash
python3 DRAGON_LUNARYVELL_Run32_Gameplay_Animations/install_run32.py --rollback
```

This restores only the two original code/config files; the new images remain
in their isolated directory, unused. Backups are under `.run32_backup/`.

## Runtime implementation notes

- ASTRALIS: its existing eight individual animation frames and timing are
  untouched.
- Five alternate dragons: four illustrated 512×512 RGBA frames each, looped
  using frame indices `0, 1, 2, 3, 2, 1` on the existing 0.1-second clock.
- Each dragon loads its own frames only when selected; if a Run 32 image
  cannot load, the Run 31 static pose remains available.
- Existing projectile sprites load asynchronously with vector fallbacks.
- Boss artwork, special-ability mechanics, collision, scoring, and wave
  behavior are not changed.

## Verification status

The images were visually checked against the game's dark background, and all
20 output PNGs have RGBA alpha and identical 512×512 dimensions. The source
patch is based on the current, matching `dragon-lunaryvell-repairs` GitHub
version. This package was staged and tested for installation safety offline.
It **has not yet been compiled in your Codespace**: the installer performs the
Flutter test and web build there before declaring success.
