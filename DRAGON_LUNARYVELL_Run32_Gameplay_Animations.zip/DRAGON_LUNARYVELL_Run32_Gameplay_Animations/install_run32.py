#!/usr/bin/env python3
"""Install Run 32 in the existing Flutter source tree, with safe guards.

Run from the folder containing pubspec.yaml. Never force-overwrites a
different file; makes a recoverable source backup and restores it if a check
fails. ASTRALIS and Run 31 files are not changed by this installer.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

PACK = Path(__file__).resolve().parent
ROOT = Path.cwd().resolve()
BACKUPS = ROOT / ".run32_backup"

BASELINE = {
    "lib/game/dragon_lunaryvell_game.dart":
        "5cf68ee4a1c7c68b4c5b3c9250dfba4a42feeb601ce82bd185afdcff9545f05a",
    "pubspec.yaml":
        "63e13ec3ed35e49dc41074795cca79d9a482dca0c909dd8bd767105b891a8235",
}

DRAGONS = ("tempestryx", "ignivar", "nyxariel", "solarion", "aquaryth")
FRAMES = tuple(
    f"dragons/{dragon}/flight/{dragon}_flight_{frame:02d}.png"
    for dragon in DRAGONS
    for frame in range(4)
)


def digest(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            sha.update(chunk)
    return sha.hexdigest()


def stop(message: str) -> None:
    print("\nRUN 32 STOPPED SAFELY: " + message, flush=True)
    raise SystemExit(2)


def atomic_copy(src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        dir=dest.parent, prefix=".run32_tmp_", delete=False
    ) as output:
        temporary = Path(output.name)
        try:
            with src.open("rb") as input_stream:
                shutil.copyfileobj(input_stream, output)
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    try:
        os.replace(temporary, dest)
    finally:
        temporary.unlink(missing_ok=True)


def verify_png(path: Path) -> None:
    with path.open("rb") as stream:
        header = stream.read(26)
    if len(header) != 26 or not header.startswith(b"\x89PNG\r\n\x1a\n"):
        stop(f"Broken image: {path.name}")
    width, height = struct.unpack(">II", header[16:24])
    if (width, height) != (512, 512) or header[25] != 6:
        stop(f"Unexpected PNG dimensions or alpha in {path.name}")


def examine_assets() -> list[tuple[Path, Path]]:
    actual = {
        item.relative_to(PACK).as_posix()
        for item in (PACK / "dragons").glob("*/flight/*.png")
    }
    if actual != set(FRAMES):
        stop("The ZIP must contain exactly 20 complete animation PNGs.")
    result = []
    for relative in FRAMES:
        source = PACK / relative
        verify_png(source)
        target = ROOT / "assets" / "images" / "run32" / relative
        if target.exists() and digest(target) != digest(source):
            stop("Different art already exists: " + target.relative_to(ROOT).as_posix())
        result.append((source, target))
    return result


def examine_source() -> str:
    states = set()
    for filename, baseline_hash in BASELINE.items():
        current = ROOT / filename
        integrated = PACK / "integration" / filename
        if not current.is_file() or not integrated.is_file():
            stop("Missing Flutter source or integration: " + filename)
        current_hash = digest(current)
        if current_hash == baseline_hash:
            states.add("baseline")
        elif current_hash == digest(integrated):
            states.add("integrated")
        else:
            stop(filename + " differs from the reviewed working branch. "
                 "Your changes have not been overwritten.")
    if len(states) != 1:
        stop("Only some Run 32 files are installed. Review the source first.")
    return states.pop()


def backup_source() -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
    location = BACKUPS / stamp
    location.mkdir(parents=True, exist_ok=False)
    for filename in BASELINE:
        target = location / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / filename, target)
    return location


def restore_source(backup: Path) -> None:
    for filename in BASELINE:
        atomic_copy(backup / filename, ROOT / filename)
    print("RUN 32: original working source restored.", flush=True)


def rollback() -> None:
    marker = BACKUPS / "latest.json"
    if not marker.is_file():
        stop("There is no completed Run 32 install to undo.")
    data = json.loads(marker.read_text(encoding="utf-8"))
    location = BACKUPS / data["stamp"]
    for filename in BASELINE:
        if not (location / filename).is_file():
            stop("Original backup is missing: " + filename)
        if digest(ROOT / filename) != digest(PACK / "integration" / filename):
            stop("Source changed after installation: " + filename +
                 ". Refusing to discard newer work.")
    restore_source(location)
    print("RUN 32 ROLLBACK COMPLETE. The additional images remain unused.")


def run_check(command: list[str], limit_seconds: int) -> None:
    print("RUN 32 CHECK:", " ".join(command), flush=True)
    try:
        result = subprocess.run(command, cwd=ROOT, check=False,
                                timeout=limit_seconds)
    except subprocess.TimeoutExpired as error:
        raise RuntimeError("Timed out: " + " ".join(command)) from error
    if result.returncode != 0:
        raise RuntimeError("Command failed (exit " + str(result.returncode) +
                           "): " + " ".join(command))


def main() -> None:
    parser = argparse.ArgumentParser(description="Safe Run 32 installer")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--rollback", action="store_true")
    parser.add_argument("--skip-flutter-checks", action="store_true",
                        help="Offline test only; do not use for the real game")
    args = parser.parse_args()

    if not (ROOT / "pubspec.yaml").is_file():
        stop("Open the Flutter project folder containing pubspec.yaml.")
    if args.rollback:
        rollback()
        return
    assets = examine_assets()
    state = examine_source()
    print("RUN 32 PRECHECK PASSED: 20 RGBA frames and matching game source.",
          flush=True)
    if args.dry_run:
        print("DRY RUN COMPLETE. No files changed.")
        return

    if state == "integrated":
        print("RUN 32 CODE ALREADY INSTALLED. Nothing replaced.")
        return

    if not args.skip_flutter_checks and not shutil.which("flutter"):
        stop("Flutter is unavailable here. No source files were changed.")

    added = 0
    for source, target in assets:
        if not target.exists():
            atomic_copy(source, target)
            added += 1
    print(f"RUN 32 ART READY: 20 verified, {added} newly added.", flush=True)

    backup = backup_source()
    try:
        for filename in BASELINE:
            atomic_copy(PACK / "integration" / filename, ROOT / filename)
        if args.skip_flutter_checks:
            print("RUN 32 OFFLINE STAGING: Flutter checks intentionally skipped.")
        else:
            run_check(["flutter", "pub", "get"], 240)
            run_check(["flutter", "test", "--no-pub"], 360)
            run_check(["flutter", "build", "web", "--release"], 720)
    except BaseException as error:
        restore_source(backup)
        print("RUN 32 CHECK FAILED; source rolled back:", error)
        print("The unused Run 32 images remain in their separate folder.")
        raise SystemExit(3)

    marker = BACKUPS / "latest.json"
    marker.write_text(json.dumps({"stamp": backup.name}), encoding="utf-8")
    print("\nRUN 32 COMPLETE: five additional dragons now have animated wings.")
    print("The existing projectile art is connected with safe shape fallbacks.")
    print("ASTRALIS and Run 31 artwork remain untouched.")
    print("TEST ON YOUR PHONE, THEN COMMIT AND PUSH THE WORKING RESULT.")


if __name__ == "__main__":
    main()
